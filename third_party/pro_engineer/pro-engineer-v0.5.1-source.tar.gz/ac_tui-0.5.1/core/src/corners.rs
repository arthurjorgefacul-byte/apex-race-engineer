//! Corners found in the trace, and where a lap's time actually went.
//!
//! The application had no notion of a corner. It could say "Speed: 183 km/h"
//! and "you lost 0.4 s somewhere", and a driver wanting to know *where* had to
//! read a graph and guess. This turns a lap's telemetry into a numbered list of
//! corners and a per-corner account of the time, which is the thing every other
//! piece of analysis in `docs/plan-0.3.7-analysis.md` is built on.
//!
//! ## Found, not looked up
//!
//! A corner is a stretch where lateral load stays up long enough to be a corner
//! rather than a kink or a bump. That needs no track data at all, so it works on
//! mods and on tracks nobody has written a table for — which is the whole reason
//! it is done this way rather than from a per-track list of corner positions
//! somebody would have to maintain.
//!
//! ## Distance, never index
//!
//! Corners are identified by **where they are**, not by their position in the
//! list. Two laps of the same track can detect a different number of corners —
//! a driver who ran wide and never loaded the car through a fast kink is
//! missing one — and comparing T5 against T5 by index after that compares two
//! different corners and reports a large, invented delta. Everything here
//! matches by distance window, and a corner found in one lap and not the other
//! is *no comparison* rather than a comparison against nothing.
//!
//! Distances are AC's normalised car position: 0.0 at the line, 1.0 at the line
//! again. Metres are available only when the track's length is known, so
//! anything reported in metres takes it as an argument and says so.

use crate::analyzer::TelemetryPoint;
use serde::{Deserialize, Serialize};

/// Lateral load that begins a corner, in g.
///
/// High enough that a straight with camber on it is not a corner, low enough
/// that a fast fifth-gear kink still is. The pair with [`SUSTAIN_G`] is
/// hysteresis: a corner does not end because one sample dipped.
const ENTER_G: f32 = 0.35;

/// Lateral load a corner has to fall below to be over, in g.
const SUSTAIN_G: f32 = 0.20;

/// The shortest stretch treated as a corner, as a fraction of a lap.
///
/// About 20 m on a 5 km track. Below this it is a bump, a kerb, or one noisy
/// sample, and naming it "T4" would push every later corner's number along.
const MIN_LENGTH: f32 = 0.004;

/// Two stretches the same way round and closer together than this are one
/// corner, as a fraction of a lap.
///
/// A long corner that unloads briefly over a crest is one corner to a driver
/// and would otherwise be reported as two. A direction change is never merged:
/// left-then-right is a chicane, which is two corners no matter how tight.
const MERGE_GAP: f32 = 0.004;

/// How far apart two corners' apexes may be and still be the same corner, as a
/// fraction of a lap.
///
/// About 50 m on a 5 km track. Wide enough that a different line through the
/// same corner still matches, tight enough that two corners in a quick sequence
/// do not match each other.
const MATCH_WINDOW: f32 = 0.010;

/// Pedal pressure that counts as being on the brakes.
const BRAKE_ON: f32 = 0.05;

/// Throttle that counts as being back on the power, rather than feeding it in
/// to balance the car.
const THROTTLE_ON: f32 = 0.50;

/// How far back from a corner's entry to look for the braking point, as a
/// fraction of a lap. About 250 m on a 5 km track, which is longer than any
/// braking zone in a road car.
const BRAKE_LOOKBACK: f32 = 0.05;

/// How close to the hardest press still counts as being at it, 0..1.
///
/// A pedal held at maximum reports 0.987, 0.991, 0.986 — the same press, and
/// three different floats. Without a tolerance the "last sample at the peak" is
/// whichever of them happened to be largest, and the trail is measured from a
/// point chosen by noise.
const AT_PEAK: f32 = 0.02;

/// Which way a corner goes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Direction {
    Left,
    Right,
}

impl Direction {
    /// A single character for a list that has no room for a word.
    pub fn arrow(self) -> &'static str {
        match self {
            Direction::Left => "←",
            Direction::Right => "→",
        }
    }
}

/// The braking for one corner, measured.
///
/// `brake_point` alone answers "did I brake too early". It says nothing about
/// what happens between that point and the apex, which is where the time in a
/// braking zone actually goes: how hard the car was stopped, and how long the
/// driver stayed on the pedal while turning in.
///
/// Every field is measured from the trace. Nothing here is a score out of ten
/// — a number a driver cannot go and change is a number that wastes their
/// evening.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Braking {
    /// Normalised distance where the brakes came on. The same value as
    /// [`Corner::brake_point`], repeated here so a braking zone is a thing on
    /// its own rather than two fields that have to be read together.
    pub start: f32,
    /// Where the driver came off the brakes. The apex when they never did —
    /// which is trail braking all the way in, and is a shape rather than a
    /// mistake.
    pub release: f32,
    /// How long the brakes were applied, in milliseconds.
    pub duration_ms: i32,
    /// The strongest deceleration reached, in g, reported positive.
    ///
    /// The trace carries braking as negative longitudinal g; this is its
    /// magnitude, which is the convention `LapData::peak_brake_g` already uses
    /// and the one a driver reads on any other tool.
    pub peak_decel_g: f32,
    /// The hardest the pedal was pressed, 0..1.
    pub peak_pressure: f32,
    /// From leaving peak pressure to coming off the pedal, in milliseconds.
    ///
    /// The trail. A long one is a driver rolling the brake off into the corner;
    /// a short one is a driver releasing it in one movement. Neither is wrong,
    /// and the difference against a reference lap is what is worth reading.
    ///
    /// Measured from the **last** sample at the hardest pressure rather than
    /// the first. A driver who holds maximum pressure for half the zone has not
    /// been trailing for half the zone — they have been stopping the car, and
    /// timing from the first of those samples would report the whole zone as
    /// trail on every corner where the peak came early.
    pub release_ms: i32,
    /// Speed when the brakes came on and when they came off, km/h.
    pub entry_speed: f32,
    pub release_speed: f32,
}

impl Braking {
    /// How far the braking zone was, in metres, on a track whose length is
    /// known. `None` otherwise, rather than a number of laps.
    pub fn distance_m(&self, track_length_m: f32) -> Option<f32> {
        if track_length_m <= 0.0 {
            return None;
        }
        Some((self.release - self.start).max(0.0) * track_length_m)
    }
}

/// One corner of one lap, and what the car did through it.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Corner {
    /// 1-based and in distance order, so this is the "7" in "T7". Only
    /// meaningful within the lap it was detected in — see the note on matching
    /// at the top of this module.
    pub number: usize,
    pub direction: Direction,

    /// Normalised distance where lateral load came up.
    pub entry: f32,
    /// Normalised distance of the slowest point, which is the apex as far as
    /// the timing is concerned.
    pub apex: f32,
    /// Normalised distance where lateral load fell away again.
    pub exit: f32,

    pub entry_speed: f32,
    pub min_speed: f32,
    pub exit_speed: f32,
    pub peak_lat_g: f32,

    /// Where the driver first touched the brakes for this corner, if they did.
    /// `None` on a corner taken flat.
    pub brake_point: Option<f32>,
    /// What happened between that point and the apex.
    ///
    /// `None` on a corner taken flat, and on any corner of a lap saved before
    /// this was measured — `serde(default)` rather than a version bump,
    /// because a lap from an older release is still a lap.
    #[serde(default)]
    pub braking: Option<Braking>,
    /// Where they got back to real throttle, if they did before the corner
    /// ended.
    pub throttle_point: Option<f32>,
    /// How long after the apex that was, in milliseconds.
    ///
    /// Measured here rather than worked out later from the trace, so a corner
    /// is self-contained: comparing two laps' throttle timing then needs the
    /// two corners and not the two traces they came from.
    pub throttle_delay_ms: Option<i32>,

    /// Lap time in milliseconds at entry and at exit, so a section's duration
    /// is a subtraction.
    pub entry_time_ms: i32,
    pub exit_time_ms: i32,
}

impl Corner {
    /// How long the car was in the corner, in milliseconds.
    pub fn duration_ms(&self) -> i32 {
        (self.exit_time_ms - self.entry_time_ms).max(0)
    }

    /// How long after the apex the driver got back on the throttle, in seconds.
    ///
    /// `None` when they never did within the corner, which is itself the
    /// finding — there is no number to compare, and inventing one would read as
    /// "on the power immediately".
    pub fn throttle_delay_s(&self) -> Option<f32> {
        self.throttle_delay_ms.map(|delay| delay as f32 / 1000.0)
    }

    /// The name a driver reads: `T7`.
    pub fn label(&self) -> String {
        format!("T{}", self.number)
    }
}

/// Interpolated lap time at a normalised distance, in milliseconds.
///
/// The trace is recorded in distance order, so this is a binary search and two
/// multiplications rather than a scan.
pub fn time_at(trace: &[TelemetryPoint], distance: f32) -> Option<i32> {
    interpolate(trace, distance, |point| point.time_ms as f32).map(|value| value as i32)
}

/// Where on the lap a given elapsed time falls, as a normalised distance.
///
/// The inverse of [`time_at`], and it exists for the same reason that one does:
/// a sector *time* cannot be drawn on a map, and a sector *line* cannot be read
/// off any game — neither simulator publishes where its sector boundaries are.
/// What both publish is the split, and the lap's own trace says where the
/// driver was when the clock read that. So the line is derived from the lap
/// rather than from a table nobody has, which is the same reasoning that makes
/// [`detect`] look for corners in the trace instead of in track data.
///
/// `None` for a lap with no trace, or a time outside the one it holds.
pub fn distance_at(trace: &[TelemetryPoint], time_ms: i32) -> Option<f32> {
    let first = trace.first()?;
    let last = trace.last()?;
    if time_ms <= first.time_ms || time_ms > last.time_ms {
        return None;
    }
    // Recorded in time order as well as distance order — the analyser appends
    // once per tick — so this is the same binary search the other way round.
    let index = trace.partition_point(|point| point.time_ms < time_ms);
    let after = trace.get(index)?;
    let before = trace.get(index.saturating_sub(1))?;

    let span = (after.time_ms - before.time_ms) as f32;
    if span <= f32::EPSILON {
        return Some(after.distance);
    }
    let factor = (((time_ms - before.time_ms) as f32) / span).clamp(0.0, 1.0);
    Some(before.distance + factor * (after.distance - before.distance))
}

/// How far ahead or behind the reference this lap was at a place on the track.
///
/// Positive is slower, the same sign convention as
/// [`Decomposition::total_ms`] and every "+0.28" a driver has ever read.
///
/// `None` where either lap has nothing at that distance — a trace that starts
/// after the line, or a reference that ended early. Withheld rather than
/// clamped: a delta of zero and "no measurement here" look identical on a
/// coloured line, and one of them is a lie.
pub fn delta_ms_at(
    lap: &[TelemetryPoint],
    reference: &[TelemetryPoint],
    distance: f32,
) -> Option<i32> {
    // **`time_at` clamps at both ends** — outside the trace it answers with
    // the first or last sample rather than with nothing, which is right for
    // `decompose`, whose section ends are deliberately `f32::MAX`. It is wrong
    // here: a stretch the reference never covered would come back as a
    // constant delta and be drawn as a plausible stretch of colour. So the
    // bounds are checked before the interpolation, not inside it.
    if !covers(lap, distance) || !covers(reference, distance) {
        return None;
    }
    Some(time_at(lap, distance)? - time_at(reference, distance)?)
}

/// Whether a trace actually holds this distance, rather than clamping to it.
fn covers(trace: &[TelemetryPoint], distance: f32) -> bool {
    match (trace.first(), trace.last()) {
        (Some(first), Some(last)) => distance >= first.distance && distance <= last.distance,
        _ => false,
    }
}

/// One point of a delta trace.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DeltaPoint {
    /// Normalised distance round the lap, 0..1.
    pub distance: f32,
    /// Milliseconds behind the reference here. Positive is slower.
    pub delta_ms: i32,
}

/// Time gained and lost against a reference, sampled along the lap.
///
/// [`decompose`] answers "which corner cost me" and this answers "where,
/// exactly" — the racing line coloured by time rather than by speed, which is
/// the first view every driver looks for and the one thing this program could
/// not draw. The arithmetic was already here, inside `decompose`, where nothing
/// else could reach it.
///
/// **Sampled at the lap's own points**, not at a fixed interval. The front end
/// draws the line from those same points, so a delta per point colours a
/// segment each without anybody interpolating twice; a fixed grid would need
/// resampling on the way back out.
///
/// The last point's delta is the lap's own delta, so this and
/// `Decomposition::total_ms` agree by construction rather than by coincidence.
pub fn delta_trace(lap: &[TelemetryPoint], reference: &[TelemetryPoint]) -> Vec<DeltaPoint> {
    if lap.is_empty() || reference.is_empty() {
        return Vec::new();
    }
    lap.iter()
        .filter_map(|point| {
            delta_ms_at(lap, reference, point.distance).map(|delta_ms| DeltaPoint {
                distance: point.distance,
                delta_ms,
            })
        })
        .collect()
}

/// Where each sector line falls on the lap, as normalised distances.
///
/// Built from the splits the game published and the lap the driver actually
/// drove. A split of zero is a sector that was never measured and is skipped
/// rather than drawn at the start line.
pub fn sector_marks(trace: &[TelemetryPoint], sectors: &[i32]) -> Vec<f32> {
    let mut elapsed = 0;
    let mut marks = Vec::with_capacity(sectors.len());
    for split in sectors {
        if *split <= 0 {
            continue;
        }
        elapsed += *split;
        // Only the lines *inside* the lap. The last split ends at the start
        // line, which is where the lap already begins and ends — drawing it
        // would put a sector marker on top of the finish line and claim the
        // track has one more section than it does.
        if let Some(distance) = distance_at(trace, elapsed)
            && (0.001..0.999).contains(&distance)
        {
            marks.push(distance);
        }
    }
    marks
}

/// Interpolated anything at a normalised distance.
fn interpolate<F>(trace: &[TelemetryPoint], distance: f32, get: F) -> Option<f32>
where
    F: Fn(&TelemetryPoint) -> f32,
{
    if trace.is_empty() {
        return None;
    }
    let first = trace.first()?;
    let last = trace.last()?;
    if distance <= first.distance {
        return Some(get(first));
    }
    if distance >= last.distance {
        return Some(get(last));
    }

    // The sample at or after `distance`. `partition_point` needs the trace
    // sorted by distance, which is how the analyser records it.
    let index = trace.partition_point(|point| point.distance < distance);
    let after = trace.get(index)?;
    let before = trace.get(index.saturating_sub(1))?;

    let span = after.distance - before.distance;
    if span <= f32::EPSILON {
        return Some(get(after));
    }
    let factor = ((distance - before.distance) / span).clamp(0.0, 1.0);
    Some(get(before) + factor * (get(after) - get(before)))
}

/// A run of samples that is one corner, before it is measured.
struct Stretch {
    direction: Direction,
    start: usize,
    end: usize,
}

/// Find the corners in one lap's trace, in distance order.
///
/// Returns nothing rather than guessing when the trace is too short to hold a
/// corner — an out-lap cut short, or a lap the recorder only caught the end of.
pub fn detect(trace: &[TelemetryPoint]) -> Vec<Corner> {
    let mut stretches: Vec<Stretch> = Vec::new();
    let mut current: Option<Stretch> = None;

    for (index, point) in trace.iter().enumerate() {
        let magnitude = point.lat_g.abs();
        let direction = if point.lat_g < 0.0 {
            Direction::Left
        } else {
            Direction::Right
        };

        match current.as_mut() {
            // In a corner: it continues while the load stays up and stays the
            // same way round.
            Some(open) if magnitude >= SUSTAIN_G && open.direction == direction => {
                open.end = index;
            }
            Some(_) => {
                // Whatever ended it, the corner is over. A direction change
                // starts the next one on the same sample rather than waiting
                // for the load to build again, which is what makes a chicane
                // two corners that meet.
                if let Some(open) = current.take() {
                    stretches.push(open);
                }
                if magnitude >= ENTER_G {
                    current = Some(Stretch {
                        direction,
                        start: index,
                        end: index,
                    });
                }
            }
            None if magnitude >= ENTER_G => {
                current = Some(Stretch {
                    direction,
                    start: index,
                    end: index,
                });
            }
            None => {}
        }
    }
    if let Some(open) = current.take() {
        stretches.push(open);
    }

    let stretches = merge_and_filter(&stretches, trace);

    stretches
        .iter()
        .enumerate()
        .filter_map(|(index, stretch)| measure(stretch, trace, index + 1))
        .collect()
}

/// Join stretches that are one corner, and drop what is too short to be one.
///
/// Merging happens before the length filter on purpose: a long corner broken
/// into three brief stretches by a crest would otherwise have all three
/// discarded and the corner would vanish entirely.
fn merge_and_filter(stretches: &[Stretch], trace: &[TelemetryPoint]) -> Vec<Stretch> {
    let distance_of = |index: usize| trace.get(index).map(|point| point.distance).unwrap_or(0.0);

    let mut merged: Vec<Stretch> = Vec::new();
    for stretch in stretches {
        let joined = merged.last_mut().is_some_and(|previous| {
            previous.direction == stretch.direction
                && distance_of(stretch.start) - distance_of(previous.end) < MERGE_GAP
        });
        if joined {
            if let Some(previous) = merged.last_mut() {
                previous.end = stretch.end;
            }
        } else {
            merged.push(Stretch {
                direction: stretch.direction,
                start: stretch.start,
                end: stretch.end,
            });
        }
    }

    merged.retain(|stretch| distance_of(stretch.end) - distance_of(stretch.start) >= MIN_LENGTH);
    merged
}

/// Measure one stretch into a [`Corner`].
fn measure(stretch: &Stretch, trace: &[TelemetryPoint], number: usize) -> Option<Corner> {
    let samples = trace.get(stretch.start..=stretch.end)?;
    let first = samples.first()?;
    let last = samples.last()?;

    // The apex is the slowest point, not the tightest: it is the timing that
    // this is for, and the slowest point is where the lap time is decided.
    let slowest = samples.iter().min_by(|a, b| {
        a.speed
            .partial_cmp(&b.speed)
            .unwrap_or(std::cmp::Ordering::Equal)
    })?;

    let peak_lat_g = samples
        .iter()
        .map(|point| point.lat_g.abs())
        .fold(0.0f32, f32::max);

    let throttle = throttle_point(trace, slowest.distance, last.distance);
    let throttle_delay_ms =
        throttle.and_then(|point| Some(time_at(trace, point)? - time_at(trace, slowest.distance)?));

    let brake_point = brake_point(trace, stretch.start, slowest.distance);

    Some(Corner {
        number,
        direction: stretch.direction,
        entry: first.distance,
        apex: slowest.distance,
        exit: last.distance,
        entry_speed: first.speed,
        min_speed: slowest.speed,
        exit_speed: last.speed,
        peak_lat_g,
        brake_point,
        braking: brake_point.and_then(|start| braking(trace, start, slowest.distance)),
        throttle_point: throttle,
        throttle_delay_ms,
        entry_time_ms: first.time_ms,
        exit_time_ms: last.time_ms,
    })
}

/// Where the braking for this corner started.
///
/// Looked for behind the corner as well as inside it, because braking for a
/// corner happens on the straight before it — which is exactly the number a
/// driver wants when they are asking whether they braked too early.
fn brake_point(trace: &[TelemetryPoint], entry_index: usize, apex: f32) -> Option<f32> {
    let entry_distance = trace.get(entry_index)?.distance;
    let earliest = entry_distance - BRAKE_LOOKBACK;

    // The *last* braking application before the apex, not the first: a driver
    // who brushed the brakes 200 m earlier and then lifted has not started
    // braking for this corner there. Tracked as runs rather than by clearing on
    // release, because on most corners the driver comes off the brakes exactly
    // at the point this is trying to measure — clearing there threw away the
    // only answer and reported a braked corner as taken flat.
    let mut open: Option<f32> = None;
    let mut last_finished: Option<f32> = None;

    for point in trace.iter() {
        if point.distance < earliest {
            continue;
        }
        if point.distance > apex {
            break;
        }
        if point.brake > BRAKE_ON {
            if open.is_none() {
                open = Some(point.distance);
            }
        } else if let Some(start) = open.take() {
            last_finished = Some(start);
        }
    }

    // Still on the brakes at the apex is trail braking, and that run is the
    // one; otherwise the most recent finished one.
    open.or(last_finished)
}

/// Measure the braking that started at `start` and ended by the apex.
///
/// The run is walked once. Everything reported comes off samples inside it —
/// nothing is inferred from the speed at the ends, because a car that was
/// already slowing before the pedal moved would then be credited to the
/// braking.
fn braking(trace: &[TelemetryPoint], start: f32, apex: f32) -> Option<Braking> {
    let mut peak_pressure = 0.0f32;
    let mut peak_pressure_at: Option<i32> = None;
    let mut strongest_decel = 0.0f32;
    let mut entry_speed = None;
    let mut last_on: Option<&TelemetryPoint> = None;
    let mut release: Option<&TelemetryPoint> = None;

    for point in trace.iter() {
        if point.distance < start {
            continue;
        }
        if point.distance > apex {
            break;
        }
        if point.brake > BRAKE_ON {
            if entry_speed.is_none() {
                entry_speed = Some(point.speed);
            }
            // The peak only grows, so "still at the peak" is a comparison
            // against it with a tolerance — a pedal held down does not report
            // the same float twice.
            if point.brake > peak_pressure {
                peak_pressure = point.brake;
                peak_pressure_at = Some(point.time_ms);
            } else if point.brake >= peak_pressure - AT_PEAK {
                peak_pressure_at = Some(point.time_ms);
            }
            // Braking is negative longitudinal g; the magnitude is what gets
            // reported, the same way `LapData::peak_brake_g` does it.
            strongest_decel = strongest_decel.max(-point.lon_g);
            last_on = Some(point);
            release = None;
        } else if last_on.is_some() && release.is_none() {
            release = Some(point);
        }
    }

    let first_on_speed = entry_speed?;
    let last_on = last_on?;
    // Off the brakes before the apex, or still on them at it. The second is
    // trail braking all the way in, and the apex is where the measurement ends
    // rather than where the driver released.
    let ended = release.unwrap_or(last_on);

    let start_time = time_at(trace, start)?;
    Some(Braking {
        start,
        release: ended.distance,
        duration_ms: (ended.time_ms - start_time).max(0),
        peak_decel_g: strongest_decel.max(0.0),
        peak_pressure,
        release_ms: peak_pressure_at
            .map(|at| (ended.time_ms - at).max(0))
            .unwrap_or(0),
        entry_speed: first_on_speed,
        release_speed: ended.speed,
    })
}

/// Where the driver got back to real throttle after the apex.
fn throttle_point(trace: &[TelemetryPoint], apex: f32, exit: f32) -> Option<f32> {
    trace
        .iter()
        .find(|point| point.distance >= apex && point.distance <= exit && point.gas >= THROTTLE_ON)
        .map(|point| point.distance)
}

/// Two corners believed to be the same corner of the same track.
#[derive(Debug, Clone)]
pub struct CornerComparison {
    pub corner: Corner,
    /// The same corner in the reference lap. `None` when the reference has no
    /// corner at this distance, which is not a delta of zero and not a large
    /// delta — it is no answer, and is drawn as one.
    pub reference: Option<Corner>,
    /// Time lost or gained in this corner's section, in milliseconds. Positive
    /// is slower than the reference.
    pub delta_ms: i32,
}

impl CornerComparison {
    /// How much later the brakes came on than in the reference, in metres.
    ///
    /// Positive is later — deeper into the corner. `None` when either lap was
    /// flat through here, or the track's length is not known, since "14 m
    /// later" needs a track to be metres of.
    pub fn braking_delta_m(&self, track_length_m: f32) -> Option<f32> {
        if track_length_m <= 0.0 {
            return None;
        }
        let mine = self.corner.brake_point?;
        let theirs = self.reference.as_ref()?.brake_point?;
        Some((mine - theirs) * track_length_m)
    }

    /// How much harder the car was stopped than in the reference, in g.
    ///
    /// Positive is harder. `None` when either lap was flat here — which is not
    /// a difference of zero, and is drawn as no answer.
    pub fn peak_decel_delta_g(&self) -> Option<f32> {
        let mine = self.corner.braking?.peak_decel_g;
        let theirs = self.reference.as_ref()?.braking?.peak_decel_g;
        Some(mine - theirs)
    }

    /// How much longer the braking zone was than the reference's, in metres.
    ///
    /// Positive is longer — more track spent slowing down. Read beside
    /// [`CornerComparison::braking_delta_m`]: braking later *and* over a
    /// shorter distance is a driver stopping the car harder, and braking later
    /// over the same distance is one carrying the speed further in.
    pub fn braking_distance_delta_m(&self, track_length_m: f32) -> Option<f32> {
        let mine = self.corner.braking?.distance_m(track_length_m)?;
        let theirs = self
            .reference
            .as_ref()?
            .braking?
            .distance_m(track_length_m)?;
        Some(mine - theirs)
    }

    /// How much longer the driver stayed on the pedal after the hardest press,
    /// in milliseconds. Positive is a longer trail.
    pub fn trail_delta_ms(&self) -> Option<i32> {
        let mine = self.corner.braking?.release_ms;
        let theirs = self.reference.as_ref()?.braking?.release_ms;
        Some(mine - theirs)
    }

    /// How much later the driver got back on the throttle than in the
    /// reference, in seconds. Positive is later.
    ///
    /// `None` unless both laps got to real throttle inside the corner: a lap
    /// that never did has no delay to be later than, and calling that "0.00 s"
    /// would read as the two being identical.
    pub fn throttle_delta_s(&self) -> Option<f32> {
        let mine = self.corner.throttle_delay_s()?;
        let theirs = self.reference.as_ref()?.throttle_delay_s()?;
        Some(mine - theirs)
    }

    /// Where inside the corner the time went: braking, turning, and getting
    /// out of it.
    ///
    /// **A section's delta says how much; this says where.** "T7 cost you
    /// 0.28" sends a driver to a corner. "0.19 of it was between the apex and
    /// the exit" sends them to the throttle, which is a thing they can change
    /// on the next lap.
    ///
    /// The three add up to the section's own delta by construction, because
    /// they are the same clock read at four places: this corner's entry, its
    /// apex, its exit, and where the next one begins. The last of those is why
    /// "exit" is worth the most on most corners — the straight that follows is
    /// charged here, which is where a bad exit is actually paid for.
    ///
    /// `None` when the reference has no corner here, or when either trace does
    /// not reach the distances involved. Not a zero: a corner the reference
    /// never drove is no comparison at all.
    pub fn inside(
        &self,
        lap: &[TelemetryPoint],
        reference: &[TelemetryPoint],
        section_end: f32,
    ) -> Option<Inside> {
        let theirs = self.reference.as_ref()?;
        // How far behind the reference this lap is at one place on the track.
        let behind = |mine: f32, theirs: f32| -> Option<i32> {
            Some(time_at(lap, mine)? - time_at(reference, theirs)?)
        };

        let at_entry = behind(self.corner.entry, theirs.entry)?;
        let at_apex = behind(self.corner.apex, theirs.apex)?;
        let at_exit = behind(self.corner.exit, theirs.exit)?;
        let at_end = behind(section_end, section_end)?;

        Some(Inside {
            braking_ms: at_apex - at_entry,
            turning_ms: at_exit - at_apex,
            exit_ms: at_end - at_exit,
        })
    }

    /// Entry, minimum and exit speed against the reference, in km/h.
    pub fn speed_deltas(&self) -> Option<(f32, f32, f32)> {
        let reference = self.reference.as_ref()?;
        Some((
            self.corner.entry_speed - reference.entry_speed,
            self.corner.min_speed - reference.min_speed,
            self.corner.exit_speed - reference.exit_speed,
        ))
    }
}

/// A corner's delta split into the three things a driver does in one.
///
/// Positive is slower than the reference, everywhere, and the three sum to the
/// section's delta.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Inside {
    /// Entry to apex: how the car was slowed and how late.
    pub braking_ms: i32,
    /// Apex to exit: how much speed was carried through the middle.
    pub turning_ms: i32,
    /// Exit to the next corner: getting back on the power, and the straight
    /// that follows, which is where a bad exit is paid for.
    pub exit_ms: i32,
}

impl Inside {
    /// The whole corner, which is what the section's delta already said.
    pub fn total_ms(&self) -> i32 {
        self.braking_ms + self.turning_ms + self.exit_ms
    }

    /// The part that cost the most, and what it cost — when one of them
    /// clearly did.
    ///
    /// **Only when it is worth a sentence.** A corner losing four hundredths
    /// spread evenly over three phases has no culprit, and naming one would be
    /// reading noise aloud.
    pub fn worst(&self) -> Option<(&'static str, i32)> {
        let parts = [
            ("braking", self.braking_ms),
            ("through the middle", self.turning_ms),
            ("on the exit", self.exit_ms),
        ];
        let worst = parts.iter().max_by_key(|part| part.1)?;
        // Half of the corner's own loss, so "it was the exit" means the exit
        // and not "the exit plus two other thirds".
        let total = self.total_ms().max(1);
        (worst.1 >= 50 && worst.1 * 2 >= total).then_some(*worst)
    }
}

/// Where a lap's time went, corner by corner.
#[derive(Debug, Clone, Default)]
pub struct Decomposition {
    pub sections: Vec<CornerComparison>,
    /// The run from the line to the first corner, which belongs to no corner
    /// and is still time. Positive is slower.
    pub opening_ms: i32,
    /// The whole lap's delta, in milliseconds. The sections and the opening sum
    /// to this by construction — see the note in [`decompose`].
    pub total_ms: i32,
}

impl Decomposition {
    /// Only the corners that cost more than `threshold` seconds.
    ///
    /// This filter is the point of the whole decomposition. Twenty corners with
    /// a number beside each is another table to read; three corners that cost a
    /// tenth each is where to go and work. Sorted worst first.
    pub fn losses_over(&self, threshold_s: f32) -> Vec<&CornerComparison> {
        let threshold_ms = (threshold_s * 1000.0) as i32;
        let mut worst: Vec<&CornerComparison> = self
            .sections
            .iter()
            .filter(|section| section.delta_ms > threshold_ms)
            .collect();
        // Negated rather than reversed, so corners costing the same time keep
        // the order they are driven in.
        worst.sort_by_key(|section| -section.delta_ms);
        worst
    }
}

/// Match this lap's corners to a reference lap's and say where the time went.
///
/// Each corner owns the track from its own entry to the next corner's entry, so
/// the straight after a corner is charged to the corner that led onto it —
/// which is where a bad exit is actually paid for. Sections therefore tile the
/// lap, and their deltas plus the opening add up to the lap's own delta rather
/// than to some other number the reader has to reconcile.
pub fn decompose(
    lap: &[TelemetryPoint],
    reference: &[TelemetryPoint],
    corners: &[Corner],
    reference_corners: &[Corner],
) -> Decomposition {
    if lap.is_empty() || reference.is_empty() {
        return Decomposition::default();
    }

    // Time lost by a given distance: how far behind the reference this lap is
    // at that point on the track.
    let behind_at = |distance: f32| -> i32 {
        let mine = time_at(lap, distance).unwrap_or(0);
        let theirs = time_at(reference, distance).unwrap_or(0);
        mine - theirs
    };

    let mut sections = Vec::with_capacity(corners.len());
    for (index, corner) in corners.iter().enumerate() {
        // To the next corner's entry, or to the line.
        let section_end = corners
            .get(index + 1)
            .map(|next| next.entry)
            .unwrap_or(f32::MAX);

        sections.push(CornerComparison {
            reference: match_corner(corner, reference_corners),
            delta_ms: behind_at(section_end) - behind_at(corner.entry),
            corner: corner.clone(),
        });
    }

    let opening_ms = corners
        .first()
        .map(|first| behind_at(first.entry))
        .unwrap_or(0);

    Decomposition {
        total_ms: behind_at(f32::MAX),
        sections,
        opening_ms,
    }
}

/// The reference lap's corner at the same place on the track, if it has one.
///
/// Nearest apex within [`MATCH_WINDOW`], and the directions have to agree: two
/// corners that close together going opposite ways are a chicane, and matching
/// its left to its right would report the difference between two different
/// corners as a driver's mistake.
fn match_corner(corner: &Corner, candidates: &[Corner]) -> Option<Corner> {
    candidates
        .iter()
        .filter(|candidate| candidate.direction == corner.direction)
        .filter(|candidate| (candidate.apex - corner.apex).abs() <= MATCH_WINDOW)
        .min_by(|a, b| {
            (a.apex - corner.apex)
                .abs()
                .partial_cmp(&(b.apex - corner.apex).abs())
                .unwrap_or(std::cmp::Ordering::Equal)
        })
        .cloned()
}

#[cfg(test)]
mod tests {

    /// The inverse has to land where the original came from, or a sector line
    /// is drawn at a place the driver never was.
    #[test]
    fn a_time_maps_back_to_the_distance_it_came_from() {
        let trace: Vec<TelemetryPoint> = (0..=100)
            .map(|step| {
                let at = step as f32 / 100.0;
                TelemetryPoint {
                    distance: at,
                    time_ms: (at * 90_000.0) as i32,
                    speed: 180.0,
                    gas: 1.0,
                    brake: 0.0,
                    gear: 5,
                    steer: 0.0,
                    lat_g: 0.0,
                    lon_g: 0.0,
                    slip_avg: 0.0,
                    x: at,
                    y: at,
                    rpms: 7_000,
                    detail: Default::default(),
                }
            })
            .collect();

        for probe in [0.25_f32, 0.5, 0.75] {
            let time = time_at(&trace, probe).expect("a time inside the lap");
            let back = distance_at(&trace, time).expect("a distance inside the lap");
            assert!(
                (back - probe).abs() < 0.01,
                "{probe} came back as {back} through {time} ms"
            );
        }
    }

    /// A split of zero is a sector nobody measured, and there is no line for
    /// it — and the last split ends on the finish line, which is not a sector
    /// marker.
    #[test]
    fn an_unmeasured_split_draws_no_sector_line() {
        let trace: Vec<TelemetryPoint> = (0..=100)
            .map(|step| {
                let at = step as f32 / 100.0;
                TelemetryPoint {
                    distance: at,
                    time_ms: (at * 90_000.0) as i32,
                    speed: 180.0,
                    gas: 1.0,
                    brake: 0.0,
                    gear: 5,
                    steer: 0.0,
                    lat_g: 0.0,
                    lon_g: 0.0,
                    slip_avg: 0.0,
                    x: at,
                    y: at,
                    rpms: 7_000,
                    detail: Default::default(),
                }
            })
            .collect();

        assert_eq!(sector_marks(&trace, &[0, 0, 0]).len(), 0);
        assert_eq!(sector_marks(&trace, &[30_000, 30_000, 30_000]).len(), 2);
    }
    use super::*;

    /// A braking zone built to known numbers: on the brakes from 0.270 to
    /// 0.300 of the lap, at 0.9 of the pedal until 0.285 and 0.4 after it, and
    /// 1.2 g at its strongest. Inside `BRAKE_LOOKBACK` of the corner on
    /// purpose — a zone further back than that is one `brake_point` will not
    /// look for, which is its own behaviour and has its own test.
    fn trace_with_a_braking_zone() -> Vec<TelemetryPoint> {
        (0..1000)
            .map(|index| {
                let distance = index as f32 / 1000.0;
                let braking = (0.270..0.300).contains(&distance);
                let cornering = (0.300..0.360).contains(&distance);
                // Hardest in the middle of the zone, rolled off into the apex.
                let pressure = if braking {
                    // Hard, then rolled off into the apex — the trail.
                    if distance < 0.285 { 0.9 } else { 0.4 }
                } else {
                    0.0
                };
                TelemetryPoint {
                    distance,
                    time_ms: index * 100,
                    speed: if braking {
                        200.0 - (distance - 0.270) * 1000.0
                    } else if cornering {
                        100.0
                    } else {
                        200.0
                    },
                    gas: if braking || cornering { 0.0 } else { 1.0 },
                    brake: pressure,
                    gear: 4,
                    steer: 0.0,
                    lat_g: if cornering { 1.4 } else { 0.0 },
                    lon_g: if braking { -1.2 } else { 0.0 },
                    slip_avg: 0.0,
                    x: 0.0,
                    y: 0.0,
                    rpms: 7000,
                    detail: Default::default(),
                }
            })
            .collect()
    }

    #[test]
    fn a_braking_zone_is_measured_where_it_was_driven() {
        let trace = trace_with_a_braking_zone();
        let corner = detect(&trace).into_iter().next().expect("one corner");
        let braking = corner.braking.expect("the corner was braked for");

        assert!(
            (braking.start - 0.270).abs() < 0.005,
            "started at {}",
            braking.start
        );
        assert!(
            (braking.release - 0.300).abs() < 0.005,
            "released at {}",
            braking.release
        );
        assert!(
            (braking.peak_decel_g - 1.2).abs() < 0.01,
            "peak was {} g",
            braking.peak_decel_g
        );
        assert!(
            (braking.peak_pressure - 0.9).abs() < 0.01,
            "peak pressure was {}",
            braking.peak_pressure
        );
        // Three per cent of a 100-second lap.
        assert!(
            (braking.duration_ms - 3_000).abs() <= 200,
            "lasted {} ms",
            braking.duration_ms
        );
    }

    /// Deceleration is negative longitudinal g in the trace and positive
    /// everywhere a person reads it. Getting that backwards reports every
    /// braking zone as 0.0 g, which looks like a car that never brakes.
    #[test]
    fn deceleration_is_reported_the_way_a_driver_reads_it() {
        let trace = trace_with_a_braking_zone();
        let corner = detect(&trace).into_iter().next().expect("one corner");
        assert!(corner.braking.expect("braking").peak_decel_g > 0.0);
    }

    /// The trail: from leaving peak pressure to coming off the pedal. Here the
    /// pressure drops at 0.285 and the brakes come off at 0.300 — 1.5 per cent
    /// of a 100-second lap, and half the zone rather than all of it.
    #[test]
    fn the_trail_is_measured_from_the_hardest_press() {
        let trace = trace_with_a_braking_zone();
        let corner = detect(&trace).into_iter().next().expect("one corner");
        let braking = corner.braking.expect("braking");
        assert!(
            (braking.release_ms - 1_500).abs() <= 200,
            "the pedal left peak pressure at 0.285 and came off at 0.300, so \
             the trail is half the zone and not all of it; got {} ms",
            braking.release_ms
        );
    }

    /// A corner nobody braked for has no braking, which is not a braking of
    /// zero — the difference is the whole of what this project is about.
    #[test]
    fn a_corner_taken_flat_has_no_braking_rather_than_an_empty_one() {
        let flat = trace_with_corners(&[(0.30, 0.36, 1.0)]);
        let flat: Vec<TelemetryPoint> = flat
            .into_iter()
            .map(|mut point| {
                point.brake = 0.0;
                point
            })
            .collect();
        let corner = detect(&flat).into_iter().next().expect("one corner");
        assert!(corner.brake_point.is_none());
        assert!(corner.braking.is_none());
    }

    /// A lap saved before any of this existed still loads, with no braking on
    /// its corners rather than a parse error.
    #[test]
    fn a_corner_from_an_older_release_still_deserialises() {
        let older = r#"{
            "number": 1, "direction": "Left",
            "entry": 0.3, "apex": 0.32, "exit": 0.36,
            "entry_speed": 200.0, "min_speed": 100.0, "exit_speed": 150.0,
            "peak_lat_g": 1.4, "brake_point": 0.24, "throttle_point": 0.33,
            "throttle_delay_ms": 100, "entry_time_ms": 30000, "exit_time_ms": 36000
        }"#;
        let corner: Corner = serde_json::from_str(older).expect("an older corner still loads");
        assert!(corner.braking.is_none());
    }

    /// A lap against itself is a flat zero everywhere. Trivial, and it is the
    /// test that catches a sign flipped or an off-by-one in the interpolation
    /// — both of which draw a plausible-looking coloured line.
    #[test]
    fn a_lap_against_itself_gained_nothing_anywhere() {
        let lap = trace_with_corners(&[(0.30, 0.36, 1.4)]);
        let deltas = delta_trace(&lap, &lap);

        assert_eq!(deltas.len(), lap.len());
        assert!(
            deltas.iter().all(|point| point.delta_ms == 0),
            "a lap is not slower than itself anywhere"
        );
    }

    /// **The agreement that matters.** The decomposition charges each corner a
    /// share of the lap's delta; this samples the same delta along the lap. If
    /// the two disagree the driver is shown a coloured line saying one thing
    /// and a table saying another, and neither can be trusted after that.
    #[test]
    fn the_last_delta_is_the_lap_delta_the_decomposition_reports() {
        let reference = trace_with_corners(&[(0.30, 0.36, 1.4)]);
        // The same lap, two seconds slower by the end: every sample after the
        // corner carries the loss.
        let lap: Vec<TelemetryPoint> = reference
            .iter()
            .map(|point| {
                let mut slower = point.clone();
                if point.distance > 0.30 {
                    slower.time_ms += 2_000;
                }
                slower
            })
            .collect();

        let corners = detect(&lap);
        let reference_corners = detect(&reference);
        let decomposition = decompose(&lap, &reference, &corners, &reference_corners);
        let deltas = delta_trace(&lap, &reference);

        let last = deltas.last().expect("a lap that was driven has a delta");
        assert_eq!(last.delta_ms, decomposition.total_ms);
        assert_eq!(last.delta_ms, 2_000);
    }

    /// Withheld, not clamped: where the reference has nothing to compare
    /// against there is no delta, and drawing zero there would colour that
    /// stretch as "exactly on the reference".
    #[test]
    fn a_stretch_the_reference_never_covered_has_no_delta() {
        let lap = trace_with_corners(&[(0.30, 0.36, 1.4)]);
        // A reference that only covers the second half of the lap.
        let reference: Vec<TelemetryPoint> = lap
            .iter()
            .filter(|point| point.distance >= 0.5)
            .cloned()
            .collect();

        let deltas = delta_trace(&lap, &reference);

        assert!(delta_ms_at(&lap, &reference, 0.10).is_none());
        assert!(
            deltas.iter().all(|point| point.distance >= 0.5),
            "the uncovered half was given a delta anyway"
        );
        assert!(!deltas.is_empty(), "the covered half still has one");
    }

    /// A trace with one corner in it: straight, sustained lateral load, straight.
    fn trace_with_corners(corners: &[(f32, f32, f32)]) -> Vec<TelemetryPoint> {
        // 1000 samples over the lap, 100 ms apart — a 100-second lap.
        (0..1000)
            .map(|index| {
                let distance = index as f32 / 1000.0;
                let mut lat_g = 0.0;
                let mut speed = 200.0;
                let mut brake = 0.0;
                let mut gas = 1.0;
                for (start, end, g) in corners {
                    if distance >= *start && distance <= *end {
                        lat_g = *g;
                        speed = 100.0;
                        gas = 0.0;
                    }
                    // Braking for 2% of the lap before each corner.
                    if distance >= start - 0.02 && distance < *start {
                        brake = 1.0;
                        gas = 0.0;
                        speed = 150.0;
                    }
                }
                TelemetryPoint {
                    distance,
                    time_ms: index * 100,
                    speed,
                    gas,
                    brake,
                    gear: 4,
                    steer: 0.0,
                    lat_g,
                    lon_g: 0.0,
                    slip_avg: 0.0,
                    x: 0.0,
                    y: 0.0,
                    rpms: 7000,
                    detail: Default::default(),
                }
            })
            .collect()
    }

    #[test]
    fn a_straight_has_no_corners() {
        let trace = trace_with_corners(&[]);
        assert!(detect(&trace).is_empty());
    }

    #[test]
    fn one_sustained_load_is_one_corner() {
        let trace = trace_with_corners(&[(0.20, 0.25, 1.2)]);
        let corners = detect(&trace);

        assert_eq!(corners.len(), 1, "{corners:?}");
        let corner = &corners[0];
        assert_eq!(corner.number, 1);
        assert_eq!(
            corner.direction,
            Direction::Right,
            "positive lat_g is right"
        );
        assert!((corner.entry - 0.20).abs() < 0.01, "{}", corner.entry);
        assert!((corner.min_speed - 100.0).abs() < 1.0);
    }

    /// The trap the module is written around: a kerb or a bump is not a corner,
    /// and calling one "T4" pushes the number of every corner after it.
    #[test]
    fn a_brief_flick_is_not_a_corner() {
        // Two samples of load — 0.2% of the lap, under MIN_LENGTH.
        let trace = trace_with_corners(&[(0.20, 0.201, 1.2)]);
        assert!(detect(&trace).is_empty(), "{:?}", detect(&trace));
    }

    /// Left then right is a chicane: two corners, however close together.
    #[test]
    fn a_direction_change_is_never_merged() {
        let trace = trace_with_corners(&[(0.20, 0.25, 1.2), (0.2505, 0.30, -1.2)]);
        let corners = detect(&trace);

        assert_eq!(corners.len(), 2, "{corners:?}");
        assert_eq!(corners[0].direction, Direction::Right);
        assert_eq!(corners[1].direction, Direction::Left);
        assert_eq!(corners[1].number, 2, "numbered in distance order");
    }

    /// A long corner that unloads over a crest is still one corner.
    #[test]
    fn a_momentary_unload_does_not_split_a_corner() {
        let mut trace = trace_with_corners(&[(0.20, 0.30, 1.2)]);
        // One sample in the middle with no load at all, as a crest would give.
        if let Some(point) = trace.get_mut(250) {
            point.lat_g = 0.0;
        }

        let corners = detect(&trace);
        assert_eq!(
            corners.len(),
            1,
            "one crest is not two corners: {corners:?}"
        );
    }

    #[test]
    fn the_braking_point_is_found_on_the_straight_before() {
        let trace = trace_with_corners(&[(0.30, 0.35, 1.2)]);
        let corners = detect(&trace);

        let brake = corners[0].brake_point.expect("the corner was braked for");
        assert!(
            (brake - 0.28).abs() < 0.005,
            "braking starts 2% of a lap before the corner, found {brake}"
        );
    }

    #[test]
    fn a_corner_taken_flat_has_no_braking_point() {
        // Load, but the synthetic trace only brakes before a corner it knows
        // about — so build one by hand with no brake at all.
        let mut trace = trace_with_corners(&[(0.30, 0.35, 1.2)]);
        for point in trace.iter_mut() {
            point.brake = 0.0;
        }

        let corners = detect(&trace);
        assert_eq!(corners[0].brake_point, None);
    }

    /// The reason everything here is keyed by distance. A reference lap that
    /// detected an extra corner must not shift every later comparison by one.
    #[test]
    fn corners_match_by_distance_and_not_by_index() {
        let mine = detect(&trace_with_corners(&[(0.50, 0.55, 1.2)]));
        // The reference found a corner earlier in the lap that this lap did
        // not — so by index, its T2 is my T1.
        let theirs = detect(&trace_with_corners(&[(0.10, 0.15, 1.2), (0.50, 0.55, 1.2)]));

        assert_eq!(mine.len(), 1);
        assert_eq!(theirs.len(), 2);

        let matched = match_corner(&mine[0], &theirs).expect("same corner, same place");
        assert!(
            (matched.apex - 0.50).abs() < 0.02,
            "matched the corner at the same distance, not the one with the same index: {matched:?}"
        );
    }

    /// Every degenerate trace this can be handed, in one place. All of these
    /// reach code that indexes and slices, and a panic here takes down a
    /// terminal that is drawing sixty times a second — a lap the recorder
    /// caught two samples of is not a reason to lose the session.
    #[test]
    fn nothing_here_panics_on_a_trace_that_is_not_a_lap() {
        let empty: Vec<TelemetryPoint> = Vec::new();
        assert!(detect(&empty).is_empty());
        assert_eq!(time_at(&empty, 0.5), None);

        let full = trace_with_corners(&[(0.20, 0.25, 1.2)]);
        let one = full.get(..1).map(<[_]>::to_vec).unwrap_or_default();
        assert!(detect(&one).is_empty(), "one sample is not a corner");
        assert!(time_at(&one, 0.5).is_some(), "clamped to the only sample");

        // A lap against nothing, and nothing against a lap.
        let corners = detect(&full);
        assert_eq!(
            decompose(&full, &empty, &corners, &[]).sections.len(),
            0,
            "there is no reference to decompose against"
        );
        assert_eq!(decompose(&empty, &full, &[], &corners).total_ms, 0);

        // A corner that runs to the very last sample, so `measure` slices to
        // the end of the trace.
        let to_the_line = trace_with_corners(&[(0.90, 1.10, 1.2)]);
        let found = detect(&to_the_line);
        assert_eq!(found.len(), 1, "{found:?}");
        assert!(found[0].exit <= 1.0);
    }

    /// AC has published a NaN into the physics page before now. A comparison
    /// against NaN is always false, so it must fall out as "not cornering"
    /// rather than opening a corner that never closes.
    #[test]
    fn a_nan_in_the_trace_is_not_a_corner() {
        let mut trace = trace_with_corners(&[]);
        for point in trace.iter_mut().skip(100).take(50) {
            point.lat_g = f32::NAN;
        }
        assert!(detect(&trace).is_empty(), "{:?}", detect(&trace));
    }

    #[test]
    fn a_corner_the_reference_does_not_have_is_no_comparison() {
        let mine = detect(&trace_with_corners(&[(0.50, 0.55, 1.2)]));
        let theirs = detect(&trace_with_corners(&[(0.10, 0.15, 1.2)]));

        assert_eq!(match_corner(&mine[0], &theirs), None);
    }

    /// A chicane's left must not match its right.
    #[test]
    fn a_matching_corner_has_to_go_the_same_way() {
        let mine = detect(&trace_with_corners(&[(0.20, 0.25, 1.2)]));
        let theirs = detect(&trace_with_corners(&[(0.20, 0.25, -1.2)]));

        assert_eq!(mine.len(), 1);
        assert_eq!(theirs.len(), 1);
        assert_eq!(match_corner(&mine[0], &theirs), None);
    }

    /// The decomposition has to add up, or it is a set of numbers rather than
    /// an account of the lap.
    #[test]
    fn the_sections_and_the_opening_sum_to_the_lap_delta() {
        let mine = trace_with_corners(&[(0.20, 0.25, 1.2), (0.60, 0.65, -1.2)]);
        // The reference is the same lap driven 5 s quicker, spread evenly.
        let theirs: Vec<TelemetryPoint> = mine
            .iter()
            .map(|point| TelemetryPoint {
                time_ms: (point.time_ms as f32 * 0.95) as i32,
                ..point.clone()
            })
            .collect();

        let my_corners = detect(&mine);
        let their_corners = detect(&theirs);
        let decomposition = decompose(&mine, &theirs, &my_corners, &their_corners);

        let summed: i32 = decomposition.opening_ms
            + decomposition
                .sections
                .iter()
                .map(|section| section.delta_ms)
                .sum::<i32>();

        assert_eq!(
            summed, decomposition.total_ms,
            "the parts have to account for the whole: {decomposition:?}"
        );
        assert!(
            decomposition.total_ms > 0,
            "this lap is the slower one: {}",
            decomposition.total_ms
        );
    }

    /// The filter is the feature: what it hides is the value.
    #[test]
    fn only_the_corners_that_cost_real_time_are_reported() {
        let decomposition = Decomposition {
            sections: vec![
                comparison(1, 180),
                comparison(2, 20),
                comparison(3, -140),
                comparison(4, 350),
            ],
            opening_ms: 0,
            total_ms: 410,
        };

        let worst = decomposition.losses_over(0.10);
        assert_eq!(worst.len(), 2, "two corners cost more than a tenth");
        assert_eq!(worst[0].corner.number, 4, "worst first");
        assert_eq!(worst[1].corner.number, 1);
    }

    fn comparison(number: usize, delta_ms: i32) -> CornerComparison {
        CornerComparison {
            corner: Corner {
                number,
                direction: Direction::Left,
                entry: 0.0,
                apex: 0.0,
                exit: 0.0,
                entry_speed: 0.0,
                min_speed: 0.0,
                exit_speed: 0.0,
                peak_lat_g: 0.0,
                brake_point: None,
                braking: None,
                throttle_point: None,
                throttle_delay_ms: None,
                entry_time_ms: 0,
                exit_time_ms: 0,
            },
            reference: None,
            delta_ms,
        }
    }

    /// A lap that never got back on the power has no delay to be later than.
    #[test]
    fn a_throttle_delta_needs_both_laps_to_have_one() {
        let mut pair = comparison(1, 0);
        pair.corner.throttle_delay_ms = Some(800);
        pair.reference = Some(pair.corner.clone());

        assert_eq!(pair.throttle_delta_s(), Some(0.0));

        if let Some(reference) = pair.reference.as_mut() {
            reference.throttle_delay_ms = Some(600);
        }
        let delta = pair.throttle_delta_s().expect("both laps got to throttle");
        assert!((delta - 0.2).abs() < 0.001, "{delta}");

        pair.corner.throttle_delay_ms = None;
        assert_eq!(
            pair.throttle_delta_s(),
            None,
            "never on the power is not the same as on it at the same moment"
        );
    }

    #[test]
    fn braking_in_metres_needs_a_track_to_be_metres_of() {
        let mut pair = comparison(1, 0);
        pair.corner.brake_point = Some(0.300);
        pair.reference = Some(pair.corner.clone());
        if let Some(reference) = pair.reference.as_mut() {
            reference.brake_point = Some(0.297);
        }

        // 5000 m track, 0.003 of a lap later on the brakes: 15 m.
        let metres = pair.braking_delta_m(5000.0).expect("both laps braked");
        assert!((metres - 15.0).abs() < 0.1, "{metres}");

        assert_eq!(
            pair.braking_delta_m(0.0),
            None,
            "an unknown track length is not a delta of zero"
        );
    }

    #[test]
    fn time_at_interpolates_between_samples() {
        let trace = trace_with_corners(&[]);
        // Halfway between sample 10 (1000 ms) and sample 11 (1100 ms).
        let time = time_at(&trace, 0.0105).expect("inside the trace");
        assert!((time - 1050).abs() <= 1, "{time}");
    }

    /// The three parts of a corner's loss add up to the corner's own loss, and
    /// the one that cost the most is named.
    #[test]
    fn where_inside_the_corner_the_time_went() {
        // A reference lap at an even second per tenth of a lap, and a lap that
        // loses two tenths between the apex and the exit and nowhere else.
        let reference: Vec<TelemetryPoint> = (0..=10)
            .map(|step| point(step as f32 / 10.0, step * 1_000, 200.0))
            .collect();
        let mine: Vec<TelemetryPoint> = (0..=10)
            .map(|step| {
                let late = if step >= 5 { 200 } else { 0 };
                point(step as f32 / 10.0, step * 1_000 + late, 200.0)
            })
            .collect();

        let comparison = CornerComparison {
            corner: Corner {
                entry: 0.3,
                apex: 0.4,
                exit: 0.6,
                ..bare_corner()
            },
            reference: Some(Corner {
                entry: 0.3,
                apex: 0.4,
                exit: 0.6,
                ..bare_corner()
            }),
            delta_ms: 200,
        };

        let inside = comparison
            .inside(&mine, &reference, 0.8)
            .expect("both laps reach these distances");
        assert_eq!(inside.total_ms(), 200, "the parts sum to the corner's loss");
        assert_eq!(inside.braking_ms, 0, "nothing was lost before the apex");
        assert_eq!(inside.turning_ms, 200, "it all went between apex and exit");
        assert_eq!(inside.exit_ms, 0);
        assert_eq!(inside.worst(), Some(("through the middle", 200)));
    }

    /// A corner with no culprit is not given one.
    #[test]
    fn a_loss_spread_evenly_has_no_culprit() {
        let inside = Inside {
            braking_ms: 30,
            turning_ms: 30,
            exit_ms: 30,
        };
        assert_eq!(inside.worst(), None);
    }

    /// A corner the reference never drove is no comparison, not a zero.
    #[test]
    fn no_reference_corner_is_no_answer() {
        let trace: Vec<TelemetryPoint> = (0..=10)
            .map(|step| point(step as f32 / 10.0, step * 1_000, 200.0))
            .collect();
        let comparison = CornerComparison {
            corner: bare_corner(),
            reference: None,
            delta_ms: 200,
        };
        assert!(comparison.inside(&trace, &trace, 0.8).is_none());
    }

    /// One sample, for the three tests above.
    fn point(distance: f32, time_ms: i32, speed: f32) -> TelemetryPoint {
        TelemetryPoint {
            distance,
            time_ms,
            speed,
            gas: 1.0,
            brake: 0.0,
            gear: 4,
            steer: 0.0,
            lat_g: 0.0,
            lon_g: 0.0,
            slip_avg: 0.0,
            x: 0.0,
            y: 0.0,
            rpms: 6000,
            detail: crate::analyzer::Detail::default(),
        }
    }

    /// A corner with nothing but zeros in it, for the tests above to fill in.
    fn bare_corner() -> Corner {
        Corner {
            number: 7,
            direction: Direction::Left,
            entry: 0.0,
            apex: 0.0,
            exit: 0.0,
            entry_speed: 0.0,
            min_speed: 0.0,
            exit_speed: 0.0,
            peak_lat_g: 0.0,
            brake_point: None,
            braking: None,
            throttle_point: None,
            throttle_delay_ms: None,
            entry_time_ms: 0,
            exit_time_ms: 0,
        }
    }
}
