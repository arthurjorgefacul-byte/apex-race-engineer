use crate::config::{AppConfig, Language};
use crate::games::{Capabilities, Car, CarClass, Session};
use crate::i18n::{Translate, tr_fmt};
use crate::session_info::SessionInfo;
use crate::setup_manager::CarSetup;
use serde::{Deserialize, Serialize};
use std::cmp::Ordering;
use std::collections::HashMap;
use std::time::{Duration, Instant};
use tracing::{debug, info};

#[derive(Debug, Serialize, Clone, Default)]
pub struct Recommendation {
    pub component: String,
    pub category: String,
    pub severity: Severity,
    pub message: String,
    pub action: String,
    pub parameters: Vec<Parameter>,
    /// The old hand-picked certainty, 0..1, still used for ordering.
    ///
    /// Superseded by [`Chain::evidence`] wherever a rule can count what it
    /// saw — see [`Recommendation::confidence_level`], which prefers the
    /// evidence and falls back to this.
    pub confidence: f32,
    /// Why this is happening, and how to know whether the fix worked.
    ///
    /// `Some` on every rule with a mechanism to state, which since v0.3.7 is
    /// all of them but the two fuel rules — see `analyze_strategy`, where the
    /// `None` is the finding rather than an omission.
    ///
    /// A chain whose [`Chain::evidence`] is *empty* is a third, deliberate
    /// state: the rule can explain itself but counts one whole-lap number
    /// rather than several corroborating observations, so
    /// [`Recommendation::confidence_level`] falls back to the hand-picked
    /// `confidence` beside it. One counter is one observation however large it
    /// gets.
    pub chain: Option<Chain>,
}

/// Evidence, mechanism, and a check for next time.
///
/// A flat finding says "front-right 96 °C". This says what produced it, what it
/// did, and — the field that matters most — **what to look at on the next run
/// to know whether the change worked**. That last one is what makes the advice
/// an engineer's rather than a paragraph: it commits the advice to being
/// checkable, and an unfalsifiable suggestion is not advice.
///
/// It also means the analysis stops being a list of independent checks. "FR
/// outer shoulder is hot" and "the car understeers in T4–T6" are two unrelated
/// findings until something states the link, and the value is entirely in the
/// link.
#[derive(Debug, Serialize, Clone, Default)]
pub struct Chain {
    /// The mechanism: "high lateral load through T4–T6".
    pub cause: String,
    /// The measurement it produced: "FR outer shoulder +11 °C".
    pub effect: String,
    /// What to look at next time: "FR I/M/O spread on the next lap".
    pub confirm: String,
    /// What was actually observed, and how much it agreed with itself.
    pub evidence: crate::confidence::Evidence,
}

impl Recommendation {
    /// How sure this advice is.
    ///
    /// Evidence wins where a rule counted what it saw; the hand-picked score is
    /// the fallback for the rules that did not, and is mapped onto the same
    /// scale rather than pretending to be evidence.
    pub fn confidence_level(&self) -> crate::confidence::Confidence {
        match self.chain.as_ref() {
            Some(chain) if !chain.evidence.is_empty() => chain.evidence.confidence(),
            _ => crate::confidence::Confidence::from_score(self.confidence),
        }
    }
}

/// `Deserialize` and `PartialEq` because a parameter is now written down and
/// read back: `followup` keeps what the driver was asked to change so the next
/// session can say whether it was.
#[derive(Debug, Serialize, Deserialize, Clone, Default, PartialEq)]
pub struct Parameter {
    pub name: String,
    pub current: f32,
    pub target: f32,
    pub unit: String,
}

/// The four corners, in the order every array in AC's physics page uses.
///
/// Was written out as a `match i { 0 => "FL", ... }` in six analysers, which
/// is six places to get the order wrong.
pub const CORNER_NAMES: [&str; 4] = ["FL", "FR", "RL", "RR"];

#[derive(Debug, Serialize, Deserialize, Clone, PartialEq, PartialOrd, Default)]
pub enum Severity {
    #[default]
    Info,
    Warning,
    Critical,
}

#[derive(Debug, Clone)]
pub struct DrivingStyle {
    pub smoothness: f32,
    pub aggression: f32,
    pub consistency: f32,
    pub trail_braking: f32,
    pub throttle_control: f32,
    pub prev_gas: f32,
    pub prev_brake: f32,
    pub prev_steer: f32,
}

#[derive(Debug, Clone, PartialEq)]
pub enum WizardPhase {
    Entry,
    Apex,
    Exit,
}

#[derive(Debug, Clone, PartialEq)]
pub enum WizardProblem {
    Understeer,
    Oversteer,
    Instability,
}

/// How many recent laps the measured fuel average runs over. Short enough to
/// track a changing pace, long enough that one cautious lap does not skew it.
const FUEL_HISTORY_LAPS: usize = 3;

pub struct Engineer {
    config: AppConfig,
    /// What the game feeding this engineer can actually measure.
    ///
    /// Starts at nothing measured, and every rule that rests on a measurement
    /// checks here before it says anything. A game is expected to announce
    /// itself through [`update_capabilities`](Engineer::update_capabilities)
    /// on the way in; until it does, the engineer withholds rather than reads
    /// a default as a reading.
    capabilities: Capabilities,
    /// What kind of car this is, and therefore what its numbers mean.
    ///
    /// Beside the capabilities because it answers the neighbouring question:
    /// those say *whether* a thing is measured, this says what a measurement
    /// of it is supposed to look like. A GT3 front brake at 520 °C is working;
    /// a road car's at 520 °C has boiled.
    ///
    /// `Unknown` — the default — means the driver's own thresholds are used
    /// unchanged, which is what a mod nobody has classified deserves.
    car_class: crate::games::CarClass,
    /// What the car itself says it lets a driver change. `None` until a car
    /// whose data could be read is loaded, and the class is asked then.
    car_adjustable: Option<crate::games::catalogue::Adjustables>,
    /// The hot pressure this car states for itself, front and rear, psi.
    ///
    /// Out of the car's own `tyres.ini`, handed in by whoever read the
    /// catalogue — the engineer does no I/O. `None` is the normal answer for
    /// Competizione, for a car whose data could not be read, and for every
    /// session before the catalogue has been walked.
    car_tyres: Option<(f32, f32)>,
    history_size: usize,
    pub stats: EngineerStats,
    pub driving_style: DrivingStyle,
    pub wizard_phase: WizardPhase,
    pub wizard_problem: WizardProblem,
    alert_timers: HashMap<String, (Instant, Instant)>,
}

#[derive(Debug, Clone)]
pub struct EngineerStats {
    pub bottoming_frames: [u32; 4],
    pub lockup_frames_front: u32,
    pub lockup_frames_rear: u32,
    pub wheel_spin_frames: u32,
    pub traction_loss_frames: u32,
    pub oversteer_frames: u32,
    pub understeer_frames: u32,
    pub coasting_frames: u32,
    pub scrubbing_frames: u32,
    pub current_excess_steer: f32,
    pub total_frames: u32,
    pub ffb_clip_frames: u32,
    pub input_history: crate::RingBuffer<(f64, f64, f64, f64, f64)>,
    pub fuel_laps_remaining: f32,
    pub fuel_consumption_rate: f32,
    /// Fuel used on each of the last few completed laps, newest last.
    ///
    /// AC's own `fuel_x_lap` sits in the part of the graphics page that is
    /// not confirmed against a live capture (see the note in `games/assetto_corsa/structs.rs`),
    /// and it reads zero on lap one regardless. Everything on the strategy
    /// tab was gated on it being positive, so the tab showed "NO DATA" for
    /// the whole first lap and, if that offset is wrong, forever.
    pub recent_fuel_per_lap: Vec<f32>,
    /// Fuel level at the start of the current lap, to measure against.
    pub fuel_at_lap_start: f32,
    pub current_delta: f32,
    pub predicted_lap_time: f32,
    pub low_speed_rake: f32,
    pub high_speed_rake: f32,
    /// Inner-minus-outer surface temperature per corner, averaged over the
    /// frames where the tyre was actually loaded sideways.
    ///
    /// A tyre says nothing about camber on a straight. Upright, both edges run
    /// at the same temperature and the spread reads about zero — which the
    /// first version of `analyze_camber` read as "contact patch inefficient"
    /// and published on every straight, four corners at a time, filling the
    /// panel's eight advice lines with one wrong answer. Camber only shows in
    /// the spread while the tyre is loaded, so the sample is taken while the
    /// car is cornering and the verdict comes from the average.
    ///
    /// All four corners are sampled rather than the loaded pair: left-handers
    /// load the right tyres and right-handers the left, so over a lap of a
    /// circuit both sides get their turn. An oval would skew it.
    pub camber_spread: [f32; 4],
    /// Ticks of cornering behind `camber_spread`. Below `CAMBER_MIN_FRAMES`
    /// the average is one corner's worth of noise and nothing is published.
    pub camber_frames: u32,
    pub base_tyre_wear: [f32; 4],
    pub stint_laps: i32,
    pub last_lap_count: i32,
    pub tyre_laps_remaining: [f32; 4],
}

impl Default for EngineerStats {
    fn default() -> Self {
        Self::new()
    }
}

impl EngineerStats {
    pub fn new() -> Self {
        Self {
            bottoming_frames: [0; 4],
            lockup_frames_front: 0,
            lockup_frames_rear: 0,
            wheel_spin_frames: 0,
            traction_loss_frames: 0,
            oversteer_frames: 0,
            understeer_frames: 0,
            coasting_frames: 0,
            scrubbing_frames: 0,
            current_excess_steer: 0.0,
            total_frames: 0,
            ffb_clip_frames: 0,
            input_history: crate::RingBuffer::new(300),
            fuel_laps_remaining: 0.0,
            fuel_consumption_rate: 0.0,
            recent_fuel_per_lap: Vec::new(),
            fuel_at_lap_start: 0.0,
            current_delta: 0.0,
            predicted_lap_time: 0.0,
            low_speed_rake: 0.0,
            high_speed_rake: 0.0,
            camber_spread: [0.0; 4],
            camber_frames: 0,
            base_tyre_wear: [100.0; 4],
            stint_laps: 0,
            last_lap_count: -1,
            // Negative means "not measured yet", and it has to be a value
            // laps remaining can never take — this was 99.0, which is also a
            // perfectly good answer, so a tyre with ninety-nine laps in it read
            // as no data.
            tyre_laps_remaining: [-1.0; 4],
        }
    }
}

impl Default for DrivingStyle {
    fn default() -> Self {
        Self::new()
    }
}

impl DrivingStyle {
    pub fn new() -> Self {
        Self {
            smoothness: 50.0,
            aggression: 50.0,
            consistency: 50.0,
            trail_braking: 0.0,
            throttle_control: 50.0,
            prev_gas: 0.0,
            prev_brake: 0.0,
            prev_steer: 0.0,
        }
    }
}

/// The tyre temperature window to judge a car against, and where it came from.
///
/// The class's window when the class is known **and** the driver has left the
/// setting at its default; the driver's own numbers the moment they change
/// one. A setting somebody has deliberately typed outranks a table, and one
/// they have never touched is not a preference — it is the application's old
/// one-size band, which was 70–105 °C for a Formula car and a Fiat 500 alike.
///
/// **Public because more than the advice depends on it.** A front end that
/// colours a tyre readout has to use the same band the advice is written
/// against, or the two disagree on one screen: the graphical front end painted
/// a front-left green at 102 °C — inside the raw 70–105 alert range — directly
/// beside the engineer's own line calling the same tyre overheating, because
/// a GT3's window closes at 100. One rule, one place.
pub fn tyre_window(alerts: &crate::config::AlertsConfig, class: CarClass) -> (f32, f32) {
    let defaults = crate::config::AlertsConfig::default();
    let untouched = (alerts.tyre_temp_min - defaults.tyre_temp_min).abs() < 0.01
        && (alerts.tyre_temp_max - defaults.tyre_temp_max).abs() < 0.01;

    if class.is_known() && untouched {
        class.window().tyre_c
    } else {
        (
            alerts.tyre_temp_min.min(alerts.tyre_temp_max),
            alerts.tyre_temp_min.max(alerts.tyre_temp_max),
        )
    }
}

/// The brake ceiling for one corner, front or rear.
///
/// Per axle, because that is how brakes work: the recording this project pins
/// Competizione to shows 520 °C at the front against 257 °C at the rear, and
/// one number for all four is either too low for the fronts or blind to the
/// rears. Same rule about the driver's own setting as [`tyre_window`], and
/// public for the same reason.
pub fn brake_ceiling(alerts: &crate::config::AlertsConfig, class: CarClass, wheel: usize) -> f32 {
    let defaults = crate::config::AlertsConfig::default();
    let untouched = (alerts.brake_temp_max - defaults.brake_temp_max).abs() < 0.01;

    if class.is_known() && untouched {
        let window = class.window();
        if wheel < 2 {
            window.brake_front_max_c
        } else {
            window.brake_rear_max_c
        }
    } else {
        alerts.brake_temp_max
    }
}

/// The hot pressure this corner should be at, in psi.
///
/// **The third of the class-aware bands, and the one that was missing.** A
/// Formula car works at 21 psi and a touring car at 28; until this existed the
/// advice judged both against one figure — the 27.5 psi default, which is a
/// GT3's number — so a single-seater was told to deflate six and a half psi
/// below the pressure it is meant to run at. That is the "false information
/// about tyre pressure" in the review that prompted this, and the window
/// already knew better: its PRESSURES view had been reading
/// [`ClassWindow::hot_pressure_psi`] while the engineer beside it read the
/// configuration. One rule in two places is two answers, which is the whole
/// reason [`tyre_window`] is public.
///
/// The order of precedence is the same as the other two, with one extra step
/// because there are two settings rather than one:
///
/// 1. the per-axle target, if the driver has moved it — the terminal's
///    Settings screen is where that happens;
/// 2. the single target, if they have moved that one — the window's slider;
/// 3. **the car's own figure**, out of its `tyres.ini`, when the game shipped
///    one this could read;
/// 4. the class's own figure, when the class is recognised;
/// 5. the per-axle default, which is where a car nobody recognises lands.
///
/// A number somebody typed always outranks the table. A default is not a
/// preference. And a number the *car* states outranks any table at all — a
/// class is a group of cars that mostly agree, and `own` is this one saying
/// what it actually wants. It is what makes a mod nobody has classified come
/// out right, and it is why a single-seater on 21 psi stopped being told to
/// inflate: GT3, road and unrecognised all carry 27.5 in the class table, so
/// for most of Assetto Corsa's grid the table changed nothing.
///
/// [`ClassWindow::hot_pressure_psi`]: crate::games::ClassWindow::hot_pressure_psi
pub fn hot_pressure(
    config: &AppConfig,
    class: CarClass,
    own: Option<(f32, f32)>,
    wheel: usize,
) -> f32 {
    let defaults = AppConfig::default();
    let (mine, its_default) = if wheel < 2 {
        (
            config.target_hot_pressure_front,
            defaults.target_hot_pressure_front,
        )
    } else {
        (
            config.target_hot_pressure_rear,
            defaults.target_hot_pressure_rear,
        )
    };

    if (mine - its_default).abs() >= 0.01 {
        return mine;
    }
    if (config.target_tyre_pressure - defaults.target_tyre_pressure).abs() >= 0.01 {
        return config.target_tyre_pressure;
    }
    if let Some((front, rear)) = own {
        return if wheel < 2 { front } else { rear };
    }
    if class.is_known() {
        return class.window().hot_pressure_psi;
    }
    mine
}

/// The band outside which a corner's pressure is worth saying out loud.
///
/// Centred on [`hot_pressure`] and as wide as the driver's own alert band, so
/// that moving the class also moves the alert with it. Without this the band
/// stayed at the configuration's 26.0–28.5 — a Formula car correctly at 21 psi
/// tripped the under-pressure alert on every corner of every lap, and the one
/// reading that was right was the one being complained about.
///
/// The driver's own numbers win the moment they touch either end, exactly as
/// in [`tyre_window`].
pub fn pressure_window(
    config: &AppConfig,
    class: CarClass,
    own: Option<(f32, f32)>,
    wheel: usize,
) -> (f32, f32) {
    let alerts = &config.alerts;
    let low = alerts.tyre_pressure_min.min(alerts.tyre_pressure_max);
    let high = alerts.tyre_pressure_min.max(alerts.tyre_pressure_max);

    let defaults = crate::config::AlertsConfig::default();
    let untouched = (alerts.tyre_pressure_min - defaults.tyre_pressure_min).abs() < 0.01
        && (alerts.tyre_pressure_max - defaults.tyre_pressure_max).abs() < 0.01;
    if !untouched {
        return (low, high);
    }

    let half = (defaults.tyre_pressure_max - defaults.tyre_pressure_min) / 2.0;
    let target = hot_pressure(config, class, own, wheel);
    (target - half, target + half)
}

impl Engineer {
    pub fn new(config: &AppConfig) -> Self {
        info!("Engineer module initialized.");
        Self {
            config: config.clone(),
            capabilities: Capabilities::default(),
            car_class: crate::games::CarClass::default(),
            car_adjustable: None,
            car_tyres: None,
            history_size: 600,
            stats: EngineerStats::new(),
            driving_style: DrivingStyle::new(),
            wizard_phase: WizardPhase::Entry,
            wizard_problem: WizardProblem::Understeer,
            alert_timers: HashMap::new(),
        }
    }

    pub fn update_config(&mut self, config: &AppConfig) {
        self.config = config.clone();
        self.stats.input_history.set_capacity(config.history_size);
    }

    /// Tell the engineer what the game it is reading can measure.
    ///
    /// Carried on every [`Reading`](crate::games::Reading), and passed on here
    /// once a tick beside the config. Nothing else needs to change when a
    /// second game arrives with a different answer.
    pub fn update_capabilities(&mut self, capabilities: Capabilities) {
        self.capabilities = capabilities;
    }

    /// Tell the engineer what it is looking at.
    ///
    /// From the car's id, which every game publishes — see
    /// [`CarClass::identify`](crate::games::CarClass::identify). Set on every
    /// tick like the capabilities, because a driver can change car without
    /// closing anything.
    pub fn update_car_class(&mut self, car_class: crate::games::CarClass) {
        self.car_class = car_class;
    }

    /// What kind of car the numbers are being read against.
    pub fn car_class(&self) -> crate::games::CarClass {
        self.car_class
    }

    /// What the car says it lets a driver change.
    ///
    /// Set beside [`Self::update_car_class`] and off the same catalogue entry,
    /// so the two cannot describe different cars.
    pub fn update_car_adjustables(
        &mut self,
        adjustable: Option<crate::games::catalogue::Adjustables>,
    ) {
        self.car_adjustable = adjustable;
    }

    /// Whether this car has a wing to be told about.
    ///
    /// **The car's own answer first, the class only when there is none.** A
    /// class is a guess and this is a fact: `setup.ini` has a `WING` section
    /// exactly when the setup screen has a wing on it. The guess is kept for
    /// Competizione, which ships no such file, and for a car whose data could
    /// not be read.
    fn wing_to_adjust(&self) -> bool {
        match self.car_adjustable {
            Some(adjustable) => adjustable.wing,
            None => self.car_class.has_adjustable_aero(),
        }
    }

    /// Whether springs or an anti-roll bar can be changed on this car.
    ///
    /// The mechanical half of a balance fix, and the reason it has to be
    /// asked: a car can have no wing *and* no bar, and the line that used to
    /// be the fallback named both.
    fn mechanical_balance(&self) -> bool {
        match self.car_adjustable {
            Some(adjustable) => adjustable.springs || adjustable.anti_roll_bar,
            // **Without the car's own answer, assume it has them.** A wing is
            // the thing road cars tend not to have; springs and a bar are the
            // thing nearly everything has, road cars included, and this is the
            // line a road car has been given since the wing rule was written.
            // Asking `has_adjustable_aero` here would have taken it away from
            // every road car to fix the few that are also without a bar.
            None => true,
        }
    }

    /// What the car says its own hot pressure is, front and rear.
    ///
    /// Set beside [`Self::update_car_class`] and from the same catalogue, so
    /// the two cannot describe different cars.
    pub fn update_car_tyres(&mut self, ideal: Option<(f32, f32)>) {
        self.car_tyres = ideal;
    }

    pub fn car_tyres(&self) -> Option<(f32, f32)> {
        self.car_tyres
    }

    /// The tyre temperature window this engineer is judging against.
    ///
    /// See [`tyre_window`], which is the rule; this is it applied to what the
    /// engineer currently knows about the car and the driver's settings.
    pub fn tyre_window(&self) -> (f32, f32) {
        tyre_window(&self.config.alerts, self.car_class)
    }

    /// The brake ceiling for one corner, front or rear.
    ///
    /// Per axle, because that is how brakes work: the recording this project
    /// pins Competizione to shows 520 °C at the front against 257 °C at the
    /// rear, and one number for all four is either too low for the fronts or
    /// blind to the rears. Same rule about the driver's own setting as above.
    fn brake_ceiling(&self, wheel: usize) -> f32 {
        brake_ceiling(&self.config.alerts, self.car_class, wheel)
    }

    /// What the engineer is currently willing to speak about.
    pub fn capabilities(&self) -> Capabilities {
        self.capabilities
    }

    pub fn update(&mut self, car: &Car, session: &Session, _info: &SessionInfo) {
        self.update_stats(car, session);
        self.analyze_driving_style(car);

        if self.stats.total_frames > self.history_size as u32 {
            debug!("Engineer history buffer reached limit, resetting counters.");
            self.reset_counters();
        }
    }

    fn update_stats(&mut self, car: &Car, session: &Session) {
        let dt_sec = (self.config.update_rate as f32 / 1000.0).clamp(0.001, 1.0);
        let ticks_norm = (dt_sec * 60.0).round().max(1.0) as u32;

        self.stats.total_frames += ticks_norm;

        if car.force_feedback.abs() > 0.98 {
            self.stats.ffb_clip_frames += ticks_norm;
        }

        if self.stats.total_frames.is_multiple_of(3) {
            let t = self.stats.total_frames as f64;
            self.stats.input_history.push((
                t,
                car.steer_angle as f64,
                car.throttle as f64,
                car.brake as f64,
                car.force_feedback as f64,
            ));
        }

        for i in 0..4 {
            if car.suspension_travel[i] < 0.005 {
                self.stats.bottoming_frames[i] += ticks_norm;
            }
        }

        // **Only where the game publishes a ride height.** Competizione does
        // not: the field is zero for the whole recording, so the rake is zero
        // at every speed and the aero rule was protected by nothing but a
        // `!= 0.0` guard on its own accumulators. One frame of noise past that
        // and a driver would be told to stiffen their rear springs because of
        // a measurement their game never made.
        //
        // The same gate the camber rule has had since it was written, on the
        // rule that needed it just as much and did not have it.
        let rake = match self.capabilities.ride_height {
            true => car.ride_height_m[1] - car.ride_height_m[0],
            false => 0.0,
        };
        let rake_mm = rake * 1000.0;
        if self.capabilities.ride_height && car.speed_kmh > 50.0 && car.speed_kmh < 90.0 {
            if self.stats.low_speed_rake == 0.0 {
                self.stats.low_speed_rake = rake_mm;
            }
            self.stats.low_speed_rake = self.stats.low_speed_rake * 0.98 + rake_mm * 0.02;
        } else if self.capabilities.ride_height && car.speed_kmh > 160.0 {
            if self.stats.high_speed_rake == 0.0 {
                self.stats.high_speed_rake = rake_mm;
            }
            self.stats.high_speed_rake = self.stats.high_speed_rake * 0.98 + rake_mm * 0.02;
        }

        // acc_g is [lateral, vertical, longitudinal]. Half a g sideways is a
        // corner being driven; a lane change on a straight does not reach it,
        // and a straight is where the inner and outer edges of a correctly
        // cambered tyre read the same temperature.
        if self.capabilities.tyre_edge_temps && car.speed_kmh > 50.0 && car.acc_g[0].abs() > 0.5 {
            let first_sample = self.stats.camber_frames == 0;
            self.stats.camber_frames = self.stats.camber_frames.saturating_add(ticks_norm);
            for i in 0..4 {
                let spread = car.tyre_temp_inner_c[i] - car.tyre_temp_outer_c[i];
                if first_sample {
                    self.stats.camber_spread[i] = spread;
                } else {
                    self.stats.camber_spread[i] =
                        self.stats.camber_spread[i] * 0.98 + spread * 0.02;
                }
            }
        }

        let current_laps = session.completed_laps;
        if current_laps != self.stats.last_lap_count {
            self.record_fuel_for_completed_lap(car.fuel_litres);
            if self.stats.last_lap_count == -1 || current_laps == 0 || car.speed_kmh < 10.0 {
                self.stats.base_tyre_wear = car.tyre_wear;
                self.stats.stint_laps = 0;
            } else if self.capabilities.tyre_wear {
                self.stats.stint_laps += 1;
                for i in 0..4 {
                    let wear_used = self.stats.base_tyre_wear[i] - car.tyre_wear[i];
                    if wear_used > 0.0 && self.stats.stint_laps > 0 {
                        let wear_per_lap = wear_used / self.stats.stint_laps as f32;
                        // Laps until the tyre is *done*, not until it is two
                        // percent past the warning. That derivation is the same
                        // one that used to call a tyre at 93.9 % life critical.
                        let replacement_threshold = self
                            .config
                            .alerts
                            .wear_critical
                            .min(self.config.alerts.wear_warning)
                            .max(0.0);
                        let remaining_wear = car.tyre_wear[i] - replacement_threshold;
                        if wear_per_lap > 0.001 {
                            let laps = (remaining_wear / wear_per_lap).max(0.0);
                            self.stats.tyre_laps_remaining[i] =
                                if laps > 500.0 { 500.0 } else { laps };
                        }
                    }
                }
            }
            self.stats.last_lap_count = current_laps;
        }

        if car.speed_kmh > 30.0 {
            if (car.wheel_slip[0].abs() > 0.2 || car.wheel_slip[1].abs() > 0.2) && car.brake > 0.1 {
                self.stats.lockup_frames_front += ticks_norm;
            }
            if (car.wheel_slip[2].abs() > 0.2 || car.wheel_slip[3].abs() > 0.2) && car.brake > 0.1 {
                self.stats.lockup_frames_rear += ticks_norm;
            }
        }

        for i in 0..4 {
            if car.wheel_slip[i] > 0.15 && car.throttle > 0.3 && car.speed_kmh < 120.0 {
                self.stats.wheel_spin_frames += ticks_norm;
            }
        }

        if car.speed_kmh > 30.0 && car.throttle < 0.05 && car.brake < 0.05 {
            self.stats.coasting_frames += ticks_norm;
        }

        if car.speed_kmh > 40.0 {
            let front_slip = car.wheel_slip[0].max(car.wheel_slip[1]);
            let rear_slip = car.wheel_slip[2].max(car.wheel_slip[3]);

            if front_slip > 0.15 && front_slip > rear_slip + 0.05 && car.steer_angle.abs() > 0.15 {
                self.stats.understeer_frames += ticks_norm;
                self.stats.scrubbing_frames += ticks_norm;
                let excess = (car.steer_angle.abs() - 0.15) * 57.2958;
                if excess > self.stats.current_excess_steer {
                    self.stats.current_excess_steer = excess;
                }
            } else if rear_slip > 0.15 && rear_slip > front_slip + 0.05 {
                self.stats.oversteer_frames += ticks_norm;
            }
        } else if self.stats.scrubbing_frames > 0 && self.stats.scrubbing_frames < 45 {
            self.stats.scrubbing_frames = 0;
            self.stats.current_excess_steer = 0.0;
        }

        // Prefer AC's own figure when it is reporting one, and fall back to
        // what we measured ourselves otherwise. Either way the strategy tab
        // has something to work with from the second lap onward.
        let fuel_per_lap = if session.fuel_per_lap > 0.0 {
            Some(session.fuel_per_lap)
        } else {
            self.measured_fuel_per_lap()
        };
        match fuel_per_lap {
            Some(per_lap) if per_lap > 0.0 => {
                self.stats.fuel_consumption_rate = per_lap;
                self.stats.fuel_laps_remaining = car.fuel_litres / per_lap;
            }
            // Nothing to go on. Clear rather than leave the previous value
            // standing: it was never reset, so after a refuel or a session
            // change `analyze_strategy` could call BOX BOX BOX on a number
            // measured before the stop.
            _ => {
                self.stats.fuel_consumption_rate = 0.0;
                self.stats.fuel_laps_remaining = 0.0;
            }
        }

        self.stats.current_delta = car.reference_delta_s;

        if session.best_lap_ms > 0 {
            self.stats.predicted_lap_time =
                (session.best_lap_ms as f32 / 1000.0) + car.reference_delta_s;
        } else if session.last_lap_ms > 0 {
            self.stats.predicted_lap_time = session.last_lap_ms as f32 / 1000.0;
        }
    }

    fn analyze_driving_style(&mut self, car: &Car) {
        let gas_diff = (car.throttle - self.driving_style.prev_gas).abs();
        let brake_diff = (car.brake - self.driving_style.prev_brake).abs();
        let steer_diff = (car.steer_angle - self.driving_style.prev_steer).abs();

        let throttle_smoothness = (100.0 - (gas_diff * 1000.0)).clamp(0.0, 100.0);
        let brake_smoothness = (100.0 - (brake_diff * 1000.0)).clamp(0.0, 100.0);
        let steer_smoothness = (100.0 - (steer_diff * 500.0)).clamp(0.0, 100.0);

        self.driving_style.smoothness = 0.95 * self.driving_style.smoothness
            + 0.05 * (throttle_smoothness + brake_smoothness + steer_smoothness) / 3.0;

        self.driving_style.prev_gas = car.throttle;
        self.driving_style.prev_brake = car.brake;
        self.driving_style.prev_steer = car.steer_angle;

        // acc_g is [lateral, vertical, longitudinal]. This combined the
        // lateral and *vertical* axes, so it measured cornering plus the ~1 g
        // the car carries standing still, and never saw braking or
        // acceleration at all.
        let combined_g = (car.acc_g[0].powi(2) + car.acc_g[2].powi(2)).sqrt();
        self.driving_style.aggression =
            0.9 * self.driving_style.aggression + 0.1 * combined_g.min(2.5) / 2.5 * 100.0;

        if car.brake > 0.1 && car.steer_angle.abs() > 0.1 {
            self.driving_style.trail_braking =
                0.95 * self.driving_style.trail_braking + 0.05 * 100.0;
        } else {
            self.driving_style.trail_braking *= 0.98;
        }
    }

    /// Average fuel burn over the laps measured so far, if there are any.
    fn measured_fuel_per_lap(&self) -> Option<f32> {
        if self.stats.recent_fuel_per_lap.is_empty() {
            return None;
        }
        let sum: f32 = self.stats.recent_fuel_per_lap.iter().sum();
        Some(sum / self.stats.recent_fuel_per_lap.len() as f32)
    }

    /// Note how much fuel the lap that just ended consumed.
    ///
    /// A negative delta means the tank went up, i.e. a pit stop: the history
    /// is dropped rather than averaged, because burn measured across a refuel
    /// is meaningless.
    fn record_fuel_for_completed_lap(&mut self, fuel_now: f32) {
        let used = self.stats.fuel_at_lap_start - fuel_now;
        self.stats.fuel_at_lap_start = fuel_now;

        if used < 0.0 {
            self.stats.recent_fuel_per_lap.clear();
            return;
        }
        if used <= 0.0 || !used.is_finite() {
            return;
        }

        self.stats.recent_fuel_per_lap.push(used);
        if self.stats.recent_fuel_per_lap.len() > FUEL_HISTORY_LAPS {
            self.stats.recent_fuel_per_lap.remove(0);
        }
    }

    fn reset_counters(&mut self) {
        self.stats.bottoming_frames = [0; 4];
        self.stats.lockup_frames_front = 0;
        self.stats.lockup_frames_rear = 0;
        self.stats.wheel_spin_frames = 0;
        self.stats.traction_loss_frames = 0;
        self.stats.oversteer_frames = 0;
        self.stats.understeer_frames = 0;
        self.stats.coasting_frames = 0;
        self.stats.scrubbing_frames = 0;
        self.stats.current_excess_steer = 0.0;
        self.stats.total_frames = 0;
        self.stats.ffb_clip_frames = 0;
    }

    /// Forget everything measured about this stint. Called when the session
    /// changes underneath us.
    pub fn reset_fuel_tracking(&mut self) {
        self.stats.recent_fuel_per_lap.clear();
        self.stats.fuel_at_lap_start = 0.0;
        self.stats.fuel_laps_remaining = 0.0;
        self.stats.fuel_consumption_rate = 0.0;
    }

    fn check_hysteresis(&mut self, key: &str, active: bool) -> bool {
        let now = Instant::now();
        if active {
            let first_seen = if let Some(&(first, _)) = self.alert_timers.get(key) {
                first
            } else {
                now
            };
            self.alert_timers.insert(key.to_string(), (first_seen, now));
            return now.duration_since(first_seen) >= Duration::from_secs_f32(1.0);
        }

        if let Some(&(first_seen, last_seen)) = self.alert_timers.get(key)
            && now.duration_since(last_seen) < Duration::from_secs_f32(2.0)
        {
            return now.duration_since(first_seen) >= Duration::from_secs_f32(1.0);
        }

        self.alert_timers.remove(key);
        false
    }

    pub fn analyze_live(
        &mut self,
        car: &Car,
        session: &Session,
        setup: Option<&CarSetup>,
    ) -> Vec<Recommendation> {
        let mut recommendations = Vec::new();

        self.analyze_tyre_pressure(car, session, &mut recommendations);
        // Both of these are built on measurements a game may simply not make,
        // and a missing measurement reads as zero — which is a confident
        // verdict about a car nobody drove. ACC publishes core tyre
        // temperature and no tread across it at all; the camber rule *is*
        // inner minus outer, and the temperature band is written against the
        // mean of the three. Neither has anything to fall back on that is the
        // same physical quantity, so neither runs.
        // The temperature band runs on whatever the game measures a tyre with:
        // the mean of the tread where there is one, the core where there is
        // not. It used to be gated with the camber rule, which cost
        // Competizione every word about tyre temperature — on a game that
        // publishes a perfectly good core reading, and a driver on cold tyres
        // was told nothing at all. The rule says which quantity it judged, so
        // a core reading is never mistaken for a surface one.
        //
        // The camber rule stays behind the gate. It *is* inner minus outer,
        // and there is nothing to fall back on.
        self.analyze_tyre_temperature(car, &mut recommendations);
        if self.capabilities.tyre_edge_temps {
            self.analyze_camber(car, &mut recommendations);
        }
        if self.capabilities.tyre_wear {
            self.analyze_tyre_wear(car, &mut recommendations);
        }
        // The other half of the same trade. Competizione publishes no tyre
        // wear and does publish what is left of the brakes; Assetto Corsa is
        // the other way round. Neither game gets the other's rule.
        if self.capabilities.brake_wear {
            self.analyze_brake_wear(car, &mut recommendations);
        }
        self.analyze_suspension(car, &mut recommendations);
        self.analyze_brakes(car, &mut recommendations);
        self.analyze_brake_bias(setup, &mut recommendations);
        // Rake is front ride height minus rear, and a game that publishes
        // neither has no rake — see where it is accumulated.
        if self.capabilities.ride_height {
            self.analyze_aero(car, &mut recommendations);
        }

        self.analyze_driving_errors(&mut recommendations);
        self.analyze_strategy(car, session, &mut recommendations);
        self.analyze_ffb_clipping(car, &mut recommendations);

        recommendations.sort_by(|a, b| {
            b.severity
                .partial_cmp(&a.severity)
                .unwrap_or(Ordering::Equal)
                .then(
                    b.confidence
                        .partial_cmp(&a.confidence)
                        .unwrap_or(Ordering::Equal),
                )
        });

        recommendations
    }

    fn analyze_suspension(&mut self, _car: &Car, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();
        // Which corners, not merely whether. The loop used to break on the
        // first one over the threshold, which was enough to raise the alert and
        // not enough to say anything about it — and a car bottoming on one rear
        // corner is a different problem from one bottoming on both fronts.
        const BOTTOMING_FRAMES: u32 = 30;
        let grounded: Vec<usize> = (0..4)
            .filter(|i| self.stats.bottoming_frames[*i] > BOTTOMING_FRAMES)
            .collect();
        let bottoming_detected = !grounded.is_empty();
        if self.check_hysteresis("bottoming", bottoming_detected) && bottoming_detected {
            recs.push(Recommendation {
                component: "Suspension".tr(ru).to_string(),
                category: "Bottoming".tr(ru).to_string(),
                severity: Severity::Critical,
                message: "Chassis bottoming out!".tr(ru).to_string(),
                action: "Increase ride height or stiffness".tr(ru).to_string(),
                parameters: vec![],
                confidence: 0.95,
                chain: Some(Chain {
                    cause: "the suspension is running out of travel over kerbs and compressions"
                        .tr(ru)
                        .to_string(),
                    effect: match ru {
                        true => format!(
                            "{}: {}",
                            Self::corner_phrase(&grounded, ru),
                            Self::frames_phrase(
                                grounded
                                    .iter()
                                    .map(|i| self.stats.bottoming_frames[*i])
                                    .max()
                                    .unwrap_or(0),
                                self.stats.total_frames,
                                ru
                            )
                        ),
                        false => format!(
                            "{}: {}",
                            Self::corner_phrase(&grounded, ru),
                            Self::frames_phrase(
                                grounded
                                    .iter()
                                    .map(|i| self.stats.bottoming_frames[*i])
                                    .max()
                                    .unwrap_or(0),
                                self.stats.total_frames,
                                ru
                            )
                        ),
                    },
                    confirm: tr_fmt(
                        "the bottoming count on {0} over the same lap, once it is raised",
                        ru,
                        &[&Self::corner_phrase_mid(&grounded, ru)],
                    ),
                    // One observation per corner that grounded, measured past
                    // the threshold rather than from zero — a corner one frame
                    // over is not the same finding as one forty frames over.
                    evidence: crate::confidence::Evidence::from_values(
                        grounded
                            .iter()
                            .map(|i| (self.stats.bottoming_frames[*i] - BOTTOMING_FRAMES) as f32),
                    ),
                }),
            });
        }
    }

    fn analyze_aero(&mut self, car: &Car, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();
        if self.stats.high_speed_rake != 0.0
            && self.stats.low_speed_rake != 0.0
            && car.speed_kmh > 150.0
        {
            let rake_loss = self.stats.low_speed_rake - self.stats.high_speed_rake;
            if self.check_hysteresis("aero_rake", rake_loss > 10.0) && rake_loss > 10.0 {
                recs.push(Recommendation {
                    component: "Aerodynamics".tr(ru).to_string(),
                    category: "Rake Loss".to_string(),
                    severity: Severity::Warning,
                    message: tr_fmt(
                        "Rear dropping too much at high speed (-{0}mm)",
                        ru,
                        &[&format!("{rake_loss:.1}")],
                    ),
                    action: "Stiffen Rear Springs or add Packers".tr(ru).to_string(),
                    parameters: vec![],
                    confidence: 0.85,
                    chain: Some(Chain {
                        cause: "downforce is squatting the rear, and the rake goes with it"
                            .tr(ru)
                            .to_string(),
                        effect: tr_fmt(
                            "-{0} mm between low and high speed",
                            ru,
                            &[&format!("{rake_loss:.1}")],
                        ),
                        confirm: "the rake difference at the same speed next run out"
                            .tr(ru)
                            .to_string(),
                        // One measurement, taken at one speed. It is a finding,
                        // not four corroborating observations, and saying so is
                        // the point of leaving this empty.
                        evidence: crate::confidence::Evidence::new(),
                    }),
                });
            }
        }
    }

    pub fn get_wizard_advice(&self) -> Vec<String> {
        let is_ru = self.config.language == Language::Russian;
        let mut advice = Vec::new();
        // A car with no wing is given the mechanical lines and not a fourth
        // one about a part it does not have — the same rule the balance
        // findings above follow. Nothing is invented to replace it: two real
        // changes are worth more than three with one that cannot be made.
        let aero = self.wing_to_adjust();

        match (&self.wizard_phase, &self.wizard_problem) {
            (WizardPhase::Entry, WizardProblem::Understeer) => {
                advice.push("Decrease Front Rebound".tr(is_ru).to_string());
                advice.push("Increase Rear Ride Height".tr(is_ru).to_string());
                advice.push("Move Brake Bias Rearwards".tr(is_ru).to_string());
            }
            (WizardPhase::Entry, WizardProblem::Oversteer) => {
                advice.push("Increase Front Rebound".tr(is_ru).to_string());
                advice.push("Move Brake Bias Forwards".tr(is_ru).to_string());
                if aero {
                    advice.push("Increase Front Wing".tr(is_ru).to_string())
                };
            }
            (WizardPhase::Apex, WizardProblem::Understeer) => {
                advice.push("Softer Front Springs".tr(is_ru).to_string());
                advice.push("Softer Front ARB".tr(is_ru).to_string());
                advice.push("More Front Camber".tr(is_ru).to_string());
            }
            (WizardPhase::Apex, WizardProblem::Oversteer) => {
                advice.push("Softer Rear Springs".tr(is_ru).to_string());
                advice.push("Softer Rear ARB".tr(is_ru).to_string());
                advice.push("Increase Front Ride Height".tr(is_ru).to_string());
            }
            (WizardPhase::Exit, WizardProblem::Understeer) => {
                advice.push("Increase Front Bump".tr(is_ru).to_string());
                advice.push("Stiffer Rear Springs".tr(is_ru).to_string());
                advice.push("Increase Diff Power".tr(is_ru).to_string());
            }
            (WizardPhase::Exit, WizardProblem::Oversteer) => {
                advice.push("Softer Rear Springs".tr(is_ru).to_string());
                advice.push("Decrease Rear Bump".tr(is_ru).to_string());
                advice.push("Decrease Diff Power".tr(is_ru).to_string());
                advice.push("Increase TC".tr(is_ru).to_string());
            }
            (_, WizardProblem::Instability) => {
                if aero {
                    advice.push("Increase Downforce (Wings)".tr(is_ru).to_string())
                };
                advice.push("More Rear Toe-In".tr(is_ru).to_string());
                advice.push("Stiffer Suspension Overall".tr(is_ru).to_string());
            }
        }
        advice
    }

    fn is_ru(&self) -> bool {
        self.config.language == Language::Russian
    }

    pub fn compare_setups_advice(&self, target: &CarSetup, reference: &CarSetup) -> Vec<String> {
        let mut advice = Vec::new();
        let ru = self.is_ru();

        let aero_diff =
            (target.wing_1 + target.wing_2) as i32 - (reference.wing_1 + reference.wing_2) as i32;
        if aero_diff != 0 {
            advice.push(tr_fmt("Aero: {0}", ru, &[&format!("{aero_diff:+}")]));
        }

        let camber_f_diff =
            (target.camber_lf + target.camber_rf) - (reference.camber_lf + reference.camber_rf);
        if camber_f_diff.abs() > 2 {
            advice.push(tr_fmt(
                "Front Camber: {0}",
                ru,
                &[&format!("{camber_f_diff:+}")],
            ));
        }

        let avg_p_target: f32 =
            (target.pressure_lf + target.pressure_rf + target.pressure_lr + target.pressure_rr)
                as f32
                / 4.0;
        let avg_p_ref: f32 = (reference.pressure_lf
            + reference.pressure_rf
            + reference.pressure_lr
            + reference.pressure_rr) as f32
            / 4.0;
        if (avg_p_target - avg_p_ref).abs() > 1.0 {
            advice.push(tr_fmt(
                "Tyre Press: {0} PSI",
                ru,
                &[&format!("{:+.1}", avg_p_target - avg_p_ref)],
            ));
        }

        if advice.is_empty() {
            advice.push("No major differences".tr(ru).to_string());
        }
        advice
    }

    fn analyze_ffb_clipping(&mut self, car: &Car, recs: &mut Vec<Recommendation>) {
        // Switched off by a driver who has no wheel to feel it with. The
        // game computes the signal either way, so there is nothing to detect
        // and this is the only honest answer — see `AlertsConfig::ffb_advice`.
        if !self.config.alerts.ffb_advice {
            return;
        }
        let ru = self.is_ru();
        let clip_ratio = if self.stats.total_frames > 0 {
            self.stats.ffb_clip_frames as f32 / self.stats.total_frames as f32
        } else {
            0.0
        };

        let is_clipping = clip_ratio > 0.05 && car.speed_kmh > 10.0;

        if self.check_hysteresis("ffb_clip", is_clipping) && is_clipping {
            recs.push(Recommendation {
                component: "Force Feedback".tr(ru).to_string(),
                category: "Clipping".to_string(),
                severity: Severity::Warning,
                message: tr_fmt(
                    "FFB Clipping: {0}% of time",
                    ru,
                    &[&format!("{:.1}", clip_ratio * 100.0)],
                ),
                action: "Lower FFB Gain".tr(ru).to_string(),
                // **No parameter, because a clip ratio is not a slider.**
                //
                // This offered `Clip Ratio 16.51 % → 0.00 %`, and a
                // `Parameter` is the setting to change and the number to
                // change it to. The setting is the wheel's gain, which lives
                // in the driver's own software and is not a number this can
                // know; the clip ratio is what happens *after* they move it,
                // which is exactly what the chain's `confirm` already says.
                //
                // The same fault as the wear rule's `FL life 89.59 % →
                // 100.00 %`: a measurement dressed as an instruction, and the
                // more prominent half of the finding.
                parameters: Vec::new(),
                confidence: 1.0,
                chain: Some(Chain {
                    cause: "the signal is hitting its ceiling, and everything above it never reaches the wheel".tr(ru)
                    .to_string(),
                    effect: Self::frames_phrase(
                        self.stats.ffb_clip_frames,
                        self.stats.total_frames,
                        ru,
                    ),
                    // The one rule whose check is not "next lap": clipping
                    // answers to a slider, and the answer arrives in the corner
                    // after it is moved.
                    confirm: "the clipping share after lowering the gain — near zero through corners".tr(ru)
                    .to_string(),
                    evidence: crate::confidence::Evidence::new(),
                }),
            });
        }
    }

    /// Name a set of corners the way an engineer would say it out loud.
    ///
    /// Four separate lines saying the same thing about four wheels is four of
    /// the overlay's slots spent on one fact, and the driver reads "FL COLD /
    /// FR COLD / RL COLD / RR COLD" as noise rather than as "the tyres are not
    /// up to temperature yet". Which is what it means.
    /// A frame count with something to measure it against.
    ///
    /// The driving rules all count frames over a lap, and a bare "412 frames"
    /// means nothing to anybody: it is 7 seconds on one circuit and 12 on
    /// another. The share of the lap is the part a driver can act on, so it is
    /// said when the denominator exists and quietly left out when it does not —
    /// a percentage of nothing is the sort of confident zero this project keeps
    /// having to remove.
    fn frames_phrase(frames: u32, total: u32, ru: bool) -> String {
        if total == 0 {
            return tr_fmt("{0} frames", ru, &[&frames.to_string()]);
        }
        let share = frames as f32 / total as f32 * 100.0;
        tr_fmt(
            "{0} frames of the lap ({1} %)",
            ru,
            &[&frames.to_string(), &format!("{share:.0}")],
        )
    }

    fn corner_phrase(corners: &[usize], ru: bool) -> String {
        match corners {
            [] => String::new(),
            [only] => CORNER_NAMES[*only].to_string(),
            [0, 1] => "Fronts".tr(ru).to_string(),
            [2, 3] => "Rears".tr(ru).to_string(),
            [0, 2] => "Left side".tr(ru).to_string(),
            [1, 3] => "Right side".tr(ru).to_string(),
            [0, 1, 2, 3] => "All four".tr(ru).to_string(),
            many => many
                .iter()
                .map(|index| CORNER_NAMES[*index])
                .collect::<Vec<_>>()
                .join("/"),
        }
    }

    /// The same phrase, for the middle of a sentence rather than the start of
    /// one.
    ///
    /// `corner_phrase` is capitalised because every message begins with it.
    /// The chain's `confirm` does not — "the hot pressure on All four after two
    /// laps" is the sort of thing that reads as machine-generated, which is
    /// exactly what this advice is trying not to sound like.
    ///
    /// Lowercased only when the phrase is a word. `FL`, `RR` and `FL/RR` are
    /// names and stay as they are — a blanket `to_lowercase` would print "fl",
    /// which is worse than the capital it fixed.
    fn corner_phrase_mid(corners: &[usize], ru: bool) -> String {
        let phrase = Self::corner_phrase(corners, ru);
        if phrase.chars().any(|c| c.is_lowercase()) {
            let mut chars = phrase.chars();
            match chars.next() {
                Some(first) => first.to_lowercase().collect::<String>() + chars.as_str(),
                None => phrase,
            }
        } else {
            phrase
        }
    }

    fn analyze_tyre_pressure(
        &mut self,
        car: &Car,
        session: &Session,
        recs: &mut Vec<Recommendation>,
    ) {
        let ru = self.is_ru();

        let compound_name = session.compound.to_string().to_lowercase();

        let class_name = compound_band(&compound_name);

        // A green track needs a little more pressure to reach the same
        // working range, and this is where that is added. It is gated,
        // because a game that publishes no grip figure leaves zero — which
        // clamps to 0.80 and adds the full 0.3 psi to the target on every lap
        // of every session, for a condition nobody measured. Competizione is
        // that game: it says how the track *is* by name instead.
        let grip_compensation = if self.capabilities.track_grip {
            (1.0 - session.surface_grip.clamp(0.80, 1.0)) * 1.5
        } else {
            0.0
        };
        // **Per corner, because the target is.** A GT3 runs the same figure at
        // both ends and a touring car does not, and the front axle of a car
        // whose driver has typed a front number of their own has nothing to do
        // with what the rear should be at. The grip allowance is the same at
        // all four: it is a property of the track, not of the axle.
        let target: [f32; 4] = std::array::from_fn(|i| {
            hot_pressure(&self.config, self.car_class, self.car_tyres, i) + grip_compensation
        });

        let mut low: Vec<usize> = Vec::new();
        let mut high: Vec<usize> = Vec::new();

        for (i, want) in target.iter().enumerate() {
            let pressure = car.tyre_pressure_psi[i];
            let (pressure_min, pressure_max) =
                pressure_window(&self.config, self.car_class, self.car_tyres, i);
            let is_error = pressure < pressure_min || pressure > pressure_max;

            let key = format!("pres_{}", i);
            if !self.check_hysteresis(&key, is_error) || car.speed_kmh <= 10.0 || !is_error {
                continue;
            }

            if pressure < *want {
                low.push(i);
            } else {
                high.push(i);
            }
        }

        // Units, at last. The temperature analyser has gone through the
        // formatter since it was written; this one printed raw psi, so anyone
        // working in bar read their pressures in one unit on the Dashboard and
        // another in the advice about them.
        let formatter = self.config.formatter();

        let mut push = |corners: &[usize], inflate: bool| {
            if corners.is_empty() {
                return;
            }
            let average = corners
                .iter()
                .map(|i| car.tyre_pressure_psi[*i])
                .sum::<f32>()
                / corners.len() as f32;
            // The group's target, which is one number when the group is one
            // axle and the mean of two when a finding spans both.
            let optimal_pressure =
                corners.iter().map(|i| target[*i]).sum::<f32>() / corners.len() as f32;
            let difference = (average - optimal_pressure).abs();

            recs.push(Recommendation {
                component: tr_fmt("Tyres ({0})", ru, &[class_name]),
                category: "Pressure".tr(ru).to_string(),
                // A pressure a full unit off the target changes how the car
                // turns; half of one is a setup working as intended.
                severity: if difference > 2.5 {
                    Severity::Warning
                } else {
                    Severity::Info
                },
                message: format!(
                    "{} {}: {} ({} {})",
                    Self::corner_phrase(corners, ru),
                    "pressure".tr(ru),
                    formatter.format_pressure(average),
                    "target".tr(ru),
                    formatter.format_pressure(optimal_pressure)
                ),
                action: if inflate {
                    "Inflate".tr(ru)
                } else {
                    "Deflate".tr(ru)
                }
                .to_string(),
                parameters: corners
                    .iter()
                    .map(|i| Parameter {
                        name: CORNER_NAMES[*i].to_string(),
                        current: car.tyre_pressure_psi[*i],
                        target: target[*i],
                        unit: formatter.pressure_symbol().to_string(),
                    })
                    .collect(),
                confidence: 0.9,
                // Hot pressure is not something the driver sets. It is the cold
                // setting plus whatever the tyre has been made to absorb, so the
                // cause is on one side of that and the fix is on the other —
                // which is exactly what makes this worth stating rather than
                // printing a number against a target.
                chain: Some(Chain {
                    cause: if inflate {
                        "the tyre is not building enough heat to reach the window"
                    } else {
                        "the tyre is building more pressure than the cold setting allows for"
                    }
                    .tr(ru)
                    .to_string(),
                    effect: format!(
                        "{} {} ({} {})",
                        Self::corner_phrase(corners, ru),
                        formatter.format_pressure(average),
                        "target".tr(ru),
                        formatter.format_pressure(optimal_pressure)
                    ),
                    confirm: tr_fmt(
                        "the hot pressure on {0} after two laps at pace: {1} is the target",
                        ru,
                        &[
                            &Self::corner_phrase_mid(corners, ru),
                            &formatter.format_pressure(optimal_pressure),
                        ],
                    ),
                    // One observation per corner in the group, each a live
                    // reading rather than an average — so two corners agreeing
                    // is Medium and all four are High, which is the right shape
                    // for a measurement this direct.
                    evidence: crate::confidence::Evidence::from_values(
                        corners
                            .iter()
                            .map(|i| car.tyre_pressure_psi[*i] - target[*i]),
                    ),
                }),
            });
        };

        push(&low, true);
        push(&high, false);
    }

    fn analyze_tyre_wear(&mut self, car: &Car, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();

        // AC counts wear down from 100, so all four corners reading zero is not
        // four destroyed tyres — it is a session that has not published wear
        // yet. Without this the panel opens with four CRITICAL lines telling a
        // driver who just left the pits that every tyre is gone, which is the
        // kind of thing that gets an engineer ignored for the rest of the race.
        if car.tyre_wear.iter().all(|wear| *wear <= 0.0) {
            return;
        }

        let warning_threshold = self.config.alerts.wear_warning;
        // Its own threshold, not `warning - 2`. That derivation made a tyre at
        // 93.9 % life a CRITICAL "WORN OUT" with the default settings, which is
        // a tyre most of the way through its first stint.
        let critical_threshold = self
            .config
            .alerts
            .wear_critical
            .min(self.config.alerts.wear_warning);

        let mut worn: Vec<usize> = Vec::new();
        let mut critical: Vec<usize> = Vec::new();

        for (i, wear) in car.tyre_wear.iter().copied().enumerate() {
            let is_worn = wear < warning_threshold;
            // The hysteresis is still per corner: it is per-corner state, and
            // one wheel picking up a flat spot should not reset the timers on
            // the other three. Only the reporting is grouped.
            if !self.check_hysteresis(&format!("wear_{}", i), is_worn) || !is_worn {
                continue;
            }
            if wear < critical_threshold {
                critical.push(i);
            } else {
                worn.push(i);
            }
        }

        // Read off before the closure: it needs them for the chain, and the
        // closure must not hold a borrow of `self` while `recs` is being
        // written through.
        let stint_laps = self.stats.stint_laps;
        let laps_left = self.stats.tyre_laps_remaining;

        let mut push = |corners: &[usize], severity: Severity| {
            if corners.is_empty() {
                return;
            }
            let lowest = corners
                .iter()
                .map(|i| car.tyre_wear[*i])
                .fold(f32::MAX, f32::min);
            let where_ = Self::corner_phrase(corners, ru);
            let where_low = Self::corner_phrase_mid(corners, ru);
            let what = if severity == Severity::Critical {
                "WORN OUT"
            } else {
                "high wear"
            }
            .tr(ru);

            recs.push(Recommendation {
                component: "Tyres".tr(ru).to_string(),
                category: "Wear".tr(ru).to_string(),
                severity,
                message: format!("{where_} {what}: {lowest:.1}%"),
                action: "Box / Careful".tr(ru)
                .to_string(),
                // **No parameters, because tyre life is not a setting.**
                //
                // This emitted one per corner — `FL life 89.59 % → 100.00 %` —
                // and a `Parameter` is the setting to change and the number to
                // change it to. Nobody can turn a tyre back to a hundred
                // percent; they stop, which is what the action already says.
                // The screen drew four rows of instruction that could not be
                // followed, above an action that could.
                //
                // Which corner is worst is worth knowing and belongs below, in
                // the effect, where it is an observation rather than an order.
                parameters: Vec::new(),
                confidence: 0.9,
                // Wear is the one finding whose cause is simply time: this set
                // has done these laps. What makes it worth chaining is the
                // check — a percentage means nothing to a driver deciding
                // whether to stop, and laps left does.
                chain: Some(Chain {
                    // A stint of zero laps is a real state rather than a missing
                    // number — a set can be past the warning before the first
                    // lap is complete — and "0 laps on this set" as the reason
                    // reads as a broken sentence rather than as the truth it is.
                    cause: if stint_laps > 0 {
                        tr_fmt("{0} laps on this set", ru, &[&stint_laps.to_string()])
                    } else {
                        "no complete lap on this set yet".tr(ru).to_string()
                    },
                    // Every corner in the group, not only the worst of them:
                    // a set wearing evenly and a set with one corner going are
                    // different problems, and the four numbers are the only
                    // thing that tells them apart. They used to be four rows
                    // of parameters; they are one line of measurement now.
                    effect: {
                        let each = corners
                            .iter()
                            .map(|i| {
                                format!("{} {:.1} %", CORNER_NAMES[*i], car.tyre_wear[*i])
                            })
                            .collect::<Vec<_>>()
                            .join(", ");
                        format!("{where_} {lowest:.1}% \u{2014} {each}")
                    },
                    confirm: {
                        // From the worst corner in the group, not the average:
                        // a set is finished when one corner is.
                        let soonest = corners
                            .iter()
                            .map(|i| laps_left[*i])
                            .fold(f32::MAX, f32::min);
                        if soonest.is_finite() && soonest > 0.0 {
                            tr_fmt(
                                "the life on {0} at the end of the next lap: ~{1} laps left at this rate",
                                ru,
                                &[&where_low, &format!("{soonest:.0}")],
                            )
                        } else {
                            tr_fmt(
                                "the life on {0} at the end of the next lap",
                                ru,
                                &[&where_low],
                            )
                        }
                    },
                    // How far past the warning each corner is, rather than the
                    // life itself: four corners at 88–91 % are all a long way
                    // from zero and would agree trivially on the raw number.
                    evidence: crate::confidence::Evidence::from_values(
                        corners
                            .iter()
                            .map(|i| warning_threshold - car.tyre_wear[*i]),
                    ),
                }),
            });
        };

        push(&critical, Severity::Critical);
        push(&worn, Severity::Warning);
    }

    /// The camber a wheel is running, in degrees, in the car's frame rather
    /// than the wheel's own.
    ///
    /// AC publishes `camberRAD` per wheel, and the two sides mirror each other:
    /// an abarth500 sitting in the pits with the same setting on both front
    /// wheels reads -0.023 rad on the left and +0.021 on the right. Negating
    /// the right-hand corners puts all four on one scale, where negative means
    /// the top of the tyre leans in — which is what a driver means by camber.
    /// Public because the probe prints it beside the tread it explains: the
    /// mirrored sign is the kind of thing a second copy gets wrong.
    pub fn camber_degrees(car: &Car, corner: usize) -> f32 {
        let sign = if corner == 1 || corner == 3 {
            -1.0
        } else {
            1.0
        };
        car.camber_rad[corner].to_degrees() * sign
    }

    /// Cornering ticks needed before the camber average is worth publishing.
    /// 60 ticks is a second of load, which is one long corner or two short
    /// ones — enough that the average is not a single frame of noise.
    const CAMBER_MIN_FRAMES: u32 = 60;

    /// What the inner and outer edges of a tyre say about its camber.
    ///
    /// Judged on `stats.camber_spread`, which is only sampled while the car is
    /// cornering — see the field. The instantaneous spread this used to read
    /// is near zero on every straight, so it published four Info lines about
    /// nothing every time the car left a corner.
    fn analyze_camber(&self, car: &Car, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();
        if self.stats.camber_frames < Self::CAMBER_MIN_FRAMES {
            return;
        }
        let fmt = self.config.formatter();
        let ideal_spread = 8.0;

        let mut too_little: Vec<usize> = Vec::new();
        let mut too_much: Vec<usize> = Vec::new();
        for i in 0..4 {
            let spread = self.stats.camber_spread[i];
            if spread < 2.0 {
                too_little.push(i);
            } else if spread > 15.0 {
                too_much.push(i);
            }
        }

        // Four corners of one problem are one problem — the same grouping the
        // wear and pressure advice does, and for the same reason: the panel
        // shows eight lines, and four of them saying "FL", "FR", "RL", "RR"
        // about one setting crowds out everything else the engineer noticed.
        let mut push = |corners: &[usize], more_camber: bool| {
            if corners.is_empty() {
                return;
            }
            let where_ = Self::corner_phrase(corners, ru);
            // The worst corner of the group is the one worth naming: the
            // furthest from the window for too little camber, the hottest
            // inner edge for too much.
            let spread = corners
                .iter()
                .map(|i| self.stats.camber_spread[*i])
                .fold(f32::NAN, if more_camber { f32::min } else { f32::max });
            // AC publishes the camber it is running, so the advice can say what
            // to change *from*. The setup file cannot: `CAMBER_LF VALUE=-9` is
            // a step index into a range that lives inside the car's `data.acd`,
            // and printing it read as "now: -9" beside a car showing -1.3°.
            let now = corners
                .iter()
                .map(|i| Self::camber_degrees(car, *i))
                .sum::<f32>()
                / corners.len() as f32;
            let now_clause = if now.abs() > 0.05 {
                format!(" ({}: {now:.1}°)", "now".tr(ru))
            } else {
                String::new()
            };

            recs.push(Recommendation {
                component: "Suspension".tr(ru).to_string(),
                category: "Camber".tr(ru).to_string(),
                severity: if more_camber {
                    Severity::Info
                } else {
                    Severity::Warning
                },
                // The message hardcoded "C" while the parameter beside it
                // was labelled with the configured symbol, so with
                // Fahrenheit selected the user saw a Celsius number
                // labelled °F. A spread is a difference, so it converts
                // by scale only -- `format_temp` would add 32.
                // **Say which edge is hot, not that a patch is "inefficient".**
                // A driver who reads "contact patch inefficient" beside a
                // negative I-O has to work out for himself that the number
                // means the outer edge — and one who has just set three and a
                // half degrees of negative camber reasonably reads the advice
                // as contradicting his own car. The debrief has said which
                // edge since it was written; this is the same three phrases.
                message: format!(
                    "{where_} {} (I-O: {})",
                    if !more_camber {
                        "inner edge overheating"
                    } else if spread < 0.0 {
                        "outer edge hotter"
                    } else {
                        "heated too evenly"
                    }
                    .tr(ru),
                    fmt.format_temp_delta(spread)
                ),
                action: if more_camber {
                    tr_fmt(
                        "More neg. camber{0}. If maxed -> soften ARB",
                        ru,
                        &[&now_clause],
                    )
                } else {
                    tr_fmt(
                        "Less neg. camber{0}. If maxed -> stiffen ARB",
                        ru,
                        &[&now_clause],
                    )
                },
                // The inner-outer spread is what is *measured*; the camber is
                // what is turned, and this does not know it in degrees. The
                // effect and the confirm below already carry the spread and
                // the window it should land in, which is the same information
                // without pretending to be a setting. See the wear rule.
                parameters: Vec::new(),
                confidence: if more_camber { 0.7 } else { 0.8 },
                // The one rule that can say why, what it did, and how to know
                // whether the change worked — and the one the plan names,
                // because a camber verdict from a single cornering frame is
                // how this project learned to distrust its own certainty.
                //
                // The evidence is one observation per wheel in the group, each
                // already the mean of at least `CAMBER_MIN_FRAMES` frames of
                // load. That is what `averaged_over` is for: two settled
                // wheels are a finding, two frames are not, and the frame gate
                // above stops being a bolted-on precondition and becomes part
                // of how sure the advice says it is.
                chain: Some(Chain {
                    // **Which shoulder is working, the right way round.** Too
                    // little negative camber means the tyre stands up in a
                    // corner and the *outer* shoulder takes the load — that is
                    // why the advice is more camber. This said the outer
                    // shoulder was not being loaded, which is the reason to do
                    // the opposite, beside an action that did this. The
                    // debrief's wording for the same two cases, which is the
                    // one that was right.
                    cause: if more_camber {
                        "the tyre is standing too upright, so the outer shoulder takes the load in a corner"
                    } else {
                        "the tyre is leaning far enough that the inner shoulder carries the corner alone"
                    }
                    .tr(ru)
                    .to_string(),
                    effect: format!("{where_} I-O {}", fmt.format_temp_delta(spread)),
                    confirm: tr_fmt(
                        "the I/M/O spread on {0} next run out: {1} is the window",
                        ru,
                        &[&where_, &fmt.format_temp_delta(ideal_spread)],
                    ),
                    evidence: crate::confidence::Evidence::from_values(
                        corners.iter().map(|i| self.stats.camber_spread[*i]),
                    )
                    .averaged_over(self.stats.camber_frames),
                }),
            });
        };

        push(&too_much, false);
        push(&too_little, true);
    }

    /// The tyre temperature this game actually measures, per wheel.
    ///
    /// The mean of the tread where the game publishes the tread, and the core
    /// where it does not. **Off the capabilities rather than off the numbers**:
    /// `Car::avg_tyre_temp_c` falls back when the tread reads zero, which is
    /// the right rule for drawing a screen and the wrong one for a verdict —
    /// a game that says it measures no tread must not have its tread fields
    /// judged, whatever happens to be in them.
    fn judged_tyre_temp(&self, car: &Car, wheel: usize) -> f32 {
        if wheel >= 4 {
            return 0.0;
        }
        if self.capabilities.tyre_edge_temps {
            (car.tyre_temp_inner_c[wheel]
                + car.tyre_temp_middle_c[wheel]
                + car.tyre_temp_outer_c[wheel])
                / 3.0
        } else {
            car.tyre_core_temp_c[wheel]
        }
    }

    fn analyze_tyre_temperature(&mut self, car: &Car, recs: &mut Vec<Recommendation>) {
        // Nothing measured at all — a session that has not published yet, or a
        // game that reports no tyre temperature of any kind. Four zeros is not
        // four frozen tyres, and it is the same guard the wear rule needs.
        if (0..4).all(|i| self.judged_tyre_temp(car, i) <= 0.0) {
            return;
        }

        // The window this class of car actually works in — see
        // `Engineer::tyre_window`, which falls back to the driver's own
        // numbers the moment they set any.
        let (min_temp, max_temp) = self.tyre_window();
        let ru = self.is_ru();

        if car.speed_kmh <= 100.0 {
            return;
        }

        let mut cold: Vec<usize> = Vec::new();
        let mut hot: Vec<usize> = Vec::new();

        for i in 0..4 {
            let temp = self.judged_tyre_temp(car, i);
            let out_of_band = temp < min_temp || temp > max_temp;
            // Same gate as the pressure and wear alerts. This ran on every
            // frame, so a tyre that stayed cold produced a fresh recommendation
            // dozens of times a second.
            if !self.check_hysteresis(&format!("tyre_temp_{}", i), out_of_band) {
                continue;
            }
            if temp < min_temp {
                cold.push(i);
            } else if temp > max_temp {
                hot.push(i);
            }
        }

        let formatter = self.config.formatter();
        // Which reading this verdict is about. A core temperature runs hotter
        // than the surface it is under, so a driver comparing it with a number
        // from a game that publishes the tread has to be told which they are
        // looking at.
        let measured = if self.capabilities.tyre_edge_temps {
            "tread".tr(ru)
        } else {
            "core".tr(ru)
        };

        if !cold.is_empty() {
            let average = cold
                .iter()
                .map(|i| self.judged_tyre_temp(car, *i))
                .sum::<f32>()
                / cold.len() as f32;
            recs.push(Recommendation {
                component: "Tyres".tr(ru).to_string(),
                category: "Temperature".tr(ru).to_string(),
                severity: Severity::Warning,
                message: format!(
                    "{} {}: {} ({measured})",
                    Self::corner_phrase(&cold, ru),
                    "COLD".tr(ru),
                    formatter.format_temp(average)
                ),
                action: "Warm tyres".tr(ru).to_string(),
                parameters: vec![],
                confidence: 0.95,
                chain: Some(Chain {
                    cause: "not enough energy is going into the tyre to bring it into its window"
                        .tr(ru)
                        .to_string(),
                    effect: format!(
                        "{} {} ({} {})",
                        Self::corner_phrase(&cold, ru),
                        formatter.format_temp(average),
                        "window from".tr(ru),
                        formatter.format_temp(min_temp)
                    ),
                    confirm: tr_fmt(
                        "the temperature on {0} after a lap at pace: the window starts at {1}",
                        ru,
                        &[
                            &Self::corner_phrase_mid(&cold, ru),
                            &formatter.format_temp(min_temp),
                        ],
                    ),
                    evidence: crate::confidence::Evidence::from_values(
                        cold.iter()
                            .map(|i| min_temp - self.judged_tyre_temp(car, *i)),
                    ),
                }),
            });
        }

        if !hot.is_empty() {
            let average = hot
                .iter()
                .map(|i| self.judged_tyre_temp(car, *i))
                .sum::<f32>()
                / hot.len() as f32;
            recs.push(Recommendation {
                component: "Tyres".tr(ru).to_string(),
                category: "Overheat".tr(ru).to_string(),
                severity: Severity::Critical,
                message: format!(
                    "{} {}: {} ({measured})",
                    Self::corner_phrase(&hot, ru),
                    "OVERHEATING".tr(ru),
                    formatter.format_temp(average)
                ),
                action: "Cool tyres".tr(ru).to_string(),
                parameters: vec![],
                confidence: 0.95,
                // Deliberately vague about the mechanism, because there are
                // three and this rule cannot tell them apart from a temperature
                // alone: too little pressure, too much slip, or a car simply
                // being asked for more than the compound has. Naming one would
                // be a guess dressed as a diagnosis; the check is the same
                // whichever it is.
                chain: Some(Chain {
                    cause: "the tyre is being given more energy than it can shed"
                        .tr(ru)
                        .to_string(),
                    effect: format!(
                        "{} {} ({} {})",
                        Self::corner_phrase(&hot, ru),
                        formatter.format_temp(average),
                        "window to".tr(ru),
                        formatter.format_temp(max_temp)
                    ),
                    confirm: tr_fmt(
                        "the temperature on {0} a lap after the change: the window ends at {1}",
                        ru,
                        &[
                            &Self::corner_phrase_mid(&hot, ru),
                            &formatter.format_temp(max_temp),
                        ],
                    ),
                    evidence: crate::confidence::Evidence::from_values(
                        hot.iter()
                            .map(|i| self.judged_tyre_temp(car, *i) - max_temp),
                    ),
                }),
            });
        }
    }

    fn analyze_brakes(&mut self, car: &Car, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();
        // Reported against whichever axle's ceiling was actually exceeded, so
        // the sentence names a number that applies to the corner it is about.
        let max_temp = (0..4)
            .filter(|i| car.brake_temp_c[*i] > self.brake_ceiling(*i))
            .map(|i| self.brake_ceiling(i))
            .fold(f32::MAX, f32::min);
        let max_temp = if max_temp.is_finite() {
            max_temp
        } else {
            self.brake_ceiling(0)
        };

        let mut cooking: Vec<usize> = Vec::new();
        for i in 0..4 {
            // Gated the way the pressure and wear alerts already are. Without
            // it this pushed a fresh recommendation on every single frame the
            // brake was over temperature — dozens a second, burying every
            // other message in the list.
            let too_hot = car.brake_temp_c[i] > self.brake_ceiling(i);
            if self.check_hysteresis(&format!("brake_temp_{}", i), too_hot) && too_hot {
                cooking.push(i);
            }
        }

        if cooking.is_empty() {
            return;
        }

        // Both front brakes overheating is one thing to say, not two. The
        // corner names are FL/FR/RL/RR the way every neighbouring alert says
        // them — this used to number them "Brake 1" to "Brake 4", the only
        // place in the application that did.
        let hottest = cooking
            .iter()
            .map(|i| car.brake_temp_c[*i])
            .fold(0.0_f32, f32::max);
        let formatter = self.config.formatter();

        recs.push(Recommendation {
            component: "Brakes".tr(ru).to_string(),
            category: "Overheat".tr(ru).to_string(),
            severity: Severity::Critical,
            message: format!(
                "{} {}: {}",
                Self::corner_phrase(&cooking, ru),
                "brakes cooking".tr(ru),
                formatter.format_temp(hottest)
            ),
            action: "Move bias / Cool down".tr(ru).to_string(),
            parameters: vec![],
            confidence: 1.0,
            chain: Some(Chain {
                cause: "more energy is going into the brakes than they can shed"
                    .tr(ru)
                    .to_string(),
                effect: format!(
                    "{} {} ({} {})",
                    Self::corner_phrase(&cooking, ru),
                    formatter.format_temp(hottest),
                    "ceiling".tr(ru),
                    formatter.format_temp(max_temp)
                ),
                confirm: tr_fmt(
                    "the peak on {0} through the next lap: {1} is the ceiling",
                    ru,
                    &[
                        &Self::corner_phrase_mid(&cooking, ru),
                        &formatter.format_temp(max_temp),
                    ],
                ),
                evidence: crate::confidence::Evidence::from_values(
                    cooking.iter().map(|i| car.brake_temp_c[*i] - max_temp),
                ),
            }),
        });
    }

    /// How much brake is left, on a game that measures it.
    ///
    /// This is Competizione's answer to tyre wear, which it does not publish:
    /// over a GT3 stint the pads are the consumable that decides the race, and
    /// a driver who has to stop for pads and does not know it loses far more
    /// than a set of tyres.
    ///
    /// **The thresholds are millimetres and they are the honest kind of
    /// approximate.** A GT3 pad in ACC starts around 29 mm and a disc around
    /// 32; teams change pads long before there is nothing left, and the disc
    /// has a minimum well above zero. So the warning is set where a stop
    /// becomes worth planning rather than where the part fails, and the
    /// critical one where it stops being a plan. Both are the first thing to
    /// check against a real stint — see `docs/plan-acc.md` §10 — and neither
    /// is invented from nothing: they are the numbers the game's own dash
    /// treats as low.
    fn analyze_brake_wear(&mut self, car: &Car, recs: &mut Vec<Recommendation>) {
        /// Pad thickness, in mm, at which a stop is worth planning.
        const PAD_WARNING_MM: f32 = 12.0;
        /// ...and at which it stops being a plan.
        const PAD_CRITICAL_MM: f32 = 8.0;
        /// Discs wear far more slowly and from a much narrower range.
        const DISC_WARNING_MM: f32 = 29.0;
        const DISC_CRITICAL_MM: f32 = 27.5;

        let ru = self.is_ru();

        // The same guard the tyre-wear rule needs, for the same reason: a
        // session that has not published yet reads as four corners with no
        // brakes left, which is a CRITICAL line at the moment a driver leaves
        // the pits and the fastest way to be ignored for the rest of the race.
        if car.brake_pad_mm.iter().all(|mm| *mm <= 0.0) {
            return;
        }

        let mut low: Vec<usize> = Vec::new();
        let mut critical: Vec<usize> = Vec::new();
        for (i, pad) in car.brake_pad_mm.iter().copied().enumerate() {
            let is_low = pad < PAD_WARNING_MM;
            if !self.check_hysteresis(&format!("pad_{i}"), is_low) || !is_low {
                continue;
            }
            if pad < PAD_CRITICAL_MM {
                critical.push(i);
            } else {
                low.push(i);
            }
        }

        // The disc is a separate part with a separate life, and a car can
        // easily be fine on one and not the other.
        let thin_discs: Vec<usize> = (0..4)
            .filter(|i| {
                let thin = car.brake_disc_mm[*i] > 0.0 && car.brake_disc_mm[*i] < DISC_WARNING_MM;
                self.check_hysteresis(&format!("disc_{i}"), thin) && thin
            })
            .collect();

        let mut push = |corners: &[usize], severity: Severity, disc: bool| {
            if corners.is_empty() {
                return;
            }
            let measure = |i: &usize| {
                if disc {
                    car.brake_disc_mm[*i]
                } else {
                    car.brake_pad_mm[*i]
                }
            };
            let lowest = corners.iter().map(measure).fold(f32::MAX, f32::min);
            let floor = if disc {
                DISC_CRITICAL_MM
            } else {
                PAD_CRITICAL_MM
            };
            let where_ = Self::corner_phrase(corners, ru);
            let where_low = Self::corner_phrase_mid(corners, ru);
            let is_critical = severity == Severity::Critical;
            let what = if disc {
                "disc thin".tr(ru)
            } else if is_critical {
                "PADS DONE".tr(ru)
            } else {
                "pads low".tr(ru)
            };

            recs.push(Recommendation {
                component: "Brakes".tr(ru).to_string(),
                category: "Wear".tr(ru).to_string(),
                severity,
                message: format!("{where_} {what}: {lowest:.1} mm"),
                action: if is_critical {
                    "Box".tr(ru).to_string()
                } else {
                    "Plan a stop".tr(ru).to_string()
                },
                // Pad and disc thickness is replaced, not set: the action is
                // to stop. Every corner is named in the effect instead, where
                // it is measurement — and all of them rather than the lowest,
                // because one pad going and four going evenly are different
                // problems.
                parameters: Vec::new(),
                confidence: 0.9,
                chain: Some(Chain {
                    cause: "braking energy is worn off the friction material, and there \
                            is a finite amount of it"
                        .tr(ru)
                        .to_string(),
                    effect: {
                        let each = corners
                            .iter()
                            .map(|i| format!("{} {:.1} mm", CORNER_NAMES[*i], measure(i)))
                            .collect::<Vec<_>>()
                            .join(", ");
                        format!("{where_} {lowest:.1} mm \u{2014} {each}")
                    },
                    // Millimetres mean nothing to a driver deciding whether to
                    // stop; how fast they are going does. Two laps apart is
                    // the measurement that answers it, and it is one the
                    // driver can take without any tool but this screen.
                    confirm: tr_fmt(
                        "the same figure on {0} two laps from now: below {1} mm it is a stop \
                         rather than a plan",
                        ru,
                        &[&where_low, &format!("{floor:.0}")],
                    ),
                    // How far below the warning each corner is, rather than
                    // the thickness itself: four pads at 11 mm agree trivially
                    // on the raw number and say nothing about spread.
                    evidence: crate::confidence::Evidence::from_values(corners.iter().map(|i| {
                        measure(i)
                            - if disc {
                                DISC_WARNING_MM
                            } else {
                                PAD_WARNING_MM
                            }
                    })),
                }),
            });
        };

        push(&critical, Severity::Critical, false);
        push(&low, Severity::Warning, false);
        push(&thin_discs, Severity::Warning, true);
    }

    fn analyze_brake_bias(&self, setup: Option<&CarSetup>, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();
        let total_lockups = self.stats.lockup_frames_front + self.stats.lockup_frames_rear;

        if total_lockups > 20 {
            let current_bias_str = if let Some(s) = setup {
                tr_fmt(" (NOW: {0}%)", ru, &[&s.brake_bias.to_string()])
            } else {
                "".to_string()
            };

            if self.stats.lockup_frames_front > self.stats.lockup_frames_rear * 2 {
                recs.push(Recommendation {
                    component: "Brakes".tr(ru).to_string(),
                    category: "Bias".tr(ru).to_string(),
                    severity: Severity::Warning,
                    message: tr_fmt("FRONT Locking detected{0}", ru, &[&current_bias_str]),
                    action: "Move Bias REARWARDS".tr(ru).to_string(),
                    parameters: vec![],
                    confidence: 0.85,
                    // Evidence left empty on purpose, and it is not laziness.
                    // What this rule has is two whole-lap counters, and two
                    // counts of *different* things are not two observations of
                    // one — feeding them to `Evidence` would measure how much
                    // the front disagrees with the rear, which is the finding
                    // rather than the corroboration. An empty evidence makes
                    // `confidence_level` fall back to the score above, which is
                    // the honest answer here.
                    chain: Some(Chain {
                        cause: "too much of the braking is landing on the front axle"
                            .tr(ru)
                            .to_string(),
                        effect: tr_fmt(
                            "{0} frames of front lock against {1} at the rear",
                            ru,
                            &[
                                &self.stats.lockup_frames_front.to_string(),
                                &self.stats.lockup_frames_rear.to_string(),
                            ],
                        ),
                        confirm: "front lockups next run out, after moving the bias back"
                            .tr(ru)
                            .to_string(),
                        evidence: crate::confidence::Evidence::new(),
                    }),
                });
            } else if self.stats.lockup_frames_rear > self.stats.lockup_frames_front * 2 {
                recs.push(Recommendation {
                    component: "Brakes".tr(ru).to_string(),
                    category: "Bias".tr(ru).to_string(),
                    severity: Severity::Critical,
                    message: tr_fmt("REAR Locking (Danger!){0}", ru, &[&current_bias_str]),
                    action: "Move Bias FORWARDS".tr(ru).to_string(),
                    parameters: vec![],
                    confidence: 0.95,
                    chain: Some(Chain {
                        cause: "too much of the braking is landing on the rear axle"
                            .tr(ru)
                            .to_string(),
                        effect: tr_fmt(
                            "{0} frames of rear lock against {1} at the front",
                            ru,
                            &[
                                &self.stats.lockup_frames_rear.to_string(),
                                &self.stats.lockup_frames_front.to_string(),
                            ],
                        ),
                        confirm: "rear lockups next run out, after moving the bias forward"
                            .tr(ru)
                            .to_string(),
                        evidence: crate::confidence::Evidence::new(),
                    }),
                });
            }
        }
    }

    fn analyze_driving_errors(&mut self, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();

        let is_coasting = self.stats.coasting_frames > 60;
        if self.check_hysteresis("coast", is_coasting) && is_coasting {
            recs.push(Recommendation {
                component: "Driving".tr(ru).to_string(),
                category: "Time Loss".tr(ru).to_string(),
                severity: Severity::Info,
                message: "Excessive Coasting".tr(ru).to_string(),
                action: "Keep throttle or brake".tr(ru).to_string(),
                parameters: vec![],
                confidence: 0.7,
                // The whole-lap counters below all carry a chain with empty
                // evidence, and that is the design rather than a gap: one
                // counter is one observation however large it gets, and
                // `Evidence` exists to count observations that *corroborate*
                // each other. An empty one makes `confidence_level` fall back
                // to the score beside it, which is what these rules have always
                // been judged on. What they gain is the other three fields —
                // the mechanism, the measurement, and something to check.
                chain: Some(Chain {
                    cause: "the car is rolling unloaded where it should be braking or driving"
                        .tr(ru)
                        .to_string(),
                    effect: Self::frames_phrase(
                        self.stats.coasting_frames,
                        self.stats.total_frames,
                        ru,
                    ),
                    confirm: "the share of the next lap spent on neither pedal"
                        .tr(ru)
                        .to_string(),
                    evidence: crate::confidence::Evidence::new(),
                }),
            });
        }

        // **One balance, and one finding about it.** These were two
        // independent counters with a threshold each, and a lap understeers
        // in one corner and oversteers in another — so both fired, and the
        // panel carried "High Speed Understeer / More Front Wing" directly
        // above "High Speed Oversteer / More Rear Wing". Two instructions
        // that undo each other are worse than either alone: a driver who
        // follows both has changed nothing and stopped believing the rest.
        //
        // Reported from a session on a 90s Miata, where both lines stood
        // together on a car that has neither wing.
        //
        // The larger count wins, and how much larger it is becomes the
        // confidence: a car that only ever understeers reads exactly as it
        // did before, and a car that does both in equal measure says so by
        // being unsure rather than by saying both.
        let (understeer, oversteer) = (self.stats.understeer_frames, self.stats.oversteer_frames);
        let leaning = understeer.max(oversteer);
        if leaning > 30 {
            let understeering = understeer >= oversteer;
            let margin = (leaning - understeer.min(oversteer)) as f32 / leaning as f32;
            // 0.5 when the two are level, and the 0.85 these rules have
            // always carried when one of them is the whole story.
            let confidence = 0.5 + 0.35 * margin;

            // The ladder is what this car can actually be changed by. A wing
            // if it has one, the springs or the bar if it has those, and
            // otherwise the four things every car with a setup screen has —
            // which is not a consolation prize on a road car, it is the
            // adjustment that car is actually tuned with.
            let action = if self.wing_to_adjust() {
                if understeering {
                    "More Front Wing / Softer Front".tr(ru)
                } else {
                    "More Rear Wing".tr(ru)
                }
            } else if self.mechanical_balance() {
                if understeering {
                    "Softer Front Springs or ARB".tr(ru)
                } else {
                    "Softer Rear Springs or ARB".tr(ru)
                }
            } else if understeering {
                "Lower Front Pressures or More Front Camber".tr(ru)
            } else {
                "Lower Rear Pressures or More Rear Camber".tr(ru)
            };

            recs.push(Recommendation {
                component: "Balance".tr(ru).to_string(),
                category: if understeering {
                    "Understeer".to_string()
                } else {
                    "Oversteer".to_string()
                },
                severity: Severity::Warning,
                message: if understeering {
                    "High Speed Understeer".tr(ru)
                } else {
                    "High Speed Oversteer".tr(ru)
                }
                .to_string(),
                action: action.to_string(),
                parameters: vec![],
                confidence,
                chain: Some(Chain {
                    cause: if understeering {
                        "the front axle runs out of grip before the rear at speed".tr(ru)
                    } else {
                        "the rear axle runs out of grip before the front at speed".tr(ru)
                    }
                    .to_string(),
                    effect: Self::frames_phrase(leaning, self.stats.total_frames, ru),
                    // Deliberately not "the car will understeer less": whether
                    // this is the car or the driving is a different question,
                    // and `driver_vs_car` is what answers it over a stint.
                    confirm: if understeering {
                        "the understeer count next run out, after the change".tr(ru)
                    } else {
                        "the oversteer count next run out, after the change".tr(ru)
                    }
                    .to_string(),
                    evidence: crate::confidence::Evidence::new(),
                }),
            });
        }

        let is_scrubbing = self.stats.scrubbing_frames > 45;
        if self.check_hysteresis("scrubbing", is_scrubbing) && is_scrubbing {
            let excess = self.stats.current_excess_steer;
            recs.push(Recommendation {
                component: "Driving".tr(ru).to_string(),
                category: "Overdriving".tr(ru).to_string(),
                severity: Severity::Warning,
                message: tr_fmt(
                    "Steering over-rotated by {0}°! Tyres sliding.",
                    ru,
                    &[&format!("{excess:.0}")],
                ),
                action: tr_fmt(
                    "Reduce steering angle by {0}°",
                    ru,
                    &[&format!("{excess:.0}")],
                ),
                parameters: vec![],
                confidence: 0.95,
                chain: Some(Chain {
                    cause: "more steering angle than the corner will take, so the tyres scrub"
                        .tr(ru)
                        .to_string(),
                    effect: tr_fmt(
                        "{0}, worst excess {1}°",
                        ru,
                        &[
                            &Self::frames_phrase(
                                self.stats.scrubbing_frames,
                                self.stats.total_frames,
                                ru,
                            ),
                            &format!("{excess:.0}"),
                        ],
                    ),
                    confirm: "the over-rotation count through the same corners next lap"
                        .tr(ru)
                        .to_string(),
                    evidence: crate::confidence::Evidence::new(),
                }),
            });
            self.stats.scrubbing_frames = 0;
            self.stats.current_excess_steer = 0.0;
        }
    }

    /// Fuel, and the two rules that deliberately have no chain.
    ///
    /// Every other rule in this file now states a mechanism, a measurement and
    /// something to check next time. These two do not, and the empty `chain`
    /// below is the finding rather than an omission:
    ///
    /// * there is **no mechanism** to state. "The fuel will not last" is
    ///   arithmetic on what is in the tank, not a chain of cause and effect —
    ///   writing one would mean inventing a story for a subtraction.
    /// * there is **nothing to check next time**, because the check is the same
    ///   number a lap later, and it is already on the screen. `confirm` exists
    ///   to make advice falsifiable; advice that restates its own input is
    ///   falsified by looking at it.
    ///
    /// A `Chain` filled in here would be three fields of ceremony that made the
    /// advice look better researched than it is, and that is the opposite of
    /// what the field is for.
    fn analyze_strategy(&self, car: &Car, session: &Session, recs: &mut Vec<Recommendation>) {
        let ru = self.is_ru();

        if self.stats.fuel_laps_remaining < self.config.alerts.fuel_warning_laps
            && self.stats.fuel_laps_remaining > 0.0
        {
            recs.push(Recommendation {
                component: "Strategy".tr(ru).to_string(),
                category: "Fuel".tr(ru).to_string(),
                severity: Severity::Critical,
                message: tr_fmt(
                    "FUEL LOW: {0} laps",
                    ru,
                    &[&format!("{:.1}", self.stats.fuel_laps_remaining)],
                ),
                action: "BOX BOX BOX".to_string(),
                parameters: vec![],
                confidence: 1.0,
                chain: None,
            });
        }

        // **Only a session that ends in a chequered flag.** This asks whether
        // the tank will see the finish, and practice, qualifying and superpole
        // have no finish to see: a clock counting down an hour of practice is
        // not a race distance, and the answer was "Short 5.7 L — save fuel or
        // box" to a driver doing exactly what practice is for. The Strategy
        // tab already knew the difference; the engineer did not, so the same
        // fact reached the driver two different ways.
        //
        // The FUEL LOW warning above is not gated and should not be: running
        // the tank dry ends a practice lap the same way it ends a race one.
        if !session.kind.has_no_finish()
            && (session.session_time_left_ms > 0.0 || session.total_laps > 0)
            && session.fuel_per_lap > 0.0
        {
            // Whole laps, not the display fraction: a timed race runs until
            // the leader completes the lap the clock ran out on, and the lap
            // already in progress still has to be finished.
            let laps_remaining_in_race = crate::session_info::SessionTiming::laps_to_fuel_for(
                session.session_time_left_ms,
                session.best_lap_ms,
                session.last_lap_ms,
                session.total_laps,
                session.completed_laps,
                session.track_position,
            );

            if laps_remaining_in_race > 0.0 {
                let fuel_needed = (laps_remaining_in_race * session.fuel_per_lap)
                    + self.config.fuel_safety_margin;
                let fuel_diff = car.fuel_litres - fuel_needed;

                if fuel_diff < -1.0 {
                    recs.push(Recommendation {
                        component: "Strategy".tr(ru).to_string(),
                        category: "Race Finish".tr(ru).to_string(),
                        severity: Severity::Warning,
                        message: tr_fmt("Short {0} L", ru, &[&format!("{:.1}", fuel_diff.abs())]),
                        action: "Save Fuel / Box".tr(ru).to_string(),
                        parameters: vec![Parameter {
                            name: "Need".to_string(),
                            current: car.fuel_litres,
                            target: fuel_needed,
                            unit: "L".to_string(),
                        }],
                        confidence: 0.8,
                        chain: None,
                    });
                }
            }
        }
    }
}

/// Which pressure band a compound belongs to, by name.
///
/// **Matched on substrings because the two games name compounds nothing
/// alike.** Assetto Corsa uses the tyre's own name — `street`, `sport`,
/// `semislick`, `wet` — and Competizione publishes exactly two, `dry_compound`
/// and `wet_compound`, whatever rubber is fitted underneath.
///
/// That difference was written down as a risk before anything measured it: an
/// ACC name matching none of AC's would fall through to the default band. It
/// does fall through, and the default is the right answer — every car in ACC
/// is a racing car on slicks, so `dry_compound` belongs in `Racing`, and
/// `wet_compound` reaches `Wet` on the substring it happens to share. Correct
/// by construction on one game and by luck on the other, which is exactly the
/// kind of thing that survives until somebody edits this list. Hence the
/// tests below naming both games' strings.
fn compound_band(compound_name: &str) -> &'static str {
    if compound_name.contains("street")
        || compound_name.contains("sport")
        || compound_name.contains("eco")
        || compound_name.contains("semislick")
    {
        "Street"
    } else if compound_name.contains("wet") || compound_name.contains("rain") {
        "Wet"
    } else {
        "Racing"
    }
}

#[cfg(test)]
mod compound_tests {
    use super::compound_band;

    /// The names Assetto Corsa publishes.
    #[test]
    fn assetto_corsa_compounds_land_where_they_should() {
        assert_eq!(compound_band("street"), "Street");
        assert_eq!(compound_band("sport"), "Street");
        assert_eq!(compound_band("semislick"), "Street");
        assert_eq!(compound_band("eco"), "Street");
        assert_eq!(compound_band("wet"), "Wet");
        assert_eq!(compound_band("rain"), "Wet");
        assert_eq!(compound_band("slicks (soft)"), "Racing");
    }

    /// The two Competizione publishes, read off the session recording in
    /// `tests_suite`: the graphics page carries `dry_compound` at offset 176.
    /// A GT3 on slicks must not be given a road car's target.
    #[test]
    fn competizione_compounds_land_where_they_should() {
        assert_eq!(
            compound_band("dry_compound"),
            "Racing",
            "every ACC car is a racing car on slicks"
        );
        assert_eq!(compound_band("wet_compound"), "Wet");
    }
}

#[cfg(test)]
mod tests {

    /// The simulator publishes zero wear until a lap is done, and so does a
    /// real session before its first update. Neither means the tyres are gone.
    #[test]
    fn wear_of_zero_on_every_corner_is_no_data_rather_than_four_dead_tyres() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);

        let mut car = Car {
            tyre_wear: [0.0; 4],
            ..Default::default()
        };
        let mut recs = Vec::new();
        engineer.analyze_tyre_wear(&car, &mut recs);
        assert!(recs.is_empty(), "no wear data means no wear advice");

        // One corner reporting something plausible is data, and a corner at 40%
        // in that state is worth saying out loud. Alerts are held back for a
        // second before they are reported, so the timer is aged by hand here
        // rather than by sleeping through it.
        car.tyre_wear = [98.0, 97.0, 40.0, 96.0];
        let aged = std::time::Instant::now() - std::time::Duration::from_secs(2);
        engineer
            .alert_timers
            .insert("wear_2".to_string(), (aged, std::time::Instant::now()));

        let mut recs = Vec::new();
        engineer.analyze_tyre_wear(&car, &mut recs);
        assert!(
            recs.iter().any(|rec| rec.message.contains("RL")),
            "the worn corner is reported once there is data: {recs:?}"
        );
    }
    use super::{Engineer, Severity, WizardProblem, hot_pressure, pressure_window};
    use crate::config::{AppConfig, PressureUnit};
    use crate::games::{Capabilities, Car, CarClass, Session};

    /// Age every alert timer past the one-second hold, so a test does not have
    /// to sleep through it.
    fn age_the_alerts(engineer: &mut Engineer) {
        let aged = std::time::Instant::now() - std::time::Duration::from_secs(2);
        let now = std::time::Instant::now();
        for key in [
            "wear_0",
            "wear_1",
            "wear_2",
            "wear_3",
            "tyre_temp_0",
            "tyre_temp_1",
            "tyre_temp_2",
            "tyre_temp_3",
            "pres_0",
            "pres_1",
            "pres_2",
            "pres_3",
            "brake_temp_0",
            "brake_temp_1",
            "brake_temp_2",
            "brake_temp_3",
            "pad_0",
            "pad_1",
            "pad_2",
            "pad_3",
            "disc_0",
            "disc_1",
            "disc_2",
            "disc_3",
        ] {
            engineer.alert_timers.insert(key.to_string(), (aged, now));
        }
    }

    /// Every rule that has a mechanism states one, and the two that do not say
    /// why in prose next to the `None`.
    ///
    /// Read off the source rather than off the output, and deliberately so: a
    /// behavioural test can only check the rules it manages to trigger, and the
    /// failure this guards against is a *new* rule added six months from now
    /// with `chain: None` copied from its neighbour. There is no telemetry that
    /// would provoke a rule nobody has written yet; there is a `grep`.
    #[test]
    fn no_rule_outside_the_fuel_pair_ships_without_an_explanation() {
        let source = include_str!("engineer.rs");
        let strategy = source
            .find("fn analyze_strategy")
            .expect("analyze_strategy is where the two exceptions live");
        // The function runs to the end of the `impl` block, which is the last
        // thing in it — everything after `mod tests` is this file's own tests
        // and has no rules in it.
        let tests = source.find("\nmod tests {").unwrap_or(source.len());

        let unexplained = source[..strategy].matches("chain: None").count();
        assert_eq!(
            unexplained, 0,
            "a rule before analyze_strategy has no chain. Either give it a \
             cause, an effect and something to check next run, or move it \
             beside the fuel rules and write down why it cannot have one."
        );

        let excused = source[strategy..tests].matches("chain: None").count();
        assert_eq!(
            excused, 2,
            "the fuel rules are the only two without a chain; if that changed, \
             the doc comment on analyze_strategy has to change with it"
        );
    }

    /// The rules a driver sees most can all say why, what, and what to check.
    ///
    /// The companion to the test above: that one proves nothing was left out,
    /// this one proves what was put in is not three empty strings.
    #[test]
    fn the_advice_a_driver_actually_sees_carries_a_usable_chain() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        // Over pressure, over temperature, cooking brakes and a worn set, all
        // at once — four different analysers, four different shapes of chain.
        let car = Car {
            tyre_pressure_psi: [31.0, 31.2, 30.8, 31.1],
            tyre_core_temp_c: [120.0; 4],
            tyre_temp_inner_c: [120.0; 4],
            tyre_temp_middle_c: [120.0; 4],
            tyre_temp_outer_c: [120.0; 4],
            brake_temp_c: [900.0, 910.0, 880.0, 895.0],
            tyre_wear: [80.0, 81.0, 79.0, 82.0],
            speed_kmh: 180.0,
            ..Default::default()
        };
        let session = Session {
            surface_grip: 1.0,
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_tyre_pressure(&car, &session, &mut recs);
        engineer.analyze_tyre_temperature(&car, &mut recs);
        engineer.analyze_brakes(&car, &mut recs);
        engineer.analyze_tyre_wear(&car, &mut recs);

        assert!(
            recs.len() >= 4,
            "this state should trip pressure, temperature, brakes and wear: {recs:?}"
        );
        for rec in &recs {
            // Phrased as an assertion rather than an unwrap because the
            // workspace denies `clippy::panic`, and a test is not exempt from a
            // lint that exists so a release build cannot abort on a driver
            // mid-race.
            assert!(
                rec.chain.is_some(),
                "{} produces no chain at all",
                rec.message
            );
            let Some(chain) = rec.chain.as_ref() else {
                continue;
            };
            // Captured by default, and printed anyway on purpose: the
            // simulator's telemetry sits inside every window, so
            // `engineer_probe` never trips these rules and there is nowhere
            // else to *read* the sentences they produce. `cargo test --
            // --nocapture` is that place. A `confirm` that is grammatical and
            // useless is not something an assertion can catch.
            println!(
                "{}\n    why:   {}\n    seen:  {}\n    check: {}",
                rec.message, chain.cause, chain.effect, chain.confirm
            );
            assert!(
                !chain.cause.trim().is_empty(),
                "{} states no mechanism",
                rec.message
            );
            assert!(
                !chain.effect.trim().is_empty(),
                "{} states no measurement",
                rec.message
            );
            // The field the whole idea rests on. Advice nobody can check is not
            // advice, and an empty string here is the failure that would be
            // easiest to ship without noticing.
            assert!(
                !chain.confirm.trim().is_empty(),
                "{} gives nothing to check next run",
                rec.message
            );
        }
    }

    /// Drive `phys` through `update` often enough for the camber average to
    /// have something behind it.
    /// The four flags, one at a time: a game that does not measure a thing
    /// must not have a verdict about it.
    ///
    /// This is the half of `Capabilities` that did not exist. The type was
    /// declared, documented and checked against a real capture, and then
    /// consulted by nobody — so on Assetto Corsa, which measures all four,
    /// nothing ever went wrong, and on the first game that does not it would
    /// have read four defaults as four measurements.
    mod capabilities {
        use super::*;

        /// A car in enough trouble that both gated rules have something to say
        /// about it, and the ungated ones do too.
        fn a_car_in_trouble() -> Car {
            Car {
                speed_kmh: 180.0,
                tyre_pressure_psi: [20.0; 4],
                tyre_wear: [70.0; 4],
                brake_temp_c: [950.0; 4],
                // Cooking, and the inner edge far hotter than the outer: too
                // much negative camber as well as too much heat.
                tyre_temp_inner_c: [140.0; 4],
                tyre_temp_middle_c: [130.0; 4],
                tyre_temp_outer_c: [118.0; 4],
                acc_g: [1.2, 1.0, 0.0],
                ..Default::default()
            }
        }

        /// "Tyres/Overheat", "Brakes/Overheat" — the component as well as the
        /// category, because two different rules both call their finding an
        /// overheat and only one of them rests on a tread temperature.
        fn advice_about(engineer: &mut Engineer, car: &Car) -> Vec<String> {
            age_the_alerts(engineer);
            drive(engineer, car, 120);
            age_the_alerts(engineer);
            engineer
                .analyze_live(car, &Session::default(), None)
                .into_iter()
                .map(|rec| format!("{}/{}", rec.component, rec.category))
                .collect()
        }

        /// Both halves in one: everything measured says all of it, and nothing
        /// measured says only what does not depend on a measurement the game
        /// withheld. The brakes are in both lists, which is the control — a
        /// silent engineer would pass a test that only checked for absence.
        #[test]
        fn a_game_that_measures_nothing_still_says_what_it_can() {
            let config = AppConfig::default();
            let car = a_car_in_trouble();

            let mut complete = engineer_reading_a_complete_game(&config);
            let said = advice_about(&mut complete, &car);
            for expected in [
                "Tyres/Overheat",
                "Suspension/Camber",
                "Tyres/Wear",
                "Brakes/Overheat",
            ] {
                assert!(said.iter().any(|c| c == expected), "{expected}: {said:?}");
            }
            // The pressure rule names the compound it judged against —
            // "Tyres (Racing)" — so it is matched by what it found.
            assert!(said.iter().any(|c| c.ends_with("/Pressure")), "{said:?}");

            let mut blind = Engineer::new(&config);
            let said = advice_about(&mut blind, &car);
            assert!(
                said.iter().any(|c| c == "Brakes/Overheat"),
                "the brakes rest on no withheld measurement: {said:?}"
            );
            assert!(
                said.iter().any(|c| c.ends_with("/Pressure")),
                "nor does the pressure: {said:?}"
            );
            for withheld in ["Tyres/Overheat", "Suspension/Camber", "Tyres/Wear"] {
                assert!(
                    !said.iter().any(|c| c == withheld),
                    "{withheld} rests on a measurement this game does not make: {said:?}"
                );
            }
        }

        /// **A `Parameter` is a setting somebody can turn**, and four rules
        /// used one to carry a measurement.
        ///
        /// The widget that draws them says so in its own comment — "the
        /// numbers to change and what to change them to" — and CLAUDE.md says
        /// it again. Tyre life, the clip ratio, the camber rule's inner-outer
        /// spread and pad thickness are none of them settings: you pit, you
        /// move the wheel's gain, you change camber in degrees, you replace
        /// pads. Each was drawn as the most prominent half of its finding, and
        /// each was an instruction nobody could follow.
        ///
        /// The two that remain are settings with numbers: a cold pressure and
        /// litres of fuel.
        #[test]
        fn no_rule_offers_a_measurement_as_a_setting() {
            let config = AppConfig::default();
            let mut car = a_car_in_trouble();
            car.tyre_wear = [89.6, 92.0, 93.7, 94.2];
            car.brake_pad_mm = [3.1, 3.3, 4.0, 4.2];
            car.force_feedback = 1.4;

            let mut engineer = engineer_reading_a_complete_game(&config);
            for _ in 0..4 {
                let _ = advice_about(&mut engineer, &car);
            }
            let said = engineer.analyze_live(&car, &Session::default(), None);

            for one in &said {
                for parameter in &one.parameters {
                    let name = parameter.name.to_lowercase();
                    assert!(
                        !(name.contains("life")
                            || name.contains("clip")
                            || name.contains("i-o")
                            || name.contains("pad")
                            || name.contains("disc")),
                        "{}/{} offers `{}` as a setting, and it is a measurement",
                        one.component,
                        one.category,
                        parameter.name
                    );
                }
            }
        }

        /// **A `Parameter` is a setting somebody can turn.**
        ///
        /// The wear rule emitted one per corner — `FL life 89.59 % → 100.00 %`
        /// — and nobody can turn a tyre back to a hundred percent. The screen
        /// drew four rows of instruction that could not be followed, above an
        /// action that could: box. Which corner is worst is still said, in the
        /// effect, where it is an observation rather than an order.
        #[test]
        fn wear_gives_no_setting_to_change_because_there_is_none() {
            let config = AppConfig::default();
            let mut car = a_car_in_trouble();
            car.tyre_wear = [89.6, 92.0, 93.7, 94.2];

            let mut engineer = engineer_reading_a_complete_game(&config);
            let _ = advice_about(&mut engineer, &car);
            let said = engineer.analyze_live(&car, &Session::default(), None);
            let wear = said
                .iter()
                .find(|one| one.category.starts_with("Wear"))
                .expect("a set this far down is worth saying something about");

            assert!(
                wear.parameters.is_empty(),
                "nothing here is a setting: {:?}",
                wear.parameters
            );
            // And the four corners are still there, as measurement.
            let effect = &wear.chain.as_ref().expect("a chain").effect;
            for corner in ["FL", "FR", "RL", "RR"] {
                assert!(effect.contains(corner), "{corner} is missing from {effect}");
            }
        }

        /// **Rake is front ride height minus rear, and one game publishes
        /// neither.**
        ///
        /// The aero rule was protected by nothing but a `!= 0.0` guard on its
        /// own accumulators: with Competizione's zeros the rake is zero at
        /// every speed, so the guard held — until one frame of noise, after
        /// which a driver would be told to stiffen their rear springs because
        /// of a measurement their game never made. The camber rule has had a
        /// capability gate since it was written; this one needed it just as
        /// much and did not have it, and was found when the window started
        /// offering the second game.
        #[test]
        fn without_a_ride_height_there_is_no_rake_verdict() {
            let config = AppConfig::default();
            let mut car = a_car_in_trouble();
            // A rear that has dropped two centimetres at speed, which is what
            // the rule is looking for.
            car.speed_kmh = 200.0;
            car.ride_height_m = [0.050, 0.030];

            let mut complete = engineer_reading_a_complete_game(&config);
            // Twice, because the rule wants a low-speed reading and a
            // high-speed one before it can compare them.
            car.speed_kmh = 70.0;
            let _ = advice_about(&mut complete, &car);
            car.speed_kmh = 200.0;
            let _ = advice_about(&mut complete, &car);

            let mut blind = Engineer::new(&config);
            car.speed_kmh = 70.0;
            let _ = advice_about(&mut blind, &car);
            car.speed_kmh = 200.0;
            let said = advice_about(&mut blind, &car);
            assert!(
                !said.iter().any(|c| c.starts_with("Aerodynamics")),
                "a game that publishes no ride height has no rake to judge: {said:?}"
            );
        }

        /// Tyre wear alone. The rule reads a percentage that counts down from
        /// 100, and an unpublished one reads as zero — which is exactly the
        /// "four tyres WORN OUT" this project has already shipped once.
        #[test]
        fn without_tyre_wear_there_is_no_wear_verdict() {
            let config = AppConfig::default();
            let car = a_car_in_trouble();

            let mut engineer = Engineer::new(&config);
            engineer.update_capabilities(Capabilities {
                tyre_wear: false,
                ..Capabilities::all()
            });
            let said = advice_about(&mut engineer, &car);
            assert!(!said.iter().any(|c| c == "Tyres/Wear"), "{said:?}");
            assert!(
                said.iter().any(|c| c == "Tyres/Overheat"),
                "only the wear flag was taken away: {said:?}"
            );
        }

        /// Somebody with no wheel is not told to lower a gain they have not got.
        ///
        /// Reported by a driver on a pad: the game computes a force whether or
        /// not anything can feel it, so the clipping line arrived every lap
        /// for hardware that is not there.
        #[test]
        fn force_feedback_advice_can_be_switched_off() {
            let clipping_car = || {
                let mut car = a_car_in_trouble();
                car.speed_kmh = 120.0;
                car
            };
            // The rule waits a second before it speaks, which a test cannot
            // sit through: the timer is put back instead.
            let settled = |engineer: &mut Engineer| {
                let now = std::time::Instant::now();
                engineer.alert_timers.insert(
                    "ffb_clip".to_string(),
                    (now - std::time::Duration::from_secs(5), now),
                );
                engineer.stats.total_frames = 1000;
                engineer.stats.ffb_clip_frames = 200;
            };

            let config = AppConfig::default();
            let mut engineer = Engineer::new(&config);
            settled(&mut engineer);
            let mut said = Vec::new();
            engineer.analyze_ffb_clipping(&clipping_car(), &mut said);
            assert_eq!(said.len(), 1, "on by default: {said:?}");
            assert_eq!(said[0].component, "Force Feedback");

            let config = AppConfig {
                alerts: crate::config::AlertsConfig {
                    ffb_advice: false,
                    ..AppConfig::default().alerts
                },
                ..AppConfig::default()
            };
            let mut engineer = Engineer::new(&config);
            settled(&mut engineer);
            let mut said = Vec::new();
            engineer.analyze_ffb_clipping(&clipping_car(), &mut said);
            assert!(said.is_empty(), "switched off and still said it: {said:?}");
        }

        /// **The two halves of a balance cannot both be true.**
        ///
        /// They were two counters with a threshold each, so a lap that
        /// understeered into one corner and oversteered out of another
        /// published both — "More Front Wing" directly above "More Rear
        /// Wing". Reported from a real session.
        #[test]
        fn the_balance_is_one_finding_and_never_both() {
            let config = AppConfig::default();
            let mut engineer = Engineer::new(&config);
            engineer.stats.total_frames = 600;
            engineer.stats.understeer_frames = 120;
            engineer.stats.oversteer_frames = 90;

            let mut said = Vec::new();
            engineer.analyze_driving_errors(&mut said);
            let balance: Vec<&crate::engineer::Recommendation> = said
                .iter()
                .filter(|one| one.component == "Balance")
                .collect();

            assert_eq!(
                balance.len(),
                1,
                "one balance finding, not two: {balance:?}"
            );
            assert_eq!(balance[0].category, "Understeer", "the larger count wins");
            assert!(
                balance[0].confidence < 0.7,
                "nearly level counts are not a confident verdict: {}",
                balance[0].confidence
            );
        }

        /// And a car that only ever understeers still reads as it always did.
        #[test]
        fn a_car_that_only_understeers_is_said_with_the_old_confidence() {
            let config = AppConfig::default();
            let mut engineer = Engineer::new(&config);
            engineer.stats.total_frames = 600;
            engineer.stats.understeer_frames = 200;
            engineer.stats.oversteer_frames = 0;

            let mut said = Vec::new();
            engineer.analyze_driving_errors(&mut said);
            let one = said
                .iter()
                .find(|one| one.component == "Balance")
                .expect("a balance finding");
            assert_eq!(one.category, "Understeer");
            assert!((one.confidence - 0.85).abs() < 0.001, "{}", one.confidence);
        }

        /// **Nothing is recommended that the car has not got.**
        ///
        /// The 90s Miata this was reported from adjusts pressures, camber,
        /// toe, gears and fuel — no wing, no bar, no springs — and was being
        /// told to add front wing.
        #[test]
        fn a_car_with_no_wing_and_no_bar_is_told_what_it_can_change() {
            use crate::games::catalogue::Adjustables;
            let config = AppConfig::default();
            let mut engineer = Engineer::new(&config);
            engineer.update_car_adjustables(Some(Adjustables::default()));
            engineer.stats.total_frames = 600;
            engineer.stats.understeer_frames = 200;

            let mut said = Vec::new();
            engineer.analyze_driving_errors(&mut said);
            let one = said
                .iter()
                .find(|one| one.component == "Balance")
                .expect("a balance finding");
            assert!(
                !one.action.contains("Wing") && !one.action.contains("ARB"),
                "a car with neither was told about both: {}",
                one.action
            );
            assert!(
                one.action.contains("Pressure") || one.action.contains("Camber"),
                "{}",
                one.action
            );
        }

        /// And one that has a wing is still told about it.
        #[test]
        fn a_car_with_a_wing_is_still_told_about_the_wing() {
            use crate::games::catalogue::Adjustables;
            let config = AppConfig::default();
            let mut engineer = Engineer::new(&config);
            engineer.update_car_adjustables(Some(Adjustables {
                wing: true,
                ..Adjustables::default()
            }));
            engineer.stats.total_frames = 600;
            engineer.stats.oversteer_frames = 200;

            let mut said = Vec::new();
            engineer.analyze_driving_errors(&mut said);
            let one = said
                .iter()
                .find(|one| one.component == "Balance")
                .expect("a balance finding");
            assert!(one.action.contains("Wing"), "{}", one.action);
        }

        /// Tread temperature gates the camber advice, and only that.
        ///
        /// It used to gate the temperature band as well, which is what this
        /// test was written for — and it was wrong: the band judges a number,
        /// and a game with no tread has a core reading to judge instead. What
        /// has no substitute is inner minus outer. The car here has neither,
        /// so both stay silent.
        #[test]
        fn without_tread_temperatures_there_is_no_camber_or_temperature_verdict() {
            let config = AppConfig::default();
            let car = a_car_in_trouble();

            let mut engineer = Engineer::new(&config);
            engineer.update_capabilities(Capabilities {
                tyre_edge_temps: false,
                ..Capabilities::all()
            });
            let said = advice_about(&mut engineer, &car);
            assert!(!said.iter().any(|c| c == "Suspension/Camber"), "{said:?}");
            assert!(!said.iter().any(|c| c == "Tyres/Overheat"), "{said:?}");
            assert!(
                said.iter().any(|c| c == "Tyres/Wear"),
                "only the tread flag was taken away: {said:?}"
            );
            assert!(
                said.iter().any(|c| c == "Brakes/Overheat"),
                "the brakes are measured and still cooking: {said:?}"
            );
        }

        /// The same telemetry, two classes of car, two different verdicts.
        ///
        /// This is the whole point of knowing what is being driven. 520 °C at
        /// the front is a GT3 working properly and a road car with boiled
        /// fluid; 78 °C is a warm GT3 tyre and a cold Formula one. One band
        /// for both — which is what this application had — is wrong for almost
        /// every car and merely quiet for the rest.
        #[test]
        fn the_same_numbers_mean_different_things_to_different_cars() {
            let config = AppConfig::default();
            let car = Car {
                speed_kmh: 180.0,
                // Inside a GT3's window (75–100) and under a Formula car's
                // (85–110): the same number, two answers.
                tyre_core_temp_c: [78.0; 4],
                brake_temp_c: [520.0, 520.0, 260.0, 260.0],
                ..Default::default()
            };
            let capabilities = Capabilities {
                tyre_edge_temps: false,
                ..Capabilities::all()
            };

            let verdicts = |class: crate::games::CarClass| {
                let mut engineer = Engineer::new(&config);
                engineer.update_capabilities(capabilities);
                engineer.update_car_class(class);
                age_the_alerts(&mut engineer);
                drive(&mut engineer, &car, 120);
                age_the_alerts(&mut engineer);
                engineer
                    .analyze_live(&car, &Session::default(), None)
                    .into_iter()
                    .map(|rec| format!("{}/{}", rec.component, rec.category))
                    .collect::<Vec<_>>()
            };

            // A GT3 at 78 °C on 520 °C fronts is a car doing its job.
            let gt3 = verdicts(crate::games::CarClass::Gt3);
            assert!(
                !gt3.iter()
                    .any(|v| v == "Tyres/Overheat" || v == "Brakes/Overheat"),
                "nothing here is wrong with a GT3: {gt3:?}"
            );

            // The same readings on a road car are brakes a long way past
            // their ceiling.
            let road = verdicts(crate::games::CarClass::Road);
            assert!(
                road.iter().any(|v| v == "Brakes/Overheat"),
                "520 C is not a road car's brakes: {road:?}"
            );

            // And a Formula car wants its tyres hotter than this, so the same
            // reading is cold rather than fine.
            let formula = verdicts(crate::games::CarClass::Formula);
            assert!(
                formula.iter().any(|v| v == "Tyres/Temperature"),
                "78 C is under a Formula tyre's window: {formula:?}"
            );
        }

        /// A car nobody recognised keeps the driver's own numbers.
        ///
        /// The same distinction the capability flags draw: not knowing and
        /// knowing a default are different answers, and a mod pressed into a
        /// class it may not be in is a wrong verdict rather than a missing one.
        #[test]
        fn an_unknown_car_is_judged_by_the_drivers_own_settings() {
            let config = AppConfig::default();
            let mut engineer = Engineer::new(&config);
            engineer.update_car_class(crate::games::CarClass::Unknown);
            assert_eq!(
                engineer.tyre_window(),
                (config.alerts.tyre_temp_min, config.alerts.tyre_temp_max),
                "an unclassified car is judged by whatever the driver has set"
            );

            // ...and a driver who has set their own numbers keeps them even on
            // a car the table knows.
            let mut mine = AppConfig::default();
            mine.alerts.tyre_temp_min = 88.0;
            mine.alerts.tyre_temp_max = 104.0;
            let mut engineer = Engineer::new(&mine);
            engineer.update_car_class(crate::games::CarClass::Gt3);
            assert_eq!(
                engineer.tyre_window(),
                (88.0, 104.0),
                "a number somebody typed outranks a table"
            );
        }

        /// A game that measures the core and not the tread still gets a
        /// temperature verdict — on the core, and saying so.
        ///
        /// This is what Competizione lost by having the band gated with the
        /// camber rule: a driver on tyres a long way outside their window was
        /// told nothing at all, on a game that publishes a perfectly good
        /// reading of them.
        #[test]
        fn a_core_temperature_is_judged_and_named() {
            let config = AppConfig::default();
            // Well over the default 105 °C ceiling, and nothing in the tread
            // fields — which is exactly what ACC's pages look like.
            let car = Car {
                speed_kmh: 180.0,
                tyre_core_temp_c: [128.0; 4],
                ..Default::default()
            };

            let mut engineer = Engineer::new(&config);
            engineer.update_capabilities(Capabilities {
                tyre_edge_temps: false,
                ..Capabilities::all()
            });
            age_the_alerts(&mut engineer);
            drive(&mut engineer, &car, 120);
            age_the_alerts(&mut engineer);
            let advice = engineer.analyze_live(&car, &Session::default(), None);

            let overheat = advice
                .iter()
                .find(|rec| rec.category == "Overheat" && rec.component == "Tyres")
                .expect("a tyre overheating on its core reading is still overheating");
            assert!(
                overheat.message.contains("core"),
                "the verdict has to say which measurement it judged: {}",
                overheat.message
            );
            assert!(
                !advice.iter().any(|rec| rec.category == "Camber"),
                "and the camber rule stays gone: it is inner minus outer"
            );
        }

        /// The other half: a game that publishes neither is still silent.
        #[test]
        fn a_game_with_no_tyre_temperature_at_all_says_nothing_about_it() {
            let config = AppConfig::default();
            let car = Car {
                speed_kmh: 180.0,
                ..Default::default()
            };

            let mut engineer = Engineer::new(&config);
            engineer.update_capabilities(Capabilities::all());
            age_the_alerts(&mut engineer);
            drive(&mut engineer, &car, 120);
            age_the_alerts(&mut engineer);
            let advice = engineer.analyze_live(&car, &Session::default(), None);
            assert!(
                !advice
                    .iter()
                    .any(|rec| rec.component == "Tyres" && rec.category != "Wear"),
                "four zeros are not four frozen tyres: {advice:?}"
            );
        }

        /// Brake wear is the trade Competizione makes: no tyre wear, and what
        /// is left of the pads instead. Neither game gets the other's rule.
        #[test]
        fn brake_wear_is_reported_only_by_a_game_that_measures_it() {
            let config = AppConfig::default();
            let mut car = a_car_in_trouble();
            car.brake_pad_mm = [7.0; 4];
            car.brake_disc_mm = [31.0; 4];

            let mut measures_it = Engineer::new(&config);
            measures_it.update_capabilities(Capabilities::all());
            let said = advice_about(&mut measures_it, &car);
            assert!(
                said.iter().any(|c| c == "Brakes/Wear"),
                "seven millimetres of pad is a stop: {said:?}"
            );

            let mut does_not = Engineer::new(&config);
            does_not.update_capabilities(Capabilities {
                brake_wear: false,
                ..Capabilities::all()
            });
            let said = advice_about(&mut does_not, &car);
            assert!(!said.iter().any(|c| c == "Brakes/Wear"), "{said:?}");
            assert!(
                said.iter().any(|c| c == "Brakes/Overheat"),
                "only the wear flag was taken away: {said:?}"
            );
        }

        /// The same guard tyre wear needs, for the same reason: a session that
        /// has not published yet reads as a car with no brakes left, and four
        /// CRITICAL lines at the moment somebody leaves the pits is how an
        /// engineer gets ignored for the rest of the race.
        #[test]
        fn brakes_nobody_has_measured_are_not_worn_out() {
            let config = AppConfig::default();
            let car = a_car_in_trouble();
            assert_eq!(car.brake_pad_mm, [0.0; 4], "nothing published");

            let mut engineer = Engineer::new(&config);
            engineer.update_capabilities(Capabilities::all());
            let said = advice_about(&mut engineer, &car);
            assert!(!said.iter().any(|c| c == "Brakes/Wear"), "{said:?}");
        }

        /// A game that publishes no track grip must not have one invented for
        /// it. The pressure target picks up a green-track allowance from
        /// `surface_grip`, and an unpublished zero clamps to the greenest
        /// track there is — so the allowance is added on every lap of every
        /// session, and the driver is told to run pressures nobody asked for.
        #[test]
        fn an_unmeasured_track_grip_adds_nothing_to_the_pressure_target() {
            let config = AppConfig::default();
            // Under the target either way, so the rule fires in both runs and
            // the difference is in the number it names.
            let car = Car {
                speed_kmh: 180.0,
                tyre_pressure_psi: [20.0; 4],
                ..Default::default()
            };
            // Nothing published: zero, which is what a game that does not
            // measure it leaves behind.
            let session = Session::default();

            let target_of = |capabilities: Capabilities| {
                let mut engineer = Engineer::new(&config);
                engineer.update_capabilities(capabilities);
                age_the_alerts(&mut engineer);
                drive(&mut engineer, &car, 120);
                age_the_alerts(&mut engineer);
                engineer
                    .analyze_live(&car, &session, None)
                    .into_iter()
                    .find(|rec| rec.category.ends_with("Pressure"))
                    .and_then(|rec| rec.parameters.first().map(|p| p.target))
            };

            let believed = target_of(Capabilities::all()).expect("a pressure verdict");
            let honest = target_of(Capabilities {
                track_grip: false,
                ..Capabilities::all()
            })
            .expect("a pressure verdict");

            assert!(
                believed > honest,
                "the green-track allowance was added for a grip figure nobody \
                 published: {believed} against {honest}"
            );
            assert!(
                (honest - config.target_tyre_pressure).abs() < 0.01,
                "with no grip measured the target is the driver's own: {honest}"
            );
        }

        /// The stat behind the camber verdict has to stop being collected too.
        ///
        /// Withholding only at the rule would leave `camber_spread` averaging
        /// zero minus zero over a whole stint — a number that reads as a
        /// perfectly cambered car rather than as no reading, and the moment a
        /// flag was flipped back on it would be believed.
        #[test]
        fn an_unmeasured_tread_leaves_no_camber_history_behind() {
            let config = AppConfig::default();
            let car = a_car_in_trouble();

            let mut engineer = Engineer::new(&config);
            engineer.update_capabilities(Capabilities {
                tyre_edge_temps: false,
                ..Capabilities::all()
            });
            drive(&mut engineer, &car, 120);
            assert_eq!(engineer.stats.camber_frames, 0);
            assert_eq!(engineer.stats.camber_spread, [0.0; 4]);
        }
    }

    /// An engineer reading a game that measures everything.
    ///
    /// Which is what Assetto Corsa does, and what every test in this file
    /// assumed before the capability flags gated anything. Spelled out rather
    /// than defaulted: the point of the flags is that a rule resting on a
    /// measurement has to be told the measurement exists.
    fn engineer_reading_a_complete_game(config: &AppConfig) -> Engineer {
        let mut engineer = Engineer::new(config);
        engineer.update_capabilities(Capabilities::all());
        engineer
    }

    fn drive(engineer: &mut Engineer, car: &Car, ticks: u32) {
        let session = Session::default();
        let info = crate::session_info::SessionInfo::default();
        for _ in 0..ticks {
            engineer.update(car, &session, &info);
        }
    }

    /// The pressure a car is judged against is its class's, not a GT3's.
    ///
    /// Reported on Overtake as "this app will always give you false
    /// information ... esp when it comes to tyre pressure". A single-seater
    /// works at 21 psi; the advice held every car to the 27.5 psi default, so
    /// a Formula driver sitting exactly on the number was told, on every lap,
    /// to inflate all four.
    #[test]
    fn a_formula_car_at_its_own_pressure_is_not_told_to_inflate() {
        let config = AppConfig::default();
        let session = Session::default();
        let car = Car {
            tyre_pressure_psi: [21.0; 4],
            speed_kmh: 180.0,
            ..Default::default()
        };

        let complaints = |class: CarClass| {
            let mut engineer = engineer_reading_a_complete_game(&config);
            engineer.update_car_class(class);
            age_the_alerts(&mut engineer);
            let mut recs = Vec::new();
            engineer.analyze_tyre_pressure(&car, &session, &mut recs);
            recs
        };

        assert!(
            complaints(CarClass::Formula).is_empty(),
            "a Formula car on 21 psi is on its target: {:?}",
            complaints(CarClass::Formula)
        );
        // The other half of the same test: the rule still fires when the
        // pressure really is wrong for the car. A GT3 wants 27.5.
        assert!(
            !complaints(CarClass::Gt3).is_empty(),
            "a GT3 six and a half psi under its target has a finding to make"
        );
    }

    /// A number somebody typed outranks the table; a default is not a
    /// preference.
    #[test]
    fn the_drivers_own_pressure_outranks_the_class() {
        let untouched = AppConfig::default();
        assert_eq!(hot_pressure(&untouched, CarClass::Formula, None, 0), 21.0);
        assert_eq!(hot_pressure(&untouched, CarClass::Gt3, None, 0), 27.5);
        // Nothing recognised: the driver's own default, which is where every
        // car sat before the class table existed.
        assert_eq!(
            hot_pressure(&untouched, CarClass::Unknown, None, 0),
            untouched.target_hot_pressure_front
        );

        // The window's single slider.
        let single = AppConfig {
            target_tyre_pressure: 24.0,
            ..AppConfig::default()
        };
        assert_eq!(hot_pressure(&single, CarClass::Formula, None, 0), 24.0);

        // The terminal's per-axle pair, which is more specific still.
        let per_axle = AppConfig {
            target_tyre_pressure: 24.0,
            target_hot_pressure_rear: 25.0,
            ..AppConfig::default()
        };
        assert_eq!(hot_pressure(&per_axle, CarClass::Formula, None, 0), 24.0);
        assert_eq!(hot_pressure(&per_axle, CarClass::Formula, None, 2), 25.0);
    }

    /// The car's own number beats the class table, and a typed one beats both.
    ///
    /// The class table cannot help most of Assetto Corsa's grid: GT3, road and
    /// unrecognised all carry 27.5 psi, so a car that wants 21 got the same
    /// wrong figure whether it was classified or not. Its own `tyres.ini` is
    /// the answer, and this is where it enters.
    #[test]
    fn the_car_states_its_own_pressure_and_that_wins() {
        let untouched = AppConfig::default();
        let own = Some((21.5, 20.5));

        assert_eq!(hot_pressure(&untouched, CarClass::Gt3, own, 0), 21.5);
        assert_eq!(hot_pressure(&untouched, CarClass::Gt3, own, 2), 20.5);
        // Including for a car nobody classified, which is the case the class
        // table has nothing at all to say about.
        assert_eq!(hot_pressure(&untouched, CarClass::Unknown, own, 0), 21.5);

        // A number the driver typed still outranks the car.
        let mine = AppConfig {
            target_tyre_pressure: 24.0,
            ..AppConfig::default()
        };
        assert_eq!(hot_pressure(&mine, CarClass::Gt3, own, 0), 24.0);

        // And the band goes with it, or the car sitting on its own pressure
        // trips the alert it should never have been near.
        let (low, high) = pressure_window(&untouched, CarClass::Gt3, own, 0);
        assert!(low < 21.5 && high > 21.5, "{low}–{high} excludes 21.5");
    }

    /// The alert band moves with the target, or the one reading that is right
    /// is the one being complained about.
    #[test]
    fn the_pressure_band_follows_the_class() {
        let untouched = AppConfig::default();
        let (low, high) = pressure_window(&untouched, CarClass::Formula, None, 0);
        assert!(
            low < 21.0 && high > 21.0,
            "a Formula car's own 21 psi fell outside its own band: {low}–{high}"
        );
        let width = high - low;
        let (gt3_low, gt3_high) = pressure_window(&untouched, CarClass::Gt3, None, 0);
        assert!(
            (width - (gt3_high - gt3_low)).abs() < 0.01,
            "the band is as wide as the driver's own, wherever it is centred"
        );

        // Touch either end and it is the driver's band again, unchanged.
        let mut mine = AppConfig::default();
        mine.alerts.tyre_pressure_min = 20.0;
        assert_eq!(
            pressure_window(&mine, CarClass::Formula, None, 0),
            (20.0, 28.5)
        );
    }

    /// A car with no wing is never told to change one.
    ///
    /// From the same review: "I'm setting up a road car, and its telling me to
    /// adjust front downforce." Advice about a part the car does not have is
    /// worse than no advice — it is the line that makes somebody stop
    /// believing the other seven.
    #[test]
    fn a_road_car_is_not_told_about_a_wing_it_does_not_have() {
        let config = AppConfig::default();

        // **One end at a time.** This used to set both counters to 40 and
        // assert that both the front and the rear line came out, which is
        // what the panel was actually doing and what a driver reported: two
        // instructions that undo each other. The rule it was written for —
        // a car with no wing is not told about one — is unchanged, and is
        // what it checks now, one balance at a time.
        let balance = |class: CarClass, understeer: u32, oversteer: u32| {
            let mut engineer = engineer_reading_a_complete_game(&config);
            engineer.update_car_class(class);
            engineer.stats.understeer_frames = understeer;
            engineer.stats.oversteer_frames = oversteer;
            let mut recs = Vec::new();
            engineer.analyze_driving_errors(&mut recs);
            recs.iter()
                .map(|rec| rec.action.clone())
                .collect::<Vec<_>>()
                .join(" | ")
        };

        let pushing = balance(CarClass::Road, 40, 0);
        let loose = balance(CarClass::Road, 0, 40);
        for road in [&pushing, &loose] {
            assert!(
                !road.to_lowercase().contains("wing"),
                "a road car was told about a wing: {road}"
            );
        }
        assert!(
            pushing.contains("Softer Front Springs or ARB"),
            "the mechanical half of the same fix is what is left: {pushing}"
        );
        assert!(
            loose.contains("Softer Rear Springs or ARB"),
            "the mechanical half of the same fix is what is left: {loose}"
        );
        assert!(
            balance(CarClass::Gt3, 40, 0)
                .to_lowercase()
                .contains("wing"),
            "a GT3 has a wing and is still told about it"
        );

        // The wizard's lists, the other place a wing is named.
        let wizard = |class: CarClass| {
            let mut engineer = engineer_reading_a_complete_game(&config);
            engineer.update_car_class(class);
            engineer.wizard_problem = WizardProblem::Instability;
            engineer.get_wizard_advice().join(" | ")
        };
        assert!(!wizard(CarClass::Road).to_lowercase().contains("wing"));
        assert!(wizard(CarClass::Formula).to_lowercase().contains("wing"));
        // Dropping a line is not the same as leaving a driver with nothing.
        assert!(!wizard(CarClass::Road).is_empty());
    }

    /// A tyre says nothing about camber while the car is upright: both edges
    /// run the same temperature, the spread reads zero, and the old check read
    /// that as "contact patch inefficient" — four Info lines, on every
    /// straight, in the eight the panel has.
    #[test]
    fn a_straight_is_not_a_camber_problem() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);

        let car = Car {
            speed_kmh: 240.0,
            acc_g: [0.0, 1.0, 0.0],
            tyre_temp_inner_c: [90.0; 4],
            tyre_temp_outer_c: [90.0; 4],
            ..Default::default()
        };
        drive(&mut engineer, &car, 600);

        let mut recs = Vec::new();
        engineer.analyze_camber(&car, &mut recs);
        assert!(recs.is_empty(), "ten seconds of straight line: {recs:?}");
    }

    /// The same spread, measured while the tyre is loaded, is a real answer —
    /// and it is one line for all four corners rather than four.
    #[test]
    fn four_corners_wanting_camber_are_one_piece_of_advice() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);

        let car = Car {
            speed_kmh: 160.0,
            acc_g: [1.2, 1.0, 0.0],
            // Outer edge hotter than inner: not enough negative camber.
            tyre_temp_inner_c: [90.0; 4],
            tyre_temp_outer_c: [94.0; 4],
            camber_rad: [
                (-1.5f32).to_radians(),
                1.5f32.to_radians(),
                (-1.5f32).to_radians(),
                1.5f32.to_radians(),
            ],
            ..Default::default()
        };
        drive(&mut engineer, &car, 120);

        let mut recs = Vec::new();
        engineer.analyze_camber(&car, &mut recs);

        assert_eq!(recs.len(), 1, "one fact, one line: {recs:?}");
        assert!(
            recs[0].message.contains("All four"),
            "and it says which corners: {}",
            recs[0].message
        );
        // The number in the advice is the camber AC reports, not the setup
        // file's step index — `CAMBER_LF VALUE=-9` used to be printed as
        // "now: -9" beside a car the game showed at -1.3°.
        assert!(
            recs[0].action.contains("-1.5°"),
            "the advice names the camber the car is running: {}",
            recs[0].action
        );
    }

    /// The two halves of one piece of camber advice have to agree with each
    /// other, and with the number beside them.
    ///
    /// A driver who has just set three and a half degrees of negative camber
    /// and is told to add more will read the reason before he believes the
    /// action. This used to say the outer shoulder was *not* being loaded —
    /// the reason to take camber out — beside an action that put camber in,
    /// and a message that named no edge at all. Reported from the outside,
    /// which is where wording faults are always found.
    #[test]
    fn the_reason_for_more_camber_is_the_outer_shoulder_working() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);

        let car = Car {
            speed_kmh: 160.0,
            acc_g: [1.2, 1.0, 0.0],
            // Outer edge hotter than inner: not enough negative camber.
            tyre_temp_inner_c: [90.0; 4],
            tyre_temp_outer_c: [96.0; 4],
            ..Default::default()
        };
        drive(&mut engineer, &car, 120);

        let mut recs = Vec::new();
        engineer.analyze_camber(&car, &mut recs);
        let advice = recs
            .first()
            .expect("an outer edge six degrees hot is advice");

        assert!(
            advice.action.contains("More neg. camber"),
            "the action: {}",
            advice.action
        );
        assert!(
            advice.message.contains("outer edge hotter"),
            "the message has to name the edge the number is about: {}",
            advice.message
        );
        let cause = advice
            .chain
            .as_ref()
            .expect("camber advice carries its reasoning")
            .cause
            .clone();
        assert!(
            cause.contains("outer shoulder takes the load"),
            "the reason has to be the one the action follows from: {cause}"
        );
    }

    /// Inner edges cooking is the other direction, and it is a warning rather
    /// than a note.
    #[test]
    fn inner_edges_cooking_ask_for_less_camber() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);

        let car = Car {
            speed_kmh: 160.0,
            acc_g: [-1.2, 1.0, 0.0],
            tyre_temp_inner_c: [110.0, 110.0, 90.0, 90.0],
            tyre_temp_outer_c: [90.0, 90.0, 82.0, 82.0],
            ..Default::default()
        };
        drive(&mut engineer, &car, 120);

        let mut recs = Vec::new();
        engineer.analyze_camber(&car, &mut recs);

        assert_eq!(recs.len(), 1, "{recs:?}");
        assert!(
            recs[0].message.contains("Fronts"),
            "only the fronts are cooking: {}",
            recs[0].message
        );
        assert_eq!(recs[0].severity, Severity::Warning);
        assert!(
            recs[0].action.contains("Less neg. camber"),
            "{}",
            recs[0].action
        );
    }

    /// AC reports camber in each wheel's own frame, so the two sides mirror.
    /// Reading them raw makes a symmetric car look like it has +1.5° on the
    /// right, which is a car about to spin rather than a normal setup.
    #[test]
    fn the_two_sides_of_the_car_report_camber_on_one_scale() {
        let car = Car {
            camber_rad: [
                (-1.3f32).to_radians(),
                1.3f32.to_radians(),
                (-2.0f32).to_radians(),
                2.0f32.to_radians(),
            ],
            ..Default::default()
        };
        for corner in 0..4 {
            assert!(
                Engineer::camber_degrees(&car, corner) < 0.0,
                "corner {corner} reads positive on a car with negative camber"
            );
        }
        assert!((Engineer::camber_degrees(&car, 0) + 1.3).abs() < 0.01);
        assert!((Engineer::camber_degrees(&car, 1) + 1.3).abs() < 0.01);
    }

    /// Four corners of one problem used to be four recommendations, which is
    /// every slot the overlay has spent saying one thing — and "FL COLD / FR
    /// COLD / RL COLD / RR COLD" reads as noise rather than as "the tyres are
    /// not up to temperature".
    #[test]
    fn four_cold_tyres_are_one_piece_of_advice() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            speed_kmh: 180.0,
            tyre_temp_inner_c: [55.0; 4],
            tyre_temp_middle_c: [55.0; 4],
            tyre_temp_outer_c: [55.0; 4],
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_tyre_temperature(&car, &mut recs);

        assert_eq!(recs.len(), 1, "one fact, one line: {recs:?}");
        assert!(
            recs[0].message.contains("All four"),
            "and it says which corners: {}",
            recs[0].message
        );
    }

    /// Two of four is still one line, and it names the axle rather than
    /// listing wheels.
    #[test]
    fn two_hot_fronts_are_named_as_an_axle() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            speed_kmh: 180.0,
            tyre_temp_inner_c: [130.0, 130.0, 90.0, 90.0],
            tyre_temp_middle_c: [130.0, 130.0, 90.0, 90.0],
            tyre_temp_outer_c: [130.0, 130.0, 90.0, 90.0],
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_tyre_temperature(&car, &mut recs);

        assert_eq!(recs.len(), 1);
        assert!(
            recs[0].message.contains("Fronts"),
            "expected an axle, got: {}",
            recs[0].message
        );
    }

    /// Cold at the front and hot at the back is two different problems, and
    /// grouping must not merge them.
    #[test]
    fn cold_and_hot_stay_separate_problems() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            speed_kmh: 180.0,
            tyre_temp_inner_c: [50.0, 50.0, 130.0, 130.0],
            tyre_temp_middle_c: [50.0, 50.0, 130.0, 130.0],
            tyre_temp_outer_c: [50.0, 50.0, 130.0, 130.0],
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_tyre_temperature(&car, &mut recs);

        assert_eq!(recs.len(), 2, "{recs:?}");
        assert!(recs.iter().any(|rec| rec.message.contains("Fronts")));
        assert!(recs.iter().any(|rec| rec.message.contains("Rears")));
    }

    /// The threshold that made the engineer cry wolf. `wear_warning - 2` meant
    /// a tyre at 93.9 % life — most of the way through a first stint — came
    /// back as CRITICAL "WORN OUT".
    #[test]
    fn a_tyre_most_of_the_way_through_a_stint_is_not_critical() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            tyre_wear: [93.0; 4],
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_tyre_wear(&car, &mut recs);

        assert_eq!(recs.len(), 1, "{recs:?}");
        assert_eq!(
            recs[0].severity,
            Severity::Warning,
            "93% life is a warning, not a critical: {}",
            recs[0].message
        );

        // And below the critical threshold it still is one.
        let car = Car {
            tyre_wear: [70.0; 4],
            ..Default::default()
        };
        let mut recs = Vec::new();
        engineer.analyze_tyre_wear(&car, &mut recs);
        assert_eq!(recs[0].severity, Severity::Critical, "{recs:?}");
    }

    /// "Laps remaining" starts as "not measured", and 99.0 was a bad way to
    /// say it — ninety-nine laps is also a perfectly good answer, so a fresh
    /// set on a short track read as having no data at all.
    #[test]
    fn tyre_life_says_not_measured_with_a_value_laps_cannot_take() {
        let engineer = Engineer::new(&AppConfig::default());
        for corner in 0..4 {
            assert!(
                engineer.stats.tyre_laps_remaining[corner] < 0.0,
                "corner {corner} should start unmeasured"
            );
        }
    }

    /// The pressure advice printed raw psi while the temperature advice next
    /// to it went through the formatter, so anyone working in bar read their
    /// pressures in one unit on the Dashboard and another in the advice about
    /// them.
    #[test]
    fn pressure_advice_is_in_the_unit_the_driver_chose() {
        let config = AppConfig {
            pressure_unit: PressureUnit::Bar,
            ..AppConfig::default()
        };
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            speed_kmh: 120.0,
            tyre_pressure_psi: [20.0; 4],
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_tyre_pressure(&car, &Session::default(), &mut recs);

        assert_eq!(
            recs.len(),
            1,
            "four under-inflated tyres are one line: {recs:?}"
        );
        assert!(
            recs[0].message.contains("bar"),
            "expected bar, got: {}",
            recs[0].message
        );
        assert!(
            !recs[0].message.contains("psi"),
            "and not psi: {}",
            recs[0].message
        );
    }

    /// Both front brakes over temperature is one thing to say. It also has to
    /// name the wheels the way every other alert does — this used to number
    /// them "Brake 1" to "Brake 4".
    #[test]
    fn cooking_brakes_are_grouped_and_named_by_corner() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            brake_temp_c: [950.0, 950.0, 300.0, 300.0],
            ..Default::default()
        };

        let mut recs = Vec::new();
        engineer.analyze_brakes(&car, &mut recs);

        assert_eq!(recs.len(), 1, "{recs:?}");
        assert!(recs[0].message.contains("Fronts"), "{}", recs[0].message);
        assert!(
            !recs[0].message.contains("Brake 1"),
            "corners are named, not numbered: {}",
            recs[0].message
        );
    }

    /// What all of this is for: the overlay carries eight lines, and a session
    /// with several things wrong has to fit more than one of them in.
    #[test]
    fn several_problems_at_once_still_leave_room_for_each_other() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        age_the_alerts(&mut engineer);

        let car = Car {
            speed_kmh: 180.0,
            tyre_pressure_psi: [20.0; 4],
            tyre_wear: [70.0; 4],
            brake_temp_c: [950.0; 4],
            tyre_temp_inner_c: [130.0; 4],
            tyre_temp_middle_c: [130.0; 4],
            tyre_temp_outer_c: [130.0; 4],
            ..Default::default()
        };

        let recs = engineer.analyze_live(&car, &Session::default(), None);

        // Four distinct problems. Ungrouped this was sixteen lines, and the
        // four the overlay publishes were all about tyre temperature.
        for expected in ["pressure", "WORN OUT", "brakes cooking", "OVERHEATING"] {
            assert!(
                recs.iter().any(|rec| rec.message.contains(expected)),
                "'{expected}' did not survive into the top of the list: {:?}",
                recs.iter().map(|r| &r.message).collect::<Vec<_>>()
            );
        }
    }

    #[test]
    fn tyre_pressure_alert_uses_updated_configuration() {
        let mut config = AppConfig::default();
        config.alerts.tyre_pressure_max = 31.0;
        let mut engineer = engineer_reading_a_complete_game(&config);
        let car = Car {
            speed_kmh: 60.0,
            tyre_pressure_psi: [30.0; 4],
            ..Default::default()
        };
        let session = Session::default();

        let recommendations = engineer.analyze_live(&car, &session, None);
        assert!(!recommendations.iter().any(|rec| rec.category == "Pressure"));

        config.alerts.tyre_pressure_max = 29.0;
        engineer.update_config(&config);

        let past = std::time::Instant::now() - std::time::Duration::from_secs(2);
        for i in 0..4 {
            engineer
                .alert_timers
                .insert(format!("pres_{}", i), (past, past));
        }

        let recommendations = engineer.analyze_live(&car, &session, None);
        assert!(recommendations.iter().any(|rec| rec.category == "Pressure"));
    }

    /// The brake and tyre-temperature alerts had no hysteresis, unlike the
    /// pressure and wear alerts, so they pushed a fresh recommendation on
    /// every frame the condition held.
    #[test]
    fn overheating_alerts_are_not_repeated_every_frame() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        let session = Session::default();
        let car = Car {
            speed_kmh: 150.0,
            brake_temp_c: [1500.0; 4],
            ..Default::default()
        };

        // The gate needs a second of sustained condition before it fires at
        // all, so the first burst produces nothing.
        let mut total = 0;
        for _ in 0..50 {
            total += engineer
                .analyze_live(&car, &session, None)
                .iter()
                .filter(|rec| rec.category == "Overheat")
                .count();
        }
        assert_eq!(
            total, 0,
            "an alert should need a sustained condition, not a single frame"
        );
    }

    /// AC's own fuel_x_lap sits in the unverified tail of the graphics page
    /// and reads zero on lap one regardless, so the whole strategy tab was
    /// gated on a field that may never be populated.
    #[test]
    fn fuel_estimate_falls_back_to_measured_consumption() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        let info = crate::session_info::SessionInfo::default();

        // AC reports nothing, as it does on lap one and as it would
        // permanently if that offset is wrong.
        let session = |laps| Session {
            completed_laps: laps,
            fuel_per_lap: 0.0,
            ..Default::default()
        };
        let car = |fuel| Car {
            fuel_litres: fuel,
            speed_kmh: 120.0,
            ..Default::default()
        };

        // Start the stint with a full tank.
        engineer.update(&car(50.0), &session(0), &info);
        assert_eq!(
            engineer.stats.fuel_laps_remaining, 0.0,
            "nothing measured yet, so no estimate is claimed"
        );

        // Two laps at 2.5 L each.
        engineer.update(&car(47.5), &session(1), &info);
        engineer.update(&car(45.0), &session(2), &info);

        assert!(
            (engineer.stats.fuel_consumption_rate - 2.5).abs() < 0.01,
            "measured burn, got {}",
            engineer.stats.fuel_consumption_rate
        );
        assert!(
            (engineer.stats.fuel_laps_remaining - 18.0).abs() < 0.1,
            "45 L at 2.5 L/lap is 18 laps, got {}",
            engineer.stats.fuel_laps_remaining
        );
    }

    /// **Practice has no finish to run short of.**
    ///
    /// The race-finish check asks whether the tank will see the flag, and it
    /// fired on any session with a clock — which is every session. An hour of
    /// practice on a GT3 became "Short 5.7 L, save fuel or box", advice about
    /// a distance nobody is running.
    #[test]
    fn no_fuel_verdict_about_finishing_a_session_that_does_not_finish() {
        use crate::games::SessionKind;
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        let info = crate::session_info::SessionInfo::default();

        // An hour on the clock, two-minute laps, and not enough fuel for
        // thirty of them.
        let session = |kind| Session {
            kind,
            session_time_left_ms: 3_600_000.0,
            best_lap_ms: 120_000,
            last_lap_ms: 120_000,
            fuel_per_lap: 2.5,
            ..Default::default()
        };
        let car = Car {
            fuel_litres: 30.0,
            speed_kmh: 120.0,
            ..Default::default()
        };

        let said_short = |engineer: &mut Engineer, kind| {
            engineer.update(&car, &session(kind), &info);
            engineer
                .analyze_live(&car, &session(kind), None)
                .iter()
                .any(|rec| rec.category.contains("Race Finish"))
        };

        assert!(
            said_short(&mut engineer, SessionKind::Race),
            "a race is exactly what this advice is for"
        );
        for quiet in [
            SessionKind::Practice,
            SessionKind::Qualifying,
            SessionKind::Superpole,
        ] {
            assert!(
                !said_short(&mut engineer, quiet),
                "{quiet:?} has no finish, so there is nothing to be short for"
            );
        }
    }

    /// Burn measured across a refuel is meaningless, and the stale estimate
    /// it produced could fire BOX BOX BOX on a car that had just filled up.
    #[test]
    fn refuelling_discards_the_measured_history() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        let info = crate::session_info::SessionInfo::default();
        let session = |laps| Session {
            completed_laps: laps,
            ..Default::default()
        };
        let car = |fuel| Car {
            fuel_litres: fuel,
            speed_kmh: 120.0,
            ..Default::default()
        };

        engineer.update(&car(20.0), &session(0), &info);
        engineer.update(&car(17.5), &session(1), &info);
        assert!(engineer.stats.fuel_laps_remaining > 0.0);

        // Pit stop: the tank goes up.
        engineer.update(&car(60.0), &session(2), &info);
        assert_eq!(
            engineer.stats.fuel_laps_remaining, 0.0,
            "the estimate is dropped rather than carried across the stop"
        );
    }

    /// acc_g is [lateral, vertical, longitudinal]. Aggression used indices 0
    /// and 1, so it summed cornering with the ~1 g of gravity the car carries
    /// even parked, and never looked at braking or acceleration.
    #[test]
    fn aggression_ignores_the_vertical_axis() {
        let config = AppConfig::default();
        let mut engineer = engineer_reading_a_complete_game(&config);
        let session = Session::default();
        let info = crate::session_info::SessionInfo::default();

        // Straight line, steady speed, 1 g down. Nothing aggressive here.
        let cruising = Car {
            speed_kmh: 120.0,
            acc_g: [0.0, 1.0, 0.0],
            ..Default::default()
        };
        for _ in 0..200 {
            engineer.update(&cruising, &session, &info);
        }
        let cruising_aggression = engineer.driving_style.aggression;
        assert!(
            cruising_aggression < 5.0,
            "vertical g must not register as aggression, got {cruising_aggression}"
        );

        // Hard braking. This is the case the old formula could not see at all,
        // because longitudinal g lives at index 2.
        let braking = Car {
            speed_kmh: 120.0,
            acc_g: [0.0, 1.0, -1.8],
            ..Default::default()
        };
        for _ in 0..200 {
            engineer.update(&braking, &session, &info);
        }
        assert!(
            engineer.driving_style.aggression > cruising_aggression + 20.0,
            "braking must raise aggression, got {}",
            engineer.driving_style.aggression
        );
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct TyreCornerAdjustment {
    pub corner_name: String,
    pub current_psi: f32,
    pub recommended_delta_psi: f32,
    pub temp_spread_c: f32,
}

#[derive(Debug, Clone, Serialize)]
pub struct TyrePressureOptimizer {
    pub corners: [TyreCornerAdjustment; 4],
}

impl TyrePressureOptimizer {
    /// **One target per corner**, because the driver can set the two axles
    /// apart and a class's figure has to reach here the same way it reaches
    /// the advice — through [`hot_pressure`]. This took a single number until
    /// v0.4.5, which is how a screen headed PER-CORNER ADJUSTMENT came to
    /// measure all four against one.
    pub fn calculate(car: &Car, target_psi: [f32; 4]) -> Self {
        let labels = ["FL", "FR", "RL", "RR"];
        let mut corners = Vec::with_capacity(4);

        for (i, label) in labels.iter().enumerate() {
            let p_psi = car.tyre_pressure_psi[i];
            let t_i = car.tyre_temp_inner_c[i];
            let t_o = car.tyre_temp_outer_c[i];
            let spread = t_i - t_o;
            let p_delta = target_psi[i] - p_psi;

            let rec_delta = if p_delta.abs() > 0.5 {
                (p_delta * 10.0).round() / 10.0
            } else if spread > 12.0 {
                -0.3
            } else if spread < -8.0 {
                0.3
            } else {
                0.0
            };

            corners.push(TyreCornerAdjustment {
                corner_name: (*label).to_string(),
                current_psi: p_psi,
                recommended_delta_psi: rec_delta,
                temp_spread_c: spread,
            });
        }

        Self {
            corners: [
                corners[0].clone(),
                corners[1].clone(),
                corners[2].clone(),
                corners[3].clone(),
            ],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ColdPressureEstimate {
    pub target_hot_psi: f32,
    pub recommended_cold_psi: f32,
    pub delta_temp_psi: f32,
    pub delta_grip_psi: f32,
}

pub struct ColdPressureCalculator;

impl ColdPressureCalculator {
    pub fn calculate(
        target_hot_psi: f32,
        ambient_temp_c: f32,
        track_grip: f32,
    ) -> ColdPressureEstimate {
        let temp_diff = (85.0 - ambient_temp_c.clamp(0.0, 50.0)).max(0.0);
        let delta_temp_psi = temp_diff * 0.08;
        let grip_norm = track_grip.clamp(0.80, 1.0);
        let delta_grip_psi = (1.0 - grip_norm) * 1.2;

        let recommended_cold_psi = (target_hot_psi - delta_temp_psi - delta_grip_psi).max(15.0);

        ColdPressureEstimate {
            target_hot_psi,
            recommended_cold_psi: (recommended_cold_psi * 10.0).round() / 10.0,
            delta_temp_psi: (delta_temp_psi * 10.0).round() / 10.0,
            delta_grip_psi: (delta_grip_psi * 10.0).round() / 10.0,
        }
    }
}
