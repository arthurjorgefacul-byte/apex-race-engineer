# Where this is going: a modular core, several games, several faces

A plan, not a description. Nothing below is built yet except where it says so.

The ask, in one sentence: **the core should read whatever game is running,
compute everything, and broadcast it; anything that draws should be a separate
thing that subscribes.** Today the core is shaped around Assetto Corsa and has
exactly two consumers, both wired in by hand.

## What is actually game-specific today

Worth being precise, because it is less than it looks. Of `core/`:

| Module | Game-specific? |
|---|---|
| `games/assetto_corsa/structs.rs` | **Yes** — AC's shared-memory pages, field for field |
| `games/assetto_corsa/paths.rs` | **Yes** — where Steam puts AC, where its setups live |
| `setup_manager.rs` | **Yes** — AC's setup `.ini`, and its click indices |
| `content_manager.rs` | **Yes** — reads AC's car data |
| `analyzer.rs` | No — laps, sectors, averages, histograms |
| `engineer.rs` | No — takes `Car` and `Session`, as of v0.3.7 |
| `debrief.rs` | No, same |
| `records.rs`, `ring_buffer.rs`, `atomic_file.rs` | No |
| `overlay/` | **Transport**, not a game — see below |

So the split is not "rewrite the core". It is: put a model in the middle, move
four modules behind a trait, and let the rest talk to the model.

## The shape

```
                 ┌──────────────┐
   Assetto Corsa │ sources/ac   │─┐
   (shared mem)  └──────────────┘ │
                 ┌──────────────┐ │   ┌─────────┐   ┌───────────┐
   another game  │ sources/…    │─┼──►│  model  │──►│ engineer  │
                 └──────────────┘ │   └─────────┘   └───────────┘
                                  │        │              │
                                  │        └──────┬───────┘
                                  │               ▼
                                  │        ┌─────────────┐
                                  └───────►│  broadcast  │
                                           └──────┬──────┘
                        ┌─────────────┬───────────┼────────────┐
                        ▼             ▼           ▼            ▼
                   shared mem     WebSocket    terminal    (your next
                   → CSP panel    → anything    (in-proc)    front end)
```

### `games/reading.rs` — the model. **Built**

One neutral `Reading`, in three parts: `Car` (what the car is doing this
instant), `Session` (where it is in the session, and the clock) and `Fixed`
(the car, the track, the driver, the limits). Speed, gear, rpm, four corners of
pressure/temperature/wear/brake, ride height, fuel, lap and sector timing,
session state. Units are in the field names and conventions are stated rather
than inherited — `Car::gear` is −1 for reverse because that is what a driver
means, and AC's 0-is-reverse is translated once, at the boundary. Plus a
`Capabilities` set, because this is the part that always goes wrong: a game that
cannot report inner/outer tyre temperature must be *distinguishable* from a game
reporting zero. The camber advice is built on that difference, and a model that
cannot express "not measured" turns every missing field into a wrong verdict.

### `sources/` — one module per game

```rust
pub trait Source {
    fn id(&self) -> &'static str;              // "assetto_corsa"
    fn capabilities(&self) -> Capabilities;
    fn detect() -> Option<Self> where Self: Sized;   // is it installed / running
    fn poll(&mut self) -> Option<Sample>;
    fn setups(&self) -> Option<&dyn SetupStore> { None }
}
```

`games/assetto_corsa/` has the structs, the paths and the `Memory` reader that
used to live in `tui/src/lib.rs`; `setup_manager` and `content_manager` are
still outside it. Nothing else in the tree mentions `AcPhysics` — and as of
v0.3.7 that is a test rather than an intention, because the first time round
the trait was written, held and bypassed. See
`tests_suite/src/boundary_tests.rs`.

### `engineer` — advice from the model only. **Built**

Takes `Car`, `Session` and `Lap`, not `AcPhysics`. It was mostly a signature
change, as expected: `debrief.rs` already worked off `LapData` and did not move
at all.

### `broadcast` — transports, plural

The frame in `overlay/frame.rs` becomes one transport among several, and it
**stays** for the in-game panel. That is not legacy: CSP Lua runs on AC's render
thread, and a 2 KB memcpy from a mapping is the cheapest thing that can possibly
happen there. A WebSocket in the panel would put a socket read in the draw path,
which is the one thing the whole design exists to avoid.

UDP and WebSocket are for everything that is *not* inside the game: a browser
overlay, a stream widget, OBS, a phone on the desk, a second machine, someone
else's tool. UDP first because it is the simplest thing that reaches another
process or another box and it cannot block the tick; WebSocket where a browser
is the client.

**Sending a driver's data to a remote server is the same shape** — a sink that
happens to have a hostname rather than a port on localhost. It is worth naming
now even though nothing does it yet, because it is the requirement that decides
the abstraction: sinks must be allowed to be slow and to fail without the tick
noticing, which means the publisher hands over a message and never waits.

```json
{ "t": "sample", "seq": 12043, "speed_kmh": 214.0, "gear": 5,
  "tyres": { "pressure_psi": [26.8, 27.0, 26.4, 26.6], "temp_c": [...] },
  "capabilities": ["tyre_edges", "sectors"] }
{ "t": "advice", "lines": [ { "severity": 1, "text": "…", "action": "…" } ] }
{ "t": "lap", "number": 12, "time_ms": 91234, "sectors": [...], "debrief": [...] }
```

Versioned like the frame is, for the same reason: the moment somebody writes a
widget against it, the schema is a contract.

## Assets

`assets/frontends/csp-panel/` is not "the overlay", it is *the Assetto Corsa
front end*. It moves to `assets/frontends/csp-panel/`, and `assets/` is where
per-game and per-frontend files live from then on. `install.rs` keeps embedding
it; only the `include_bytes!` paths change.

## The one that decides the shape: watching someone else drive

A driver is on track and cannot look away. A friend runs the same program, sets
it to receive, and sees the driver's telemetry and the engineer's advice — in
their own overlay, while spectating the same session in their own copy of AC.

This is worth writing down before the transport is built, because it is the
requirement that makes the design pay for itself:

**A remote peer is just another `Source`.** The friend's core does not know the
samples arrived over a socket rather than out of shared memory. The analyser,
the engineer, the debrief, the frame writer and the panel are unchanged — they
are already downstream of `Source`, as of the commit that created it. Sharing
is one new sink; receiving is one new source. Nothing in the middle moves.

```
driver's machine                          friend's machine
  AC shared memory                          network source
        │                                         │
    core (analyse, advise)  ──[ sink ]──►    core (analyse, advise)
        │                                         │
   local frame → panel                     local frame → panel
```

The friend's panel needs no change at all: their own application writes their
own local frame, and the numbers in it happen to be someone else's.

### What has to be decided, and what is genuinely hard

**Where the engineer runs.** Two honest options:

* *Send samples, advise locally.* The friend's own thresholds, units and
  language apply, and they can page the debrief independently. Costs more
  bandwidth and the receiving core needs enough lap history to be useful.
* *Send the computed frame.* Far simpler, far smaller, and the friend sees
  exactly what the driver's engineer is saying — which is what you want when the
  point is to help the person driving. Their unit and language settings would
  not apply.

Start with the second. It is the smaller change and the better answer for the
stated use; the first can be added later as a second message kind.

**The frame needs a flag saying whose numbers these are.** Otherwise the
receiving panel draws "CONNECTED" and a lap counter about a car the viewer is
not in, and a bug report arrives about telemetry that does not match the game.
One bit and a name.

**The network is the hard part, not the data.** Two machines in one flat is a
UDP socket and nothing else. Two machines behind two home routers is NAT, and
direct UDP will usually not connect without port forwarding. The options are the
usual three: forward a port, punch holes, or put a relay in the middle — and a
relay is the same thing as "send a driver's data to a server", so it solves the
broadcast case at the same time. That is one piece of infrastructure serving
both, and it is the only part of this that is not a weekend.

**Losing a packet is fine; losing a lap is not.** Samples are replaced sixty
times a second, so UDP dropping one costs nothing. A completed lap and its
debrief happen once, so those want acknowledging or repeating.

**It is telemetry about a person.** Sharing has to be something the driver turns
on, per session, and if it travels through a relay the driver should be told
that before the first packet leaves.

### The terminal gets it for nothing

Worth saying explicitly because it is the test of whether the abstraction is
real: the terminal renders from the core, and the core renders from a `Source`.
A network source therefore shows up in the TUI — every tab, the engineer, the
analysis, the debrief — with no code written for it. If that turned out not to
be true, the boundary would be in the wrong place.

### Scaling it up: a championship

Two friends is peer-to-peer. Twenty cars and a room full of people watching is a
different problem, and the difference is worth planning for even if it is built
much later:

* **The relay stops being optional.** One driver cannot send to thirty
  receivers; the sink sends once and the relay fans out.
* **Every stream needs an identity** — car number, driver name — and receivers
  need to choose which one they are watching. Peer-to-peer can skip this;
  a championship cannot.
* **The rate has to come down.** The computed frame is about 2.5 KB. At the
  tick rate that is roughly 150 KB/s per car, which is fine for one and is
  3 MB/s at the relay for twenty. A spectator does not need sixty updates a
  second — ten is past the point of noticing — so remote sinks should publish at
  their own rate rather than at the tick's. That is a property of the sink, and
  designing it in from the first one is much easier than retrofitting it.

None of this changes the core. It is all inside the transport, which is the
point of separating it.

## Stages

Each one leaves the tree working, tested and releasable. That matters more than
usual here: the frame version has already moved three times this cycle, and
every move costs every Linux driver a bridge update.

1. ~~**Assets move.**~~ Done. `assets/frontends/csp-panel/`.
2. ~~**A folder per game, and the core reads it.**~~ Done.
   `core/src/games/assetto_corsa/` holds the structs, the paths and the shared
   memory reader that used to live in the terminal, behind a `Source` trait
   with a `Capabilities` set. The neutral reading was still to come — the
   engineer took `AcPhysics`, and so did the analyser and five screens, which
   meant the boundary was a folder and carried no data.
3. ~~**The engineer moves onto the model.**~~ Done, v0.3.7.
   `Source::poll` returns a `Reading` and there are no accessors beside it;
   `games/assetto_corsa/reading.rs` converts. 109 references to AC's structs
   across ten files became none, with no change to a single screenshot, and
   two source-level tests keep it that way. Still open here: the compound-aware
   thresholds below, and **the capability flags, which are consulted by
   nobody.**
4. ~~**`broadcast`, with sinks.**~~ Done. `Sink`, a `Broadcaster` that fans out
   and never waits, the shared-memory mapping wearing the same interface, and a
   UDP sink sending the computed frame as JSON. Off unless `broadcast_to` is
   set.
5. **A receiving `Source`, and the settings to switch between sending and
   receiving.** The half that makes a friend able to watch: a source that reads
   the UDP messages instead of shared memory, and a frame flag saying whose
   numbers these are. WebSocket alongside UDP where the client is a browser.
6. **A second game.** Only now, because until a second source exists every
   abstraction above is a guess. The first one will find three wrong assumptions
   in the model, and that is cheaper to fix with one consumer than five.

## The advice itself

Separate from the architecture, and worth doing regardless. The current
verdicts are thin in one specific way: **thresholds are global constants where
the physics is car-specific.**

- `analyze_tyre_pressure` reads the compound and picks a band —
  street/sport/eco/semislick, wet/rain, or racing.
- `analyze_tyre_temperature` and the wear checks do **not**. One
  `tyre_temp_min`/`tyre_temp_max` pair from the config is applied to a GT3 slick
  and to an Abarth on street tyres, whose working windows are nowhere near each
  other. "All four cold 62 °C" is right for one and nonsense for the other.

That is the same shape of mistake as the camber bug: a fixed number standing in
for something the car decides. Same for brake temperature, where a carbon disc
and an iron one differ by hundreds of degrees.

The fix is a per-compound table in the model rather than four numbers in a
config, which is why it belongs in stage 3 and not before.
