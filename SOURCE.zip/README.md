# APEX 0.5.1 — native race engineer for original Assetto Corsa

Open **Apex.exe**, or the **APEX Race Engineer** shortcut on your Desktop. APEX is a native Windows application. Your saved recordings remain in this folder's `data/` directory.

## Start and finish a session

**Home** is the starting screen. Press **Start session** to begin recording and open the live engineer. If Assetto Corsa is not connected yet, APEX waits for your chosen car and track. Existing recordings remain available under **Lap analysis** without starting a new session.

Use **End session & debrief** when finished. APEX also finishes an active session when the driving session ends or changes, after allowing brief connection interruptions. Pausing alone does not end it. Home then shows the session's useful figures, measured strengths, improvement priorities and a plan for the next run. A new session requires pressing Start again. A partial final lap does not become a completed reference lap.

Debriefs distinguish measured evidence from an experiment to try. The elapsed session time includes pauses; fuel and consistency figures appear only when the recorded data supports them. Debriefs and lap sheets stay on this computer.

## While driving

- **Live engineer** shows current telemetry, fuel range, tyre readings and delta to your own clean reference.
- The engineer responds during the lap: observed track-limit excursions, game-reported invalidity and flags, pit transitions, fuel alerts, verified tyre-target deviations, periodic pace/range checks, corner preparation and measured corner exits.
- Routine calls wait for a sustained straight or the pits. Track-limit calls can interrupt. **Settings → Radio frequency** changes how often the engineer speaks; **Quiet radio** preserves urgent track-limit and critical fuel alerts. The speech mute disables all spoken output.
- Each eligible detected corner can receive its own call. A lap needs a usable comparable clean reference; early partial laps, AI driving, pit/out laps and invalid laps are excluded from driving coaching. Corners that improved once do not immediately become repeated praise.
- Open **Race Engineer** in AC's app sidebar and click **ENGINEER MENU +**. Ask for fuel, tyres, pace, next corner, corner losses, last lap, strategy, energy, track limits or the new race queries below. More/fewer/quiet controls are also there. Requests travel on a background worker.
- Desktop quick buttons and a typed question box use the same answers. These are factual telemetry commands, not an unrestricted chatbot.
- **Driver feedback** identifies the highest-priority measured loss first: braking onset/release, throttle pickup, exit speed or observed entry/exit gear differences when those channels exist. It gives a specific next experiment and retains the evidence and uncertainty in the lap analysis. Repeated comparable clean-lap evidence takes priority over a single poor section.
- Requested answers speak after push-to-talk closes, including while stationary or paused. They do not wait for the routine straight-line update schedule. The speech mute still applies; the desktop answer reports its speech status.

## Race and tyre commands

Ask **my fastest lap**, **fastest lap of the race**, **other drivers best laps**, **gap ahead**, **gap behind**, or **gap to the leader**. The **Race timing** sheet shows available opponent best laps, compounds and estimated gaps. Position gaps require a race session and fresh CSP timing; a qualifying best-lap comparison is not presented as a physical race gap. Missing data remains unavailable.

Ask **change compound** to see the compounds actually available for this car. APEX asks which one if you have not specified it and reports observed matching-car pace by compound when enough valid completed laps have been observed. It does not assign an old session-best time to the tyre a driver happens to have fitted now. Different cars within broad Formula or prototype families are not pooled as equivalent pace.

A compound request prepares the **next Quick Pitstop tyre selection**, when the CSP bridge has a verified writable mapping. It does not replace tyres while driving. APEX reports success only after reading back the accepted setting; unavailable mappings, expired requests or missing acknowledgements are reported explicitly. No choice is silently guessed.

## Push-to-talk

Hold **F10**, wait for **MIC LISTENING** in the overlay, say a short English command, then release. Examples: **“fuel status”**, **“tyres”**, **“pace”**, **“next corner”**, **“corner five”** (one through ten), **“corner losses”**, **“last lap”**, **“race strategy”**, **“energy”**, **“track limits”**, **“my fastest lap”**, **“fastest lap of the race”**, **“other drivers best laps”**, **“gap ahead”**, **“gap behind”**, **“gap to the leader”**, **“change compound”**, **“change to medium”**, **“give me feedback”**, **“quiet radio”**, **“more updates”** or **“fewer updates”**.

In **Settings**, use **Bind wheel button…**, release your wheel buttons, then press the desired button. The detected wheel and button appear beside the binding; learning never opens the microphone. G29 and other Windows joystick-compatible devices use the same binding flow. Button labels start at 1. Windows' legacy joystick interface exposes at most 32 buttons per device; an unavailable or disconnected device does not start the microphone.

Alternatively choose a global keyboard key (F1–F24, letters, numbers or the listed navigation keys), or disable push-to-talk, then save. Choose a binding that does not conflict with your game controls. APEX checks the saved device identity before accepting a wheel hold and requires release before rearming after a reconnect. The first microphone startup takes a moment; the overlay shows when it is ready. A recognized question closes the input before its answer. Releasing the button ends the owned microphone worker immediately; a 12-second limit also bounds an abandoned hold.

Recognition uses the installed **Windows English (United States)** speech recognizer and the default input device. Audio is processed locally and is not saved or uploaded. APEX reports missing recognizers/devices. Speech output uses Windows' default audio output; **Radio check** tests it. Speaking waits while push-to-talk is active. Actual recognition depends on your microphone and pronunciation.

## Find your driving data

1. Open **Lap analysis**.
2. Choose a session on the left, then a lap. **Clean**, **Excluded** and **Removed** identify its status; hover a row for the recorded reason and fuel use.
3. The large heading shows the lap time, total difference and largest section losses. Choose an automatic clean best or a particular clean reference from that session.
4. Hover the graph for A/B speed, throttle, brake, elapsed time and cumulative delta. Drag across it to zoom; double-click or **Full lap** to reset. Values outside recorded coverage remain unavailable.
5. Select any detected corner in the table to focus its corner-and-exit section. Read the action first, then entry/minimum/exit speeds, braking and throttle differences, available gear evidence, confidence and a sourced experiment to test. Scroll the table to inspect every section.
6. **Remove lap** excludes it from APEX references, comparisons and fuel estimates. **Undo removal**, or **Show removed laps → Restore**, reverses it. Raw recordings are retained. This does not change Pro Engineer's independent history.
7. **Export…** saves the full selected session, including recorded samples. **Files** opens the recordings folder. Large exports use a separate read-only view so recording can continue.

Detected C1/C2 labels describe telemetry segments and their following straights. They are not claimed to be official circuit turn numbers.

## Coaching foundations and human telemetry

The reference material is a background database used by feedback and debriefs. It is not a separate top-level tab or an automatic target lap. **42 circuit-family profiles × eight broad car categories** provide 336 combinations of circuit context and category inspection priorities. Exact car and circuit identities still matter; an unknown or misleadingly renamed mod stays unverified. A profile does not establish calibrated braking marks, optimal gears, setup values or an elite driver model.

Corner explanations use measured differences to select phase-relevant engineering context and offer a test; they do not diagnose a setup fault from a single scalar. The radio wording is informed by actual published driver-engineer exchanges and official team explanations: crucial action first, a short measured reason, routine calls during lower-workload moments and fuller explanations after the lap.

- Analysis methods: [AiM RaceStudio 3](https://www.aim-sportline.com/docs/racestudio3/manual/html/analysis.html).
- Driving mechanisms and experiments: [Scott Mansell / Driver61](https://driver61.com/uni/corner-phases/).
- **Nine published original-AC human laps** cover BMW Z4 GT3, Dallara F317 and Mazda Miata NA at Red Bull Ring GP, Barcelona older GP and Monza GP, from [AssettoCorsaGym](https://huggingface.co/datasets/dasgringuen/assettoCorsaGym), Adrian Remonda et al., NeurIPS 2024, **CC BY 4.0**. They are selected complete laps within individual research recordings, not claimed expert or world-record laps. Fuel use and tyre wear were disabled in those recordings.
- Radio research: [McLaren's explanation of radio timing](https://www.mclaren.com/racing/latest-news/mclarenracing/article/question-time/) and [Aston Martin's race-engineer interviews](https://www.astonmartinf1.com/en-GB/news/feature/trust-focus-and-managing-the-mind-of-an-f1-driver), with actual official F1 radio examples cited in the foundations database. F1-specific tyre and pit rules are not transferred to AC.
- Real F1 record times and current official Red Bull Ring information are labelled context only, with dated source links. They contain no driver-input telemetry and do not become AC GT3 targets.

Your own comparable clean laps remain the live reference. Public research traces provide attributed context; their driver skill, exact physics/setup/BoP and comparable conditions are not verified, so they are not activated as pace targets. The bundled verified elite-reference count is **zero**. Existing imported records are preserved; the source and import formats remain documented in `reference_data/README.md`.

See `reference_data/foundations/README.md` for coverage, source attribution, transformations and limitations, and `reference_data/README.md` for the reference formats. No proprietary Track Titan lap library, private race-engineer telemetry or trained optimal-lap model is claimed.

## Engines, installation and closing

**APEX live engineer** reads original AC's shared memory directly. **Settings** also offers the bundled, unmodified **AC Pro Engineer v0.5.1**, with its corresponding source and AGPL notices. Its own live controls require selecting AC and pressing **Enter** on **Start**. APEX combines its advice with independent recordings and live calls. Pro's rule settings remain in its own application. Pro may check for updates or update its CSP panel. Simulator Controller, Crew Chief and Track Titan are not embedded integrations.

For another installation, run **Install Overlay.cmd** to install both the Python overlay and **APEX session bridge** for CSP. Activation preserves other apps and backs up changed settings. If AC is still running, activation is deferred: enable the bridge in CSP App Shelf, or end the driving session and run the installer again before starting a new one. **RaceEngineer** also needs to be enabled in Content Manager's AC Apps settings. Keep the complete overlay folder, including its official Python 3.3 socket support. No separate Python 3.3 installation is needed. Opponent compounds and guarded Quick Pitstop changes require the CSP bridge; direct shared-memory telemetry remains available separately.

Closing the window is immediate and does not ask a modal question. A companion started by this window is stopped through bounded cleanup after the window disappears. An existing companion is left running. **Keep recording when I close the window** is an explicit option for the current run. No garage settings are changed automatically.

This release requires **Windows x64**, the **.NET 10 Windows Desktop Runtime**, and **Python 3.10+**. Both runtimes are already present here. No Rust build, browser runtime, cloud account or paid API is needed. Keep Apex.exe together with the supplied companion/source/third-party files. Portable ZIPs exclude your recordings and settings.

Unknown channels remain unavailable. AC/mods can omit definitive lap validity, hybrid deployment, setup/version identity or official race timing. Fuel estimates need observed consumption; tyre targets must be set for the current car/compound. Setup suggestions remain controlled experiments, and APEX does not apply them to the car.
